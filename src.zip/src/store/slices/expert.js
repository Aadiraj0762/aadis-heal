import { createAsyncThunk, createSlice } from "@reduxjs/toolkit";
import ExpertService from "../../services/expert.service";
import AuthService from "../../services/auth.service";

export const expertDetail = createAsyncThunk(
    "auth/get/user",
    async(thunkAPI) => {
        try {
            const data = await ExpertService.expertDetails();
            return { user: data };
        } catch (error) {
            const message =
                (error.response &&
                    error.response.data &&
                    error.response.data.message) ||
                error.message ||
                error.toString();
            return thunkAPI.rejectWithValue({ message });
        }
    }
);


export const postexpert = createAsyncThunk(
    "auth/forgotpassword",
    async(item, thunkAPI) => {
        try {
            const data = await ExpertService.expertprofile(item);
            return { user: data };
        } catch (error) {
            const message =
                (error.response &&
                    error.response.data &&
                    error.response.data.message) ||
                error.message ||
                error.toString();
            return thunkAPI.rejectWithValue({ message });
        }
    }
);


export const editExpert = createAsyncThunk(
    "auth/updateProfile",
    async(item, thunkAPI) => {
        try {
            const data = await ExpertService.editexpertprofile(item);
            return { user: data };
        } catch (error) {
            const message =
                (error.response &&
                    error.response.data &&
                    error.response.data.message) ||
                error.message ||
                error.toString();
            return thunkAPI.rejectWithValue({ message });
        }
    }
);



// export const logout = createAsyncThunk("auth/logout", async() => {
//     ExpertService.logout();
// });

const initialState = {
    loading: false,
    error: "",
    user: AuthService.getUserDetails() || null,
    isLoggedIn: false,
};

const authSlice = createSlice({
    name: "auth",
    initialState,
    extraReducers: {
      

        // [logout.fulfilled]: (state) => {
        //     state.isLoggedIn = false;
        //     state.user = null;
        // },
    },
});

const { reducer } = authSlice;
export default reducer;