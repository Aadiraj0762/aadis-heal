import { createAsyncThunk, createSlice } from "@reduxjs/toolkit";
import RevenueService from "../../services/revenue.service";
import AuthService from "../../services/auth.service";

export const HcRevenue = createAsyncThunk(
    "revenue/get/travelRevenue",
    async(thunkAPI) => {
        try {
            const data = await RevenueService.getHCRevenue();
            return { user: data };
        } catch (error) {
            const message =
                (error.response &&
                    error.response.data &&
                    error.response.data.message) ||
                error.message ||
                error.toString();
            return thunkAPI.rejectWithValue({ message });
        }
    }
);

// export const logout = createAsyncThunk("auth/logout", async () => {
//   AuthService.logout();
// });

const initialState = {
    loading: false,
    error: "",
    user: AuthService.getUserDetails() || null,
    isLoggedIn: false,
};

const revenueSlice = createSlice({
    name: "revenue",
    initialState,
    extraReducers: {
        [HcRevenue.pending]: (state) => {
            state.loading = true;
            state.error = "";
            state.isLoggedIn = false;
            state.user = null;
        },
        [HcRevenue.fulfilled]: (state, action) => {
            state.loading = false;
            state.error = "";
            state.isLoggedIn = true;
            state.user = action.payload.user;
        },
        [HcRevenue.rejected]: (state, action) => {
            state.loading = false;
            state.error = action.payload.message;
            state.isLoggedIn = false;
            state.user = null;
        },
        // [logout.fulfilled]: (state, action) => {
        //   state.isLoggedIn = false;
        //   state.user = null;
        // },
    },
});

const { reducer } = revenueSlice;
export default reducer;