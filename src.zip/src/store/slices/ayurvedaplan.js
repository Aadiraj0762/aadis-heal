import { createAsyncThunk, createSlice } from "@reduxjs/toolkit";
import ayurvedaplansService from "../../services/ayurvedaplans.service";
import AuthService from "../../services/auth.service";

export const getayurvedaplans = createAsyncThunk(
    "ayurvedaplan/get",
    async( thunkAPI) => {
        try {
            const data = await ayurvedaplansService.getayurvedaplans();
            return { user: data };
        } catch (error) {
            const message =
                (error.response &&
                    error.response.data &&
                    error.response.data.message) || 
                error.message ||  
                error.toString(); 
            return thunkAPI.rejectWithValue({ message });  
        }
    }
);

export const postayurdedaplans = createAsyncThunk(
    "ayurvedaplan/post",
    async(item, thunkAPI) => {
        try {
            const data = await ayurvedaplansService.postayurdedaplans(item);
            return { user: data };
        } catch (error) {
            const message =
                (error.response &&
                    error.response.data &&
                    error.response.data.message) || 
                error.message ||  
                error.toString(); 
            return thunkAPI.rejectWithValue({ message });  
        }
    }
);

export const editayurvedaplans = createAsyncThunk(
    "ayurvedaplan/put",
    async(item, thunkAPI) => {
        try {
            const data = await ayurvedaplansService.editayurvedaplans(item);
            return { user: data };
        } catch (error) {
            const message =
                (error.response &&
                    error.response.data &&
                    error.response.data.message) || 
                error.message ||  
                error.toString(); 
            return thunkAPI.rejectWithValue({ message });  
        }
    }
);

export const deleteayurvedaplans = createAsyncThunk(
    "ayurvedaplan/delete",
    async(thunkAPI) => {
        try {
            const data = await ayurvedaplansService.deleteayurvedaplans();
            return { user: data };
        } catch (error) {
            const message =
                (error.response &&
                    error.response.data &&
                    error.response.data.message) ||
                error.message ||
                error.toString();
            return thunkAPI.rejectWithValue({ message });
        }
    }
);

const initialState = {
    loading: false,
    error: "",
    user: AuthService.getUserDetails() || null,
    isLoggedIn: false,
};

const ayurvedaplansSlice = createSlice({
    name: "ayurvedaplan",
    initialState,
    extraReducers: {

        [getayurvedaplans.pending]: (state) => {
            state.loading = true;
            state.error = "";
            state.isLoggedIn = false;
            state.user = null;
        },
        [getayurvedaplans.fulfilled]: (state, action) => {
            state.loading = false;
            state.error = "";
            state.isLoggedIn = true;
            state.user = action.payload.user;
        },
        [getayurvedaplans.rejected]: (state, action) => {
            state.loading = false;
            state.error = action.payload.message;
            state.isLoggedIn = false;
            state.user = null;
        },

        [postayurdedaplans.pending]: (state) => {
            state.loading = true;
            state.error = "";
            state.isLoggedIn = false;
            state.user = null;
        },
        [postayurdedaplans.fulfilled]: (state, action) => {
            state.loading = false;
            state.error = "";
            state.isLoggedIn = true;
            state.user = action.payload.user;
        },
        [postayurdedaplans.rejected]: (state, action) => {
            state.loading = false;
            state.error = action.payload.message;
            state.isLoggedIn = false;
            state.user = null;
        },

        [editayurvedaplans.pending]: (state) => {
            state.loading = true;
            state.error = "";
            state.isLoggedIn = false;
            state.user = null;
        },
        [editayurvedaplans.fulfilled]: (state, action) => {
            state.loading = false;
            state.error = "";
            state.isLoggedIn = true;
            state.user = action.payload.user;
        },
        [editayurvedaplans.rejected]: (state, action) => {
            state.loading = false;
            state.error = action.payload.message;
            state.isLoggedIn = false;
            state.user = null;
        },

        [deleteayurvedaplans.pending]: (state) => {
            state.loading = true;
            state.error = "";
            state.isLoggedIn = false;
            state.user = null;
        },
        [deleteayurvedaplans.fulfilled]: (state, action) => {
            state.loading = false;
            state.error = "";
            state.isLoggedIn = true;
            state.user = action.payload.user;
        },
        [deleteayurvedaplans.rejected]: (state, action) => {
            state.loading = false;
            state.error = action.payload.message;
            state.isLoggedIn = false;
            state.user = null;
        },
    },
});

const { reducer } = ayurvedaplansSlice;
export default reducer;