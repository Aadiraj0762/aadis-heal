import { createAsyncThunk, createSlice } from "@reduxjs/toolkit";
import specialistService from "../../services/specialist.service";
import AuthService from "../../services/auth.service";



export const getspecialist = createAsyncThunk(
    "specialist/get/specialist",
    async(thunkAPI) => {
        try {
            const data = await specialistService.getspecialist();
            return { user: data };
        } catch (error) {
            const message =
                (error.response &&
                    error.response.data &&
                    error.response.data.message) ||
                error.message ||
                error.toString();
            return thunkAPI.rejectWithValue({ message });
        }
    }
)


export const getspecialists = createAsyncThunk(
    "specialist/get/specialist",
    async(thunkAPI) => {
        try {
            const data = await specialistService.getspecialistdetails();
            return { user: data };
        } catch (error) {
            const message =
                (error.response &&
                    error.response.data &&
                    error.response.data.message) ||
                error.message ||
                error.toString();
            return thunkAPI.rejectWithValue({ message });
        }
    }
)






// export const logout = createAsyncThunk("auth/logout", async () => {
//   AuthService.logout();
// });

const initialState = {
    loading: false,
    error: "",
    user: AuthService.getUserDetails() || null,
    isLoggedIn: false,
};

const labdetailsSlice = createSlice({
    name: "labdetails",
    initialState,
    extraReducers: {

        [getspecialist.pending]: (state) => {
            state.loading = true;
            state.error = "";
            state.isLoggedIn = false;
            state.user = null;
        },
        [getspecialist.fulfilled]: (state, action) => {
            state.loading = false;
            state.error = "";
            state.isLoggedIn = true;
            state.user = action.payload.user;
        },
        [getspecialist.rejected]: (state, action) => {
            state.loading = false;
            state.error = action.payload.message;
            state.isLoggedIn = false;
            state.user = null;
        },


        // [logout.fulfilled]: (state, action) => {
        //   state.isLoggedIn = false;
        //   state.user = null;
        // },
    },
});

const { reducer } = labdetailsSlice;
export default reducer;