import { createAsyncThunk, createSlice } from "@reduxjs/toolkit";
import medicalService from "../../services/medicalform.service";
import AuthService from "../../services/auth.service";






export const postmedical = createAsyncThunk(
    "exercise/post/exercise",
    async(item, thunkAPI) => {
        try {
            const data = await medicalService.postmedicalform(item);
            return { user: data };
        } catch (error) {
            const message =
                (error.response &&
                    error.response.data &&
                    error.response.data.message) || 
                error.message ||  
                error.toString(); 
            return thunkAPI.rejectWithValue({ message });  
        }
    }
);



// export const logout = createAsyncThunk("auth/logout", async () => {
//   AuthService.logout();
// });

const initialState = {
    loading: false,
    error: "",
    user: AuthService.getUserDetails() || null,
    isLoggedIn: false,
};

const TravelSlice = createSlice({
    name: "addtravels",
    initialState,
    extraReducers: {
    
        [postmedical.pending]: (state) => {
            state.loading = true;
            state.error = "";
            state.isLoggedIn = false;
            state.user = null;
        },
        [postmedical.fulfilled]: (state, action) => {
            state.loading = false;
            state.error = "";
            state.isLoggedIn = true;
            state.user = action.payload.user;
        },
        [postmedical.rejected]: (state, action) => {
            state.loading = false;
            state.error = action.payload.message;
            state.isLoggedIn = false;
            state.user = null;
        },


        // [logout.fulfilled]: (state, action) => {
        //   state.isLoggedIn = false;
        //   state.user = null;
        // },
    },
});

const { reducer } = TravelSlice;
export default reducer;