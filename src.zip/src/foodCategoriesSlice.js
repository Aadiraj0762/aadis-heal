import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import axios from 'axios';

// Fetch food categories
export const fetchFoodCategories = createAsyncThunk('foodCategories/fetch', async () => {
  const response = await axios.get('https://api-wm.healthonify.com/get/foodcategory');
  return response.data;
});

const foodCategoriesSlice = createSlice({
  name: 'foodCategories',
  initialState: [],
  reducers: {},
  extraReducers: (builder) => {
    builder.addCase(fetchFoodCategories.fulfilled, (state, action) => {
      return action.payload;
    });
  },
});

export default foodCategoriesSlice.reducer;
