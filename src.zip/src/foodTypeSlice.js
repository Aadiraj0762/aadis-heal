import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import axios from 'axios';

// Fetch food types
export const fetchFoodTypes = createAsyncThunk('foodTypes/fetch', async () => {
  const response = await axios.get('https://api-wm.healthonify.com/get/foodtype');
  return response.data;
});

const foodTypesSlice = createSlice({
  name: 'foodTypes',
  initialState: [],
  reducers: {},
  extraReducers: (builder) => {
    builder.addCase(fetchFoodTypes.fulfilled, (state, action) => {
      return action.payload;
    });
  },
});

export default foodTypesSlice.reducer;
