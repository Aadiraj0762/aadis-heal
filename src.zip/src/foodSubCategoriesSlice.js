import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import axios from 'axios';

// Fetch food subcategories
export const fetchFoodSubCategories = createAsyncThunk('foodSubCategories/fetch', async () => {
  const response = await axios.get('https://api-wm.healthonify.com/get/foodcategory');
  return response.data;
});

const foodSubCategoriesSlice = createSlice({
  name: 'foodSubCategories',
  initialState: [],
  reducers: {},
  extraReducers: (builder) => {
    builder.addCase(fetchFoodSubCategories.fulfilled, (state, action) => {
      return action.payload;
    });
  },
});

export default foodSubCategoriesSlice.reducer;
