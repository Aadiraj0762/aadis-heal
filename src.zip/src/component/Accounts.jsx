import React from "react";
import Navbarside from "./Navbarside";
import Footer from "./footer";
import { Link } from "react-router-dom";

const Accounts = () => {
  return (
    <div>
      <Navbarside />
      <div className="container-fluid pb-5 response-cover">
        <div className="row">
          <div className="col-lg-2 col-md-4" />
          <div className="col-lg-10 col-md-8">
            <div className="container-fluid pt-5">
              <div className="row">
                <div className="col-xl-4 col-lg-4 col-md-6 col-12">
                  <Link to="/SalesReport">
                    <div className="card bg-white">
                      <div className="card-body">
                        <div className="card-block pt-10 pb-10">
                          <div className="media">
                            <div className="media-body white text-left">
                              <h4 className="font-medium-2 card-title mb-0">
                                Sales Collection Report
                              </h4>
                            </div>
                            <div className="media-right text-right">
                              {/* <i class="fas fa-heartbeat fa-edit-icon success"></i> */}
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </Link>
                </div>

                <div className="col-xl-4 col-lg-4 col-md-6 col-12">
                  <Link to="/ExpertRecon">
                    <div className="card bg-white">
                      <div className="card-body">
                        <div className="card-block pt-10 pb-10">
                          <div className="media">
                            <div className="media-body white text-left">
                              <h4 className="font-medium-2 card-title mb-0">
                                Expert Recon Report
                              </h4>
                            </div>
                            <div className="media-right text-right">
                              <i className="icon-wallet font-large-1 warning"></i>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </Link>
                </div>
                <div className="col-xl-4 col-lg-4 col-md-6 col-12">
                  <Link to="/GstRecon">
                    <div className="card bg-white">
                      <div className="card-body">
                        <div className="card-block pt-10 pb-10">
                          <div className="media">
                            <div className="media-body white text-left">
                              <h4 className="font-medium-2 card-title mb-0">
                                GST Recon Report
                              </h4>
                            </div>
                            <div className="media-right text-right">
                              {/* <i class="far fa-comment warning fa-edit-icon"></i> */}
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </Link>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <Footer />
    </div>
  );
};

export default Accounts;
