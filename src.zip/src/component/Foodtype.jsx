import React from "react";
import Navbarside from "./Navbarside";
import { useDispatch } from "react-redux";
import {
    gettypefoods
} from "../store/slices/food";
import { useState } from "react";
import Footer from "./footer";
import { useNavigate, useParams, Link, } from "react-router-dom";

import { ExportToExcel } from "./ExportToExcel";
import { API_PATHS } from "../utils/constants/api.constants";
import axios from "axios";
const Foodtype = () => {
  const [foodrecipestype, setFoodRecipestype] = useState([]);

  const dispatch = useDispatch();

  const [data, setData] = useState([]);
  const fileName = "Food Type";

  React.useEffect(() => {
    const fetchData = () => {
      axios.get(API_PATHS.getfoodtype).then((postData) => {
        const customHeadings = postData.data.data.map((item) => ({
          "Name": item.name,
        
        }));

        setData(customHeadings);
      });
    };
    fetchData();
  }, []);

  React.useEffect(() => {
    dispatch(gettypefoods())
      .unwrap()
      .then((data) => {
        setFoodRecipestype(data.user.data);
      })
      .catch(({ message }) => {
        alert(message);
      });
  }, [dispatch]);


  return (
    <div>
      <Navbarside />

      <div className="container-fluid response-cover pb-5">
        <div className="row">
          <div className="col-lg-2 col-md-4" />
          <div className="col-lg-10 col-md-8">
            <div className="container-fluid pt-5">
              <div className="row">
                <div className="col-12">
                  <div className="card">
                    <div className="card-header">
                      <div className="card-title-wrap bar-success d-flex align-items-center">
                        <h4 className="card-title">Food Type</h4>
                        &nbsp; &nbsp; &nbsp;
                         <Link to="/Weightmanagement/Foodtype/AddFoodtype" className="btn btn-success col-white">Add</Link>
                         &nbsp; &nbsp; &nbsp;
                        <ExportToExcel apiData={data} fileName={fileName} />
                      </div>
                    </div>
                    <div className="card-body collapse show">
                      <div className="card-block card-dashboard table-responsive">
                        <table className="table table-striped table-bordered zero-configuration">
                          <thead>
                            <tr>
                              <th>Food Type Name</th>
                              <th>Action</th>
                            

                            </tr>
                          </thead>

                          <tbody>
                            {foodrecipestype.map((foodcategoryVal, index) => (
                              <tr key={index}>
                                
                                <td>{foodcategoryVal.name}</td>
                               
                        
                             <td className="d-flex justify-content-center"><Link to="" className="btn btn-primary col-white">Edit</Link></td>

                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <Footer />
    </div>
  );
};

export default Foodtype;
