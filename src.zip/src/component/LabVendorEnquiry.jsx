import React from "react";
import Navbarside from "./Navbarside";
import { useDispatch } from "react-redux";
import {
  getlabvendorEnquiry,
  ApprovelabsvendorEnquiry,
} from "../store/slices/lab";
import { useState } from "react";
import Footer from "./footer";
import { ExportToExcel } from "./ExportToExcel";
import { API_PATHS } from "../utils/constants/api.constants";
import axios from "axios";
import Moment from "moment";
const LabVendorEnquiry = () => {
  const [vendor, setVendor] = useState([]);
  const dispatch = useDispatch();
  const [data, setData] = useState([]);
  const fileName = "Lab Vendor Enquiry";

  React.useEffect(() => {
    const fetchData = () => {
      axios.get(API_PATHS.getlabvendorEnquiry).then((postData) => {
        const customHeadings = postData.data.data.map((item) => ({
          Name: item.name,
          Mobile: item.contactNumber,
          Email: item.email,
          Lab_Name: item.labName,
          Address: item.address,
        }));

        setData(customHeadings);
      });
    };
    fetchData();
  }, []);

  React.useEffect(() => {
    dispatch(getlabvendorEnquiry())
      .unwrap()
      .then((data) => {
        setVendor(data.user.data);
      })
      .catch(({ message }) => {
        alert(message);
      });
  }, [dispatch]);

  async function enableApprove(ids) {
    let status = "approved";
    let id = ids;
    let item = { id, status };
    dispatch(ApprovelabsvendorEnquiry(item))
      .unwrap()
      .then(() => {
        alert("Approved succesfully");
        window.location.reload(false);
      })
      .catch(({ message }) => {
        alert(message);
      });
    console.log(item);
    console.log(id);
  }

  async function disableApprove(ids) {
    let status = "rejected";
    let id = ids;
    let item = { id, status };
    localStorage.setItem("item", JSON.stringify(item));
    dispatch(ApprovelabsvendorEnquiry(item))
      .unwrap()
      .then(() => {
        alert("Request rejected succesfully");
        window.location.reload(false);
      })
      .catch(({ message }) => {
        alert(message);
      });
    console.log(item);
    console.log(id);
  }

  return (
    <div>
      <Navbarside />

      <div className="container-fluid response-cover pb-5">
        <div className="row">
          <div className="col-lg-2 col-md-4" />
          <div className="col-lg-10 col-md-8">
            <div className="container-fluid pt-5">
              <div className="row">
                <div className="col-12">
                  <div className="card">
                    <div className="card-header">
                      <div className="card-title-wrap bar-success d-flex align-items-center">
                        <h4 className="card-title">Lab Vendor Enquiry</h4>{" "}
                        &nbsp; &nbsp; &nbsp;
                        <ExportToExcel
                          apiData={data}
                          fileName={fileName}
                          style={{
                            height: "25px",
                            padding: "0 10px",
                            marginBottom: "0%",
                          }}
                        />
                      </div>
                    </div>
                    <div className="card-body collapse show">
                      <div className="card-block card-dashboard table-responsive">
                        <table className="table table-striped table-bordered zero-configuration">
                          <thead>
                            <tr>
                              <th>Owner Deatails</th>
                              <th>Message</th>

                              <th>Lab Name</th>
                              <th>Enquiry Date/ Time</th>
                              <th>NABL Certificate</th>
                              <th>Status</th>
                            </tr>
                          </thead>

                          <tbody>
                            {vendor.map((LabVal, index) => (
                              <tr key={index}>
                                <td>
                                  Name: {LabVal.name}
                                  <br />
                                  Email: {LabVal.email}
                                  <br />
                                  Contact Number: {LabVal.contactNumber}
                                  <br />
                                  Address: {LabVal.address}
                                </td>
                                <td>{LabVal.message}</td>

                                <td>{LabVal.labName}</td>
                                <td>
                                  {" "}
                                  {Moment(LabVal.created_at).format(
                                    "DD-MM-YYYY"
                                  )}
                                  /{" "}
                                  {Moment(LabVal.created_at).format("hh:mm A")}
                                </td>
                                <td>
                                  <a href={LabVal.nablCertificate} download>
                                    Download
                                  </a>
                                </td>
                                <td>
                                  {LabVal.status ===
                                    "labVendorRegistrationRequest" && (
                                    <button
                                      className="btn btn-primary"
                                      style={{
                                        height: "25px",
                                        padding: "0 10px",
                                      }}
                                      onClick={() => enableApprove(LabVal._id)}
                                    >
                                      Approve
                                    </button>
                                  )}
                                  &nbsp;
                                  {LabVal.status ===
                                    "labVendorRegistrationRequest" && (
                                    <button
                                      className="btn btn-warning"
                                      style={{
                                        height: "25px",
                                        padding: "0 10px",
                                      }}
                                      onClick={() => disableApprove(LabVal._id)}
                                    >
                                      Reject
                                    </button>
                                  )}
                                  &nbsp;
                                  {LabVal.status === "rejected" && (
                                    <button
                                      className="btn btn-warning"
                                      style={{
                                        height: "25px",
                                        padding: "0 10px",
                                      }}
                                    >
                                      Rejected
                                    </button>
                                  )}
                                  &nbsp;
                                  {LabVal.status === "approved" && (
                                    <button
                                      className="btn btn-success"
                                      style={{
                                        height: "25px",
                                        padding: "0 10px",
                                      }}
                                    >
                                      Approved
                                    </button>
                                  )}
                                  &nbsp;
                                </td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <Footer />
    </div>
  );
};

export default LabVendorEnquiry;
