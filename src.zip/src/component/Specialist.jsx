import React, { useState } from "react";
import { Link } from "react-router-dom";
import Navbarside from "./Navbarside";
import { useDispatch, useSelector } from "react-redux";
import { getHcExperts } from "../store/slices/hcexpert";
import { useNavigate, useParams } from "react-router-dom";
import Footer from "./footer";
import { enableExpert } from "../store/slices/auth";
import { ExportToExcel } from "./ExportToExcel";
import { API_PATHS } from "../utils/constants/api.constants";
import axios from "axios";

const Specialist = () => {
  const [specialistdetils, setSpecialistdetils] = useState([]);
  const dispatch = useDispatch();

  const [data, setData] = useState([]);
  const fileName = "HCExpert";

  React.useEffect(() => {
    const fetchData = () => {
      axios.get(API_PATHS.getuser).then((postData) => {
        const customHeadings = postData.data.data.map((item) => ({
          "First Name": item.firstName,
          "Last Name": item.lastName,
          "Mobile No.": item.mobileNo,
          Email: item.email,
          Expertise: item.expertise,
        }));

        setData(customHeadings);
      });
    };
    fetchData();
  }, []);

  React.useEffect(() => {
    dispatch(getHcExperts())
      .unwrap()
      .then((data) => {
        setSpecialistdetils(data.user.data);
      })
      .catch(({ message }) => {
        // alert(message);
      });
  }, [dispatch]);

  async function disableApprove(ids) {
    let isAdminApproved = false;
    let id = ids;
    let item = { set: { isAdminApproved } };
    localStorage.setItem("item", JSON.stringify(item));
    localStorage.setItem("expertId", id);
    dispatch(enableExpert(item))
      .unwrap()
      .then(() => {
        alert("Expert disabled succesfully");
        window.location.reload(false);
      })
      .catch(({ message }) => {
        alert(message);
      });
    // console.log(item);
    // console.log(id);
  }

  async function enableApprove(ids) {
    let isAdminApproved = true;
    let id = ids;
    let item = { set: { isAdminApproved } };
    localStorage.setItem("item", JSON.stringify(item));
    localStorage.setItem("expertId", id);
    dispatch(enableExpert(item))
      .unwrap()
      .then(() => {
        alert("Expert approved succesfully");
        window.location.reload(false);
      })
      .catch(({ message }) => {
        alert(message);
      });
    // console.log(item);
    // console.log(id);
  }

  return (
    <div>
      <Navbarside />

      <div className="container-fluid pb-5 response-cover">
        <div className="row">
          <div className="col-lg-2 col-md-4" />
          <div className="col-lg-10 col-md-8">
            <div className="container-fluid pt-5">
              <div className="row">
                <div className="col-12">
                  <div className="card">
                    <div className="card-header">
                      <div className="card-title-wrap bar-success d-flex align-items-center">
                        <h4 className="card-title"> Health Care Expert</h4>{" "}
                        &nbsp; &nbsp; &nbsp;
                        <ExportToExcel
                          apiData={data}
                          fileName={fileName}
                          style={{
                            height: "25px",
                            padding: "0 10px",
                            marginBottom: "0%",
                          }}
                        />
                        &nbsp; &nbsp; &nbsp;
                        <Link
                          to="/AddExpert/6343acb2f427d20b635ec853"
                          className="btn btn-success"
                        >
                          Add Expert
                        </Link>
                      </div>
                    </div>
                    <div className="card-body collapse show">
                      <div className="card-block card-dashboard table-responsive">
                        <table className="table table-striped table-bordered zero-configuration">
                          <thead>
                            <tr>
                              <th>Name</th>
                              <th>Email</th>
                              <th>Mobile Number</th>
                              <th>Is Verified</th>
                              <th>Action</th>
                            </tr>
                          </thead>

                          <tbody>
                            {specialistdetils.map((specialistVal, index) => (
                              <tr key={index}>
                                <td>
                                  <Link
                                    to={`/Expertdetails/${
                                      specialistVal._id
                                        ? specialistVal._id
                                        : null
                                    }`}
                                  >
                                    {specialistVal.firstName}{" "}
                                    {specialistVal.lastName}
                                  </Link>
                                </td>
                                <td>{specialistVal.email}</td>
                                <td>{specialistVal.mobileNo}</td>
                                <td>
                                  {specialistVal.isAdminApproved === false && (
                                    <button
                                      onClick={() =>
                                        enableApprove(specialistVal._id)
                                      }
                                      className="btn btn-warning"
                                      style={{
                                        height: "25px",
                                        padding: "0 10px",
                                      }}
                                    >
                                      Approve
                                    </button>
                                  )}
                                  {specialistVal.isAdminApproved === true && (
                                    <button
                                      className="btn btn-success"
                                      style={{
                                        height: "25px",
                                        padding: "0 10px",
                                      }}
                                    >
                                      Verified
                                    </button>
                                  )}
                                </td>
                                <td>
                                  <Link
                                    to={`/EditExpert/${
                                      specialistVal._id
                                        ? specialistVal._id
                                        : null
                                    }`}
                                    className="btn btn-primary"
                                    style={{
                                      height: "25px",
                                      padding: "0 10px",
                                    }}
                                  >
                                    Edit Profile
                                  </Link>
                                  &nbsp;
                                  {specialistVal.isAdminApproved === true && (
                                    <button
                                      onClick={() =>
                                        disableApprove(specialistVal._id)
                                      }
                                      className="btn btn-warning"
                                      style={{
                                        height: "25px",
                                        padding: "0 10px",
                                      }}
                                    >
                                      Disable
                                    </button>
                                  )}
                                </td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <Footer />
    </div>
  );
};

export default Specialist;
