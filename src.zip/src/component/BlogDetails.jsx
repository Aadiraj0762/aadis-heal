import React, { useState } from "react";

import Navbarside from "./Navbarside";
import Footer from "./footer";
import { getsingleblogs } from "../store/slices/blog";
import { useDispatch, useSelector } from "react-redux";
import { useParams } from "react-router-dom";

import { FaUserCircle } from "react-icons/fa";

const BlogDetails = () => {
  const dispatch = useDispatch();
  const [blogTitle, setblogTitle] = useState("");
  const [mediaLink, setmediaLink] = useState("");
  const [description, setDescription] = useState("");
  const [date, setDate] = useState("");
  const { id } = useParams();
  localStorage.setItem("blogId", id);

  React.useEffect(() => {
    dispatch(getsingleblogs())
      .unwrap()
      .then((data) => {
        if (data.user.data[0]._id === id) {
          setblogTitle(data.user.data[0].blogTitle);
          setmediaLink(data.user.data[0].mediaLink);
          setDescription(data.user.data[0].description);
          setDate(data.user.data[0].date);
        }
      })
      .catch(({ message }) => {
        // alert(message);
      });
  }, [dispatch]);
  return (
    <div>
      <body data-col="2-columns" className=" 2-columns ">
        <Navbarside />

        <div className="container-fluid pb-5 response-cover">
          <div className="row">
            <div className="col-lg-2 col-md-4" />
            <div className="col-lg-10 col-md-8">
              <div className="container-fluid pt-5">
                <div className="row">
                  <div className="col-lg-12 col-sm-12 col-md-12">
                    <div className="post-card mt-2 mb-2">
                      <img
                        src={mediaLink}
                        className="post-image-media"
                        alt=""
                      />
                      <p className="post-name mt-2">{blogTitle}</p>

                      <div className="description-res mt-2">
                        <p className="post-Description">{description}</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <Footer />
      </body>
    </div>
  );
};

export default BlogDetails;
