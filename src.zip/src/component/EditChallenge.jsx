import React, { useState } from "react";
import Navbarside from "./Navbarside";
import { getChallengeDetails, editChallenge } from "../store/slices/challenges";
import { useDispatch } from "react-redux";
import { useNavigate } from "react-router-dom";
import { API_PATHS } from "../utils/constants/api.constants";
import { Link } from "react-router-dom";
import { useParams } from "react-router-dom";
import Moment from "moment";
import { createAsyncThunk, createSlice } from "@reduxjs/toolkit";
import ChallengeService from "../services/challenge.service";
const EditChallenges = (e) => {
  const { id } = useParams();
  localStorage.setItem("challengeId", id);
  const navigate = useNavigate("");
  const dispatch = useDispatch();
  const [challengeCategorys, setchallengeCategorys] = useState([]);
  const [startDate, setStartDate] = useState("");
  const [description, setDescription] = useState("");
  const [endDate, setEndDate] = useState("");
  const [tips, setTips] = useState("");
  const [needToDo, setNeedToDo] = useState("");
  const [name, setName] = useState("");
  const [mediaLink, setmediaLink] = useState("");
  const [shortDescription, setShortDescription] = useState("");
  const [prizeType, setPrizetype] = useState("");
  const [prizeValue, setPrizeValue] = useState("");
  const [details, setDetails] = useState("");
  const [prizemediaLink, setPrizemediaLink] = useState("");
  const [challengeCategoryId, setchallengeCategoryId] = useState([]);
  const [catName, setcatName] = useState("");

  // alert message
  const [alertstartDate, setAlertstartDate] = useState("");
  const [alertdescription, setAlertdescription] = useState("");
  const [alertendDate, setAlertendDate] = useState("");
  const [alerttips, setAlerttips] = useState("");
  const [alertname, setAlertname] = useState("");
  const [alertmediaLink, setAlertmediaLink] = useState("");
  const [alertprizemediaLink, setAlertprizemediaLink] = useState("");
  const [alertshortDescription, setAlertshortDescription] = useState("");
  const [alertprizeType, setAlertprizeType] = useState("");
  const [alertprizeValue, setAlertprizeValue] = useState("");
  const [alertdetails, setAlertdetails] = useState("");
  const [alertneedToDo, setAlertneedToDo] = useState("");

  const save = (e) => {
    const regdate =
      /^([0]?[1-9]|[1|2][0-9]|[3][0|1])[-]([0]?[1-9]|[1][0-2])[-]([0-9]{4}|[0-9]{2})$/;
    if (regdate.test(endDate)) {
      setAlertendDate("");
    } else if (!regdate.test(endDate) && endDate === "") {
      setAlertendDate("Enter any date");
      e.preventDefault();
    } else {
      setAlertendDate("");
    }

    const regdate2 =
      /^([0]?[1-9]|[1|2][0-9]|[3][0|1])[-]([0]?[1-9]|[1][0-2])[-]([0-9]{4}|[0-9]{2})$/;
    if (regdate2.test(startDate)) {
      setAlertstartDate("");
    } else if (!regdate2.test(startDate) && startDate === "") {
      setAlertstartDate("Enter any date");
      e.preventDefault();
    } else {
      setAlertstartDate("");
    }

    const regtextDesc = /^(.|\s)*[a-zA-Z]+(.|\s)*$/;
    if (regtextDesc.test(description)) {
      setAlertdescription("");
    } else if (!regtextDesc.test(description) && description === "") {
      setAlertdescription("Please enter the description");
      e.preventDefault();
    } else {
      setAlertdescription("");
    }

    const regtextTips = /^(([A-Za-z]+[,.]?[ ]?|[a-z]+['-]?|[0-9])+)$/;
    if (regtextTips.test(tips)) {
      setAlerttips("");
    } else if (!regtextTips.test(tips) && tips === "") {
      setAlerttips("Please enter the tips");
      e.preventDefault();
    } else {
      setAlerttips("Single and double quotes are not-valid");
      e.preventDefault();
    }

    const regtextvalue =
      /^(([A-Za-z]+[,.]?[ ]?|[a-z]+['-]?|[0-9]+[ ]?|[/-])+)$/;
    if (regtextvalue.test(prizeValue)) {
      setAlertprizeValue("");
    } else if (!regtextvalue.test(prizeValue) && prizeValue === "") {
      setAlertprizeValue("Please enter the Prize Value");
      e.preventDefault();
    } else {
      setAlertprizeValue("Single and double quotes are not-valid");
      e.preventDefault();
    }

    const regtextType = /^(([A-Za-z]+[,.]?[ ]?|[a-z]+['-]?|[0-9]+[ ]?|[/-])+)$/;
    if (regtextType.test(prizeType)) {
      setAlertprizeType("");
    } else if (!regtextType.test(prizeType) && prizeType === "") {
      setAlertprizeType("Please enter the Prize type");
      e.preventDefault();
    } else {
      setAlertprizeType("Single and double quotes are not-valid");
      e.preventDefault();
    }

    const regtextDetails = /^(([A-Za-z]+[,.]?[ ]?|[a-z]+['-]?|[0-9])+)$/;
    if (regtextDetails.test(details)) {
      setAlertdetails("");
    } else if (!regtextDetails.test(details) && details === "") {
      setAlertdetails("Please enter the details");
      e.preventDefault();
    } else {
      setAlertdetails("Single and double quotes are not-valid");
      e.preventDefault();
    }

    const regtextName = /^(([A-Za-z]+[,.]?[ ]?|[a-z]+['-]?|[0-9])+)$/;
    if (regtextName.test(name)) {
      setAlertname("");
    } else if (!regtextName.test(name) && name === "") {
      setAlertname("Please enter the name");
      e.preventDefault();
    } else {
      setAlertname("Single and double quotes are not-valid");
      e.preventDefault();
    }

    const regimage = /(gif|jpe?g|tiff?|png|webp|bmp)$/i;
    if (regimage.test(mediaLink)) {
      setAlertmediaLink("");
    } else if (!regimage.test(mediaLink) && mediaLink === "") {
      setAlertmediaLink("Please enter valid media file");
      e.preventDefault();
    } else {
      setAlertmediaLink("");
    }

    const regimage2 = /(gif|jpe?g|tiff?|png|webp|bmp)$/i;
    if (regimage2.test(prizemediaLink)) {
      setAlertprizemediaLink("");
    } else if (!regimage2.test(prizemediaLink) && prizemediaLink === "") {
      setAlertprizemediaLink("Please enter valid media file");
      e.preventDefault();
    } else {
      setAlertprizemediaLink("");
    }

    const regtextdes2 = /^(.|\s)*[a-zA-Z]+(.|\s)*$/;
    if (regtextdes2.test(shortDescription)) {
      setAlertshortDescription("");
    } else if (!regtextdes2.test(shortDescription) && shortDescription === "") {
      setAlertshortDescription("Please enter the short-description");
      e.preventDefault();
    } else {
      setAlertshortDescription("");
    }

    const regtextDo = /^(([A-Za-z]+[,.]?[ ]?|[a-z]+['-]?|[0-9])+)$/;
    if (regtextDo.test(needToDo)) {
      setAlertneedToDo("");
    } else if (!regtextDo.test(needToDo) && needToDo === "") {
      setAlertneedToDo("Please enter need to do");
      e.preventDefault();
    } else {
      setAlertneedToDo("Single and double quotes are not-valid");
      e.preventDefault();
    }
  };

  const clear = () => {
    setStartDate("");
    setDescription("");
    setEndDate("");
    setTips("");
    setNeedToDo("");
    setName("");
    setmediaLink("");
    setShortDescription("");
    setPrizetype("");
    setPrizeValue("");
    setDetails("");
    setPrizemediaLink("");
    setAlertstartDate("");
    setAlertdescription("");
    setAlertendDate("");
    setAlerttips("");
    setAlertname("");
    setAlertmediaLink("");
    setAlertprizemediaLink("");
    setAlertshortDescription("");
    setAlertneedToDo("");
    setAlertprizeType("");
    setAlertprizeValue("");
    setAlertdetails("");
  };

  React.useEffect(() => {
    dispatch(getChallengeDetails())
      .unwrap()
      .then((data) => {
        if (data.user.data[0]._id === id) {
          setStartDate(data.user.data[0].startDate);
          setDescription(data.user.data[0].description);
          setEndDate(data.user.data[0].endDate);
          setTips(data.user.data[0].tips);
          setNeedToDo(data.user.data[0].needToDo);
          setName(data.user.data[0].name);
          setmediaLink(data.user.data[0].mediaLink);
          setShortDescription(data.user.data[0].shortDescription);
          setPrizetype(data.user.data[0].prize.prizeType);
          setDetails(data.user.data[0].prize.details);
          setPrizemediaLink(data.user.data[0].prize.mediaLink);
          setPrizeValue(data.user.data[0].prize.prizeValue);
          //setcatName(data.user.data[0].categoryId.categoryName);
        }
      })
      .catch(({ message }) => {
        alert(message);
      });
  }, [dispatch]);

  let sdate = Moment(startDate).format("DD-MM-YYYY");
  async function imageUpload(e) {
    e.preventDefault();
    var formdata = new FormData();
    formdata.append("file", e.target.files[0]);

    var requestOptions = {
      method: "POST",
      body: formdata,
      redirect: "follow",
    };
    let response = await fetch(API_PATHS.uploadImage, requestOptions);
    let data = await response.json();
    setmediaLink(data.data.location);
  }

  async function imageUpload2(e) {
    e.preventDefault();
    var formdata = new FormData();
    formdata.append("file", e.target.files[0]);

    var requestOptions = {
      method: "POST",
      body: formdata,
      redirect: "follow",
    };
    let response = await fetch(API_PATHS.uploadImage, requestOptions);
    let data = await response.json();
    setPrizemediaLink(data.data.location);
  }

  async function addData(e) {
    e.preventDefault();
    let prize = {
      prizeType,
      prizeValue,
      details,
    };

    let item = {
      set: {
        startDate,
        description,
        endDate,
        tips,
        name,
        mediaLink,
        shortDescription,
        needToDo,
        prize,
      },
    };
    dispatch(editChallenge(item))
      .unwrap()
      .then(() => {
        alert("Updated succesfully");
        navigate("/Challenges");
      })
      .catch(({ message }) => {
        alert(message);
      });
  }
  const ChallengeCategorys = createAsyncThunk(
    "expertise/get/expertise",
    async (thunkAPI) => {
      try {
        // console.log("consultation")
        const data = await ChallengeService.getChallengeCategories();
        return { user: data };
      } catch (error) {
        const sessionCount =
          (error.response &&
            error.response.data &&
            error.response.data.sessionCount) ||
          error.sessionCount ||
          error.toString();
        return thunkAPI.rejectWithValue({ sessionCount });
      }
    }
  );

  React.useEffect(() => {
    dispatch(ChallengeCategorys())
      .unwrap()
      .then((data) => {
        setchallengeCategorys(data.user.data);
        setchallengeCategoryId(data.user.data[0]._id);
      })
      .catch(({ sessionCount }) => {
        alert(sessionCount);
      });
  }, [dispatch]);

  return (
    <body data-col="2-columns" className=" 2-columns ">
      <Navbarside />

      <div className="container-fluid pb-5 response-cover">
        <div className="row">
          <div className="col-lg-2 col-md-4" />
          <div className="col-lg-10 col-md-8">
            <div className="container-fluid pt-5">
              <div className="row">
                <div className="col-12">
                  <div className="card">
                    <div className="card-header">
                      <div className="card-title-wrap bar-danger d-flex align-items-center">
                        <h4 className="card-title">Edit Challenge</h4>
                      </div>
                    </div>

                    <section className="form-section">
                      <form onSubmit={addData}>
                        <div className="row">
                          <div className="col-md-6 pt-3 pb-2">
                            <span>Name</span>
                            <input
                              type="text"
                              placeholder="Enter  Name"
                              className="form-control"
                              value={name}
                              required
                              onChange={(e) => setName(e.target.value)}
                            />
                            <p className="alert-message">{alertname}</p>
                          </div>
                          {/* <div className="col-md-6 pt-3">
                            <span>Challenge Category</span>
                            <select
                              value={catName}
                              className="form-control"
                              onChange={handleCategoryChange}
                              required
                            >
                              <option value="">Select</option>
                              {challengeCategorys.map((option) => (
                                <option value={option.expertiseId}>
                                  {option.name}
                                </option>
                              ))}
                            </select>
                            <p className="alert-message"></p>
                          </div> */}
                          <div className="col-md-12 pt-3 pb-2">
                            <span>Description</span>
                            <textarea
                              placeholder="Enter  Description"
                              className="form-control"
                              value={description}
                              required
                              onChange={(e) => setDescription(e.target.value)}
                            />
                            <p className="alert-message">{alertdescription}</p>
                          </div>

                          <div className="col-md-6 pt-3 pb-2">
                            <span>Short Description</span>
                            <input
                              type="text"
                              placeholder="Enter  Description"
                              className="form-control"
                              value={shortDescription}
                              required
                              onChange={(e) =>
                                setShortDescription(e.target.value)
                              }
                            />
                            <p className="alert-message">
                              {alertshortDescription}
                            </p>
                          </div>

                          <div className="col-md-6 pt-2 pb-2">
                            <span>Image</span>
                            <br />
                            <img
                              src={mediaLink}
                              alt=""
                              style={{
                                height: "100px",
                                width: "120px",
                                marginBottom: "10px",
                              }}
                            />
                            <br />
                            <input
                              type="file"
                              className="form-control"
                              Placeholder="Price Tagline"
                              name="imageUrl"
                              onChange={(e) => imageUpload(e)}
                            />
                            <p className="alert-message">{alertmediaLink}</p>
                          </div>

                          <div className="col-md-6 pt-3 pb-2">
                            <span>Prize type</span>
                            <input
                              type="text"
                              placeholder="Enter Need to do"
                              className="form-control"
                              value={prizeType}
                              required
                              onChange={(e) => setPrizetype(e.target.value)}
                            />
                            <p className="alert-message">{alertprizeType}</p>
                          </div>

                          <div className="col-md-6 pt-3 pb-2">
                            <span>Prize Value</span>
                            <input
                              type="text"
                              placeholder="Enter Need to do"
                              className="form-control"
                              value={prizeValue}
                              required
                              onChange={(e) => setPrizeValue(e.target.value)}
                            />
                            <p className="alert-message">{alertprizeValue}</p>
                          </div>

                          <div className="col-md-6 pt-3 pb-2">
                            <span>Details</span>
                            <input
                              type="text"
                              placeholder="Enter  details"
                              className="form-control"
                              value={details}
                              onChange={(e) => setDetails(e.target.value)}
                            />
                            <p className="alert-message">{alertdetails}</p>
                          </div>

                          <div className="col-md-6 pt-2 pb-2">
                            <span>Prize Image</span>
                            <br />
                            <img
                              src={prizemediaLink}
                              alt=""
                              style={{
                                height: "100px",
                                width: "120px",
                                marginBottom: "10px",
                              }}
                            />
                            <br />
                            <input
                              type="file"
                              className="form-control"
                              Placeholder="Price Tagline"
                              name="imageUrl"
                              onChange={(e) => imageUpload2(e)}
                            />
                            <p className="alert-message">
                              {alertprizemediaLink}
                            </p>
                          </div>

                          <div className="col-md-6 pt-3 pb-2">
                            <span>Start Date </span>
                            <input
                              type="date"
                              className="form-control"
                              value={Moment(startDate).format("YYYY-MM-DD")}
                              // required
                              onChange={(e) => setStartDate(e.target.value)}
                            />
                            <p className="alert-message">{alertstartDate}</p>
                          </div>

                          <div className="col-md-6 pt-3 pb-2">
                            <span>End Date</span>
                            <input
                              type="date"
                              className="form-control"
                              value={Moment(endDate).format("YYYY-MM-DD")}
                              // required
                              onChange={(e) => setEndDate(e.target.value)}
                            />
                            <p className="alert-message">{alertendDate}</p>
                          </div>

                          <div className="col-md-6 pt-3 pb-2">
                            <span>Tips</span>
                            <input
                              type="text"
                              placeholder="Enter Tips"
                              className="form-control"
                              value={tips}
                              required
                              onChange={(e) => setTips(e.target.value)}
                            />
                            <p className="alert-message">{alerttips}</p>
                          </div>

                          <div className="col-md-6 pt-3 pb-2">
                            <span>Need to Do</span>
                            <input
                              type="text"
                              placeholder="Enter Tips"
                              className="form-control"
                              value={needToDo}
                              required
                              onChange={(e) => setNeedToDo(e.target.value)}
                            />
                            <p className="alert-message">{alertneedToDo}</p>
                          </div>

                          <div className="col-md-3" />
                          <div className="col-md-12" align="center">
                            <br />
                            <button
                              onClick={save}
                              type="submit"
                              className="btn btn-primary"
                              style={{ width: "150px" }}
                              disabled={!mediaLink}
                            >
                              Update
                            </button>
                            &nbsp;
                            <button
                              type="reset"
                              onClick={clear}
                              className="btn btn-danger"
                              style={{ width: "150px" }}
                            >
                              Cancel
                            </button>
                          </div>
                        </div>
                      </form>
                    </section>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </body>
  );
};

export default EditChallenges;
