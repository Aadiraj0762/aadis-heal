import React, { useState, useRef } from "react";
import { useDispatch, useSelector } from "react-redux";
import Navbarside from "../component/Navbarside";
import Footer from "./footer";
import Moment from "moment";
import { AppointmentAnalysisDetails } from "../store/slices/analysis";
import { useDownloadExcel } from "react-export-table-to-excel";

const AppointmentAnalysis = () => {
  const [startDate, setstartDate] = useState("");
  const [endDate, setendDate] = useState("");
  const tableRef = useRef(null);

  const dispatch = useDispatch();

  const [data, setData] = useState([]);
  async function analysisData(e) {
    e.preventDefault();
    let item = { startDate, endDate };
    localStorage.setItem("item", JSON.stringify(item));
    dispatch(AppointmentAnalysisDetails())
      .unwrap()
      .then((data) => {
        setData(data.user.data);
      })
      .catch(({ message }) => {
        // alert(message);
      });
  }

  const { onDownload } = useDownloadExcel({
    currentTableRef: tableRef.current,
    filename: "Appointment Analysis Report",
    sheet: "Sheet1",
  });

  return (
    <div>
      <Navbarside />

      <div className="container-fluid pb-5 response-cover">
        <div className="row">
          <div className="col-lg-2 col-md-4" />
          <div className="col-lg-10 col-md-8">
            <div className="container-fluid pt-5">
              <div className="row">
                <div className="col-12">
                  <div className="card">
                    <div className="card-header">
                      <div className="card-title-wrap bar-success d-flex align-items-center">
                        <h4 className="card-title">
                          Appointment Analysis Report
                        </h4>
                      </div>
                    </div>
                    <section className="form-section">
                      <form onSubmit={analysisData}>
                        <div className="row">
                          <div className="col-md-4 col-sm-12 pt-2">
                            <p
                              className="col-black"
                              style={{ marginBottom: "2px" }}
                            >
                              From Date
                            </p>
                            <input
                              type="date"
                              placeholder="Enter the recipe name"
                              value={startDate}
                              onChange={(e) => setstartDate(e.target.value)}
                              className="form-control"
                            />
                            <p className="alert-message"></p>
                          </div>
                          <div className="col-md-4 col-sm-12 pt-2">
                            <p
                              className="col-black"
                              style={{ marginBottom: "2px" }}
                            >
                              To Date
                            </p>
                            <input
                              type="date"
                              placeholder="Enter the recipe name"
                              value={endDate}
                              onChange={(e) => setendDate(e.target.value)}
                              className="form-control"
                            />
                            <p className="alert-message"></p>
                          </div>
                          <div className="col-md-4 col-sm-12 pt-2 mt-3">
                            <button type="submit" className="btn btn-primary">
                              Submit
                            </button>
                          </div>
                        </div>
                      </form>
                    </section>
                    <div className="card-body collapse show">
                      <div className="card-block card-dashboard table-responsive">
                        {data !== "" && (
                          <div>
                            <button
                              onClick={onDownload}
                              className="btn btn-primary"
                            >
                              Export to Excel
                            </button>
                            <table
                              className="table table-striped table-bordered zero-configuration"
                              ref={tableRef}
                            >
                              <thead>
                                <tr>
                                  <th>Appointment Date</th>
                                  <th>Appointment Time</th>
                                  <th>Category</th>
                                  {/* <th>Created By</th> */}
                                  <th>Appointment Status</th>
                                  <th>Appointment Assigned to Expert</th>
                                  <th>User Name</th>
                                </tr>
                              </thead>

                              <tbody>
                                {data.map((dataVal, index) => (
                                  <tr>
                                    <td>
                                      {" "}
                                      {Moment(dataVal.created_at).format(
                                        "DD-MM-YYYY"
                                      )}
                                    </td>
                                    <td>
                                      {Moment(dataVal.created_at).format(
                                        "hh:mm A"
                                      )}
                                    </td>

                                    <td>{dataVal.category}</td>
                                    <td>{dataVal.status}</td>
                                    <td>
                                      <p>
                                        {dataVal.expertId == null
                                          ? null
                                          : dataVal.expertId[0].firstName}
                                        &nbsp;
                                        {dataVal.expertId
                                          ? dataVal.expertId[0].lastName
                                          : null}
                                      </p>
                                    </td>
                                    <td>
                                      {dataVal.userId[0].firstName
                                        ? dataVal.userId[0].firstName
                                        : null}
                                      &nbsp;
                                      {dataVal.userId[0].lastName
                                        ? dataVal.userId[0].lastName
                                        : null}
                                    </td>
                                  </tr>
                                ))}
                              </tbody>
                            </table>
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <Footer />
    </div>
  );
};

export default AppointmentAnalysis;
