import React from "react";
import Navbarside from "./Navbarside";
import Footer from "./footer";
import { Link } from "react-router-dom";
const Physiotherapy = () => {
  return (
    <div>
      <Navbarside />
      <div className="container-fluid pb-5 response-cover">
        <div className="row">
          <div className="col-lg-2 col-md-4" />
          <div className="col-lg-10 col-md-8">
            <div className="container-fluid pt-5">
              <div className="row">
                <div className="col-xl-3 col-lg-3 col-md-6 col-12">
                  <Link to="/PhysioExpert">
                    <div className="card bg-white">
                      <div className="card-body">
                        <div className="card-block pt-10 pb-10">
                          <div className="media">
                            <div className="media-body white text-left">
                              <h4 className="font-medium-2 card-title mb-0">
                                Experts
                              </h4>
                            </div>
                            <div className="media-right text-right">
                              <i className="fas fa-user-tie fa-edit-icon success"></i>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </Link>
                </div>

                <div className="col-xl-3 col-lg-3 col-md-6 col-12">
                  <Link to="/Physiotherapy/PhysioEnquiry">
                    <div className="card bg-white">
                      <div className="card-body">
                        <div className="card-block pt-10 pb-10">
                          <div className="media">
                            <div className="media-body white text-left">
                              <h4 className="font-medium-2 card-title mb-0">
                                General Enquiry
                              </h4>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </Link>
                </div>
                <div className="col-xl-4 col-lg-4 col-md-6 col-12">
                  <Link to="/Physiotherapy/PhysiotherapyEnquiry">
                    <div className="card bg-white">
                      <div className="card-body">
                        <div className="card-block pt-10 pb-10">
                          <div className="media">
                            <div className="media-body white text-left">
                              <h4 className="font-medium-2 card-title mb-0">
                                Physiotherapy Enquiry
                              </h4>
                            </div>
                            <div className="media-right text-right">
                              <i class="fas fa-comment-medical fa-edit-icon danger"></i>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </Link>
                </div>
                <div className="col-xl-3 col-lg-3 col-md-6 col-12">
                  <Link to="/Physiotherapy/HealthConditions">
                    <div className="card bg-white">
                      <div className="card-body">
                        <div className="card-block pt-10 pb-10">
                          <div className="media">
                            <div className="media-body white text-left">
                              <h4 className="font-medium-2 card-title mb-0">
                                Health Conditions
                              </h4>
                            </div>
                            <div className="media-right text-right">
                              <i class="fas fa-comment-medical fa-edit-icon danger"></i>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </Link>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <Footer />
    </div>
  );
};

export default Physiotherapy;
