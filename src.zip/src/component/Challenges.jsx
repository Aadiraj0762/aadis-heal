import React, { useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import Navbarside from "./Navbarside";
import { Link } from "react-router-dom";
import Footer from "./footer";
import { getChallenge, deleteChallenge } from "../store/slices/challenges";
import { confirmAlert } from "react-confirm-alert";
import $ from "jquery";

function Challenges() {
  const dispatch = useDispatch();

  React.useEffect(() => {
    dispatch(getChallenge())
      .unwrap()
      .then((data) => {
        $("#example").DataTable({
          data: data.user.data.map((e, index) => {
            return { index, ...e };
          }),
          columns: [
            {
              title: "#",
              render: (data, type, row) => {
                return ++row.index;
              },
            },
            {
              data: "name",
              title: "Name",
            },
            {
              data: "description",
              title: "Description",
            },
            {
              title: "Status",
              render: (data, type, row) => {
                if (row.isActive === true) {
                  return `<button class="btn btn-success" style="height: 25px; padding: 0 10px">Active</button>`;
                } else {
                  return `<button class="btn btn-danger" style="height: 25px; padding: 0 10px">Inactive</button>`;
                }
              },
            },
            {
              title: "Action",
              render: (data, type, row) => {
                return `<a href="/EditChallenge/${row._id ? row._id : null}"
                  class="btn btn-primary"
                  style="height: 25px; padding: 0 10px"
                >
                Edit
                </a>
                <button
                data-id="${row._id}"
                class="btn btn-warning delete"
                style="height: 25px; padding: 0 10px"
              >
                Delete
              </button>`;
              },
            },
          ],
          destroy: true,
        });
      })
      .catch(({ message }) => {
        // alert(message);
      });

    $("#example").on("click", ".delete", function (e) {
      e.stopPropagation();
      deleteData($(this).data("id"));
    });
  }, [dispatch]);

  const Delete = async function deletePlaylist(id) {
    localStorage.setItem("id", id);
    dispatch(deleteChallenge())
      .unwrap()
      .then(() => {
        // alert("Uploaded succesfully");
        window.location.reload(false);
      })
      .catch(({ message }) => {
        alert(message);
      });

    console.log(id);
  };
  const deleteData = (id) => {
    confirmAlert({
      title: "Want to delete?",
      message: "Are you sure you want to delete this post?",
      buttons: [
        {
          label: "Yes",
          onClick: () => Delete(id),
        },
        {
          label: "No",
          //onClick: () => alert('Click No')
        },
      ],
    });
  };

  return (
    <body data-col="2-columns" className=" 2-columns ">
      <Navbarside />

      <div className="container-fluid pb-5 response-cover">
        <div className="row">
          <div className="col-lg-2 col-md-4" />
          <div className="col-lg-10 col-md-8">
            <div className="container-fluid pt-5">
              <div className="row">
                <div className="col-12">
                  <div className="card">
                    <div className="card-header">
                      <div className="card-title-wrap bar-success d-flex align-items-center">
                        <h4 className="card-title">Challenges</h4>
                        &nbsp; &nbsp;
                        <Link
                          to="/AddChallenge"
                          className="btn btn-primary"
                          style={{ marginBottom: "0%" }}
                        >
                          <i className="fa fa-plus"></i> Add
                        </Link>{" "}
                      </div>
                    </div>
                    <div className="card-body collapse show">
                      <div className="card-block card-dashboard table-responsive">
                        <table id="example" className="display"></table>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <Footer />
    </body>
  );
}

export default Challenges;
