import React, { useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import Navbarside from "./Navbarside";
import { Link, useNavigate } from "react-router-dom";
import Footer from "./footer";
import { postcontent, getCategoryDetails } from "../store/slices/livewell";
import { API_PATHS } from "../utils/constants/api.constants";
import { useParams } from "react-router-dom";
const AddContent = () => {
  const navigate = useNavigate("");
  const dispatch = useDispatch();
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [masterCategoryId, setmasterCategoryId] = useState("");
  const [mediaLink, setmediaLink] = useState("");
  const [format, setFormat] = useState();
  const [thumbnail, setThumbnail] = useState();

  const [alerttitle, setAlertTitle] = useState("");
  const [alertitle, setAlertitle] = useState("");
  const [alertdescription, setAlertdescription] = useState("");
  const [alertmediaLink, setAlertmediaLink] = useState("");
  const [alertformat, setAlertformat] = useState("");

  const [message, setMessage] = useState("");
  const { id } = useParams();
  localStorage.setItem("id", id);
  localStorage.setItem("pid", id);
  let categoryId = localStorage.getItem("id");

  // const save = (e) => {
  //   const regname = /^(([A-Za-z]+[,.]?[ ]?|[a-z]+['-]?|[0-9])+)$/;
  //   if (regname.test(title)) {
  //     setAlertTitle("");
  //   } else if (!regname.test(title) && title === "") {
  //     setAlertTitle("Please enter the content name");
  //     e.preventDefault();
  //   } else {
  //     setAlertTitle("Single and double quotes are not-valid");
  //     e.preventDefault();
  //   }

  //   const regdescription = /^(.|\s)*[a-zA-Z]+(.|\s)*$/;
  //   if (regdescription.test(description)) {
  //     setAlertDescription("");
  //   } else if (!regdescription.test(description) && description === "") {
  //     setAlertDescription("Please enter the Description");
  //     e.preventDefault();
  //   } else {
  //     setAlertDescription("");
  //   }

  //   const regimage = /(gif|jpe?g|tiff?|png|webp|bmp)$/i;
  //   if (regimage.test(mediaLink)) {
  //     setAlertmediaLink("");
  //   } else if (!regimage.test(mediaLink) && mediaLink === "") {
  //     setAlertmediaLink("Please enter image link");
  //     e.preventDefault();
  //   } else {
  //     setAlertmediaLink("Invalid file");
  //     e.preventDefault();
  //   }
  // };

  const clear = () => {
    setTitle("");
    setDescription("");
    setmediaLink("");
    setAlertitle("");
    setAlertdescription("");
    setAlertmediaLink("");
    setThumbnail("");
  };

  async function addData(e) {
    e.preventDefault();
    let item = {
      title,
      description,
      mediaLink,
      categoryId,
      format,
      thumbnail,
      masterCategoryId,
    };
    dispatch(postcontent(item))
      .unwrap()
      .then(() => {
        alert("Uploaded succesfully");
        // navigate("/Dailies");
        navigate(-1);
      })
      .catch(({ message }) => {
        alert(message);
      });
  }
  async function imageUpload(e) {
    e.preventDefault();
    var formdata = new FormData();
    formdata.append("file", e.target.files[0]);

    var requestOptions = {
      method: "POST",
      body: formdata,
      redirect: "follow",
    };
    let response = await fetch(API_PATHS.uploadImage, requestOptions);
    let data = await response.json();
    setThumbnail(data.data.location);
  }

  React.useEffect(() => {
    dispatch(getCategoryDetails())
      .unwrap()
      .then((data) => {
        setmasterCategoryId(data.user.data[0].parentCategoryId);
      })
      .catch(({ message }) => {
        alert(message);
      });
  }, [dispatch]);
  return (
    <body data-col="2-columns" className=" 2-columns ">
      <Navbarside />

      <div className="container-fluid pb-5 response-cover">
        <div className="row">
          <div className="col-lg-2 col-md-4" />
          <div className="col-lg-10 col-md-8">
            <div className="container-fluid pt-5">
              <div className="row">
                <div className="col-12">
                  <div className="card">
                    <div className="card-header">
                      <div className="card-title-wrap bar-danger d-flex align-items-center">
                        <h4 className="card-title">
                          Add Content
                          {/* <Link
                              to="/UploadPackage"
                              className="btn btn-primary"
                            >
                              <i className="fa fa-plus"></i> Add
                            </Link> */}
                        </h4>
                      </div>
                    </div>

                    <section className="form-section">
                      <form onSubmit={addData}>
                        <div className="row">
                          <div className="col-md-8 pt-2 pb-3">
                            <span className="label">Name</span>
                            <input
                              type="text"
                              placeholder="Enter content name"
                              className="form-control"
                              value={title}
                              onChange={(e) => setTitle(e.target.value)}
                            />
                            <p className="alert-message">{alertitle}</p>
                          </div>
                          <div className="col-md-4 pt-2 pb-3">
                            <span className="label">Content Type</span>
                            <select
                              className="form-control"
                              onChange={(e) => setFormat(e.target.value)}
                            >
                              <option value="">Select</option>
                              <option>Audio</option>
                              <option>Video</option>
                              <option>Pdf file</option>
                            </select>

                            <p className="alert-message">{alertformat}</p>
                          </div>

                          <div className="col-md-12 pt-2 pb-3">
                            <span className="label">Description</span>
                            <textarea
                              placeholder="Enter description"
                              className="form-control"
                              value={description}
                              rows="5"
                              onChange={(e) => setDescription(e.target.value)}
                            />
                            <p className="alert-message">{alertdescription}</p>
                          </div>
                          <div className="col-md-4 pt-2 pb-3">
                            <span className="label">Thumbnail</span>
                            <input
                              type="file"
                              className="form-control"
                              Placeholder="Enter content link"
                              name="mediaLink"
                              onChange={(e) => imageUpload(e)}
                            />
                          </div>
                          <div className="col-md-8 pt-2 pb-3">
                            <span className="label">Content Link</span>
                            <input
                              type="text"
                              className="form-control"
                              Placeholder="Enter content link"
                              name="format"
                              onChange={(e) => setmediaLink(e.target.value)}
                            />
                            <p className="alert-message">{alertmediaLink}</p>
                          </div>
                          <div className="col-md-12" align="center">
                            <br />
                            <button
                              type="submit"
                              className="btn btn-primary"
                              style={{ width: "150px" }}
                              // disabled={!message}
                              // onClick={save}
                            >
                              Submit
                            </button>
                            &nbsp;
                            <button
                              type="reset"
                              onClick={clear}
                              className="btn btn-danger"
                              style={{ width: "150px" }}
                            >
                              Reset
                            </button>
                          </div>
                        </div>
                      </form>
                    </section>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <Footer />
    </body>
  );
};

export default AddContent;
