import React, { useState } from "react";
import { useDispatch } from "react-redux";
import Navbarside from "./Navbarside";
import { useNavigate, useParams } from "react-router-dom";
import Footer from "./footer";
import { editEnquiry, enquiryDetails } from "../store/slices/enquiry";

const UpdateEnquiry = () => {
  const [status, setStatus] = useState("");
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const navigate = useNavigate("");
  const dispatch = useDispatch();
  const cancel = () => {
    navigate(-1);
  };

  const { id } = useParams();
  localStorage.setItem("enquiryId", id);

  React.useEffect(() => {
    dispatch(enquiryDetails())
      .unwrap()
      .then((data) => {
        if (data.user.data[0]._id == id) {
          setName(data.user.data[0].name);
          setEmail(data.user.data[0].email);
        }
      })
      .catch(({ message }) => {
        // alert(message);
      });
  }, [dispatch]);

  async function upload(e) {
    e.preventDefault();
    let item = {
      id,
      status,
      email,
      name,
    };

    dispatch(editEnquiry(item))
      .unwrap()
      .then(() => {
        alert("Enquiry status updated succesfully");
        navigate(-1);
      })
      .catch(({ message }) => {
        alert(message);
      });
  }

  return (
    <body data-col="2-columns" className=" 2-columns ">
      <Navbarside />

      <div className="container-fluid pb-5 response-cover">
        <div className="row">
          <div className="col-lg-2 col-md-4" />
          <div className="col-lg-10 col-md-8">
            <div className="container-fluid pt-5">
              <div className="row">
                <div className="col-12">
                  <div className="card">
                    <div className="card-header">
                      <div className="card-title-wrap bar-danger d-flex align-items-center">
                        <h4 className="card-title">Update Enquiry</h4>
                      </div>
                    </div>

                    <section className="form-section">
                      <form onSubmit={upload}>
                        <div className="row">
                          <div className="col-md-6 col-sm-12 pt-2">
                            <label>Status</label>
                            <select
                              name="health"
                              id="health"
                              className="form-control"
                              value={status}
                              onChange={(e) => setStatus(e.target.value)}
                            >
                              <option value="" className="">
                                Select
                              </option>
                              <option>Interested</option>
                              <option>Not Interested</option>
                              <option>Invalid Enquiry</option>
                              <option>Other</option>
                            </select>
                          </div>
                        </div>

                        <div className="d-flex justify-content-center pt-3">
                          <button type="submit" className="btn btn-primary">
                            Submit
                          </button>
                          &nbsp; &nbsp; &nbsp;
                          <button
                            type="reset"
                            className="btn btn-warning"
                            onClick={cancel}
                          >
                            Cancel
                          </button>
                        </div>
                      </form>
                    </section>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <Footer />
    </body>
  );
};

export default UpdateEnquiry;
