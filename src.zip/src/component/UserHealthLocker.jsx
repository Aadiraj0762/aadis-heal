import React from "react";
import Navbarside from "./Navbarside";
import { useDispatch } from "react-redux";
import { userhealthLocker } from "../store/slices/forms";
import { useState } from "react";
import Footer from "./footer";
import Moment from "moment";

import { Link, useParams } from "react-router-dom";

const UserHealthLocker = () => {
  const { id } = useParams();
  localStorage.setItem("clientId", id);
  const [WeightLog, setWeightLog] = useState([]);
  const dispatch = useDispatch();

  React.useEffect(() => {
    dispatch(userhealthLocker())
      .unwrap()
      .then((data) => {
        setWeightLog(data.user.data);
      })
      .catch(({ message }) => {
        alert(message);
      });
  }, [dispatch]);

  return (
    <div>
      <Navbarside />

      <div className="container-fluid response-cover pb-5">
        <div className="row">
          <div className="col-lg-2 col-md-4" />
          <div className="col-lg-10 col-md-8">
            <div className="container-fluid pt-5">
              <div className="row">
                <div className="col-12">
                  <div className="card">
                    <div className="card-header">
                      <div className="card-title-wrap bar-success d-flex align-items-center">
                        <h4 className="card-title">User Health Locker</h4>
                      </div>
                    </div>
                    <div className="card-body collapse show">
                      <div className="card-block card-dashboard table-responsive">
                        <table className="table table-striped table-bordered zero-configuration">
                          <thead>
                            <tr>
                              <th>Date of Report</th>
                              <th>Report Type</th>
                              <th>Report Name</th>
                              <th>Action</th>
                            </tr>
                          </thead>

                          <tbody>
                            {WeightLog.map((reportVal, index) => (
                              <tr key={index}>
                                <td>
                                  {Moment(reportVal.date).format("DD-MM-YYYY")}
                                </td>
                                <td>{reportVal.reportType}</td>
                                <td>{reportVal.reportName}</td>
                                <td>
                                  <a href={reportVal.mediaLink} target="_blank">
                                    View
                                  </a>
                                </td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <Footer />
    </div>
  );
};

export default UserHealthLocker;
