// import React, { useState } from 'react';
// import axios from 'axios';

// const CreateDishForm = () => {
//   const [formData, setFormData] = useState({
//     name: '',
//     foodTypeId: '',
//     foodCategoryId: '',
//     foodSubCategoryId: '',
//     perUnit: {
//       weight: '',
//       calories: 0,
//       quantity: '',
//       weightIn: '',
//       weightInGm: '',
//     },
//     nutrition: [
//       { proteins: { quantity: 0 } },
//       { carbs: { quantity: 0 } },
//       { fats: { quantity: 0 } },
//       { fiber: { quantity: 0 } },
//     ],
//     nutritionInGm: {
//       proteins: 0,
//       carbs: 0,
//       fats: 0,
//       fiber: 0,
//     },
//     mediaLink: '',
//     unit: 0,
//     isVeg: true,
//     source: '',
//   });

//   const handleSubmit = async (event) => {
//     event.preventDefault();

//     try {
//       await axios.post('/api/dishes', formData);
//       console.log('Dish created successfully!');
//       // Reset the form
//       setFormData({
//         name: '',
//         foodTypeId: '',
//         foodCategoryId: '',
//         foodSubCategoryId: '',
//         perUnit: {
//           weight: '',
//           calories: 0,
//           quantity: '',
//           weightIn: '',
//           weightInGm: '',
//         },
//         nutrition: [
//           { proteins: { quantity: 0 } },
//           { carbs: { quantity: 0 } },
//           { fats: { quantity: 0 } },
//           { fiber: { quantity: 0 } },
//         ],
//         nutritionInGm: {
//           proteins: 0,
//           carbs: 0,
//           fats: 0,
//           fiber: 0,
//         },
//         mediaLink: '',
//         unit: 0,
//         isVeg: true,
//         source: '',
//       });
//     } catch (error) {
//       console.error(error);
//     }
//   };

//   const handleChange = (event) => {
//     const { name, value } = event.target;
//     setFormData((prevFormData) => ({
//       ...prevFormData,
//       [name]: value,
//     }));
//   };

//   return (
//     <form onSubmit={handleSubmit}>
//       {/* Input fields for each property */}
//       {/* ... */}
//       <button type="submit">Create Dish</button>
//     </form>
//   );
// };

// export default CreateDishForm;


import React, { useState, useEffect } from 'react';
import axios from 'axios';

const CreateDishForm = () => {
  const [formData, setFormData] = useState({
    name: '',
    foodTypeId: '',
    foodCategoryId: '',
    foodSubCategoryId: '',
    perUnit: {
      weight: '',
      calories: 0,
      quantity: '',
      weightIn: '',
      weightInGm: '',
    },
    nutrition: [
      { proteins: { quantity: 0 } },
      { carbs: { quantity: 0 } },
      { fats: { quantity: 0 } },
      { fiber: { quantity: 0 } },
    ],
    nutritionInGm: {
      proteins: 0,
      carbs: 0,
      fats: 0,
      fiber: 0,
    },
    mediaLink: '',
    unit: 0,
    isVeg: true,
    source: '',
  });

  const [foodCategories, setFoodCategories] = useState([]);
  const [foodSubcategories, setFoodSubcategories] = useState([]);
  const [foodTypes, setFoodTypes] = useState([]);

  useEffect(() => {
    fetchFoodCategories();
    fetchFoodTypes();
  }, []);

  const fetchFoodCategories = async () => {
    try {
      const response = await axios.get('/api/foodcategories');
      setFoodCategories(response.data);
    } catch (error) {
      console.error(error);
    }
  };

  const fetchFoodSubcategories = async (categoryId) => {
    try {
      const response = await axios.get(`/api/foodcategories/${categoryId}/subcategories`);
      setFoodSubcategories(response.data);
    } catch (error) {
      console.error(error);
    }
  };

  const fetchFoodTypes = async () => {
    try {
      const response = await axios.get('/api/foodtypes');
      setFoodTypes(response.data);
    } catch (error) {
      console.error(error);
    }
  };

  const handleSubmit = async (event) => {
    event.preventDefault();

    try {
      await axios.post('/api/dishes', formData);
      console.log('Dish created successfully!');
      // Reset the form
      setFormData({
        name: '',
        foodTypeId: '',
        foodCategoryId: '',
        foodSubCategoryId: '',
        perUnit: {
          weight: '',
          calories: 0,
          quantity: '',
          weightIn: '',
          weightInGm: '',
        },
        nutrition: [
          { proteins: { quantity: 0 } },
          { carbs: { quantity: 0 } },
          { fats: { quantity: 0 } },
          { fiber: { quantity: 0 } },
        ],
        nutritionInGm: {
          proteins: 0,
          carbs: 0,
          fats: 0,
          fiber: 0,
        },
        mediaLink: '',
        unit: 0,
        isVeg: true,
        source: '',
      });
    } catch (error) {
      console.error(error);
    }
  };

  const handleChange = (event) => {
    const { name, value } = event.target;
    setFormData((prevFormData) => ({
      ...prevFormData,
      [name]: value,
    }));
  };

  const handleCategoryChange = (event) => {
    const categoryId = event.target.value;
    setFormData((prevFormData) => ({
      ...prevFormData,
      foodCategoryId: categoryId,
    }));
    fetchFoodSubcategories(categoryId);
  };

  return (
    <form onSubmit={handleSubmit}>
      {/* Other input fields */}

      {/* Category Dropdown */}
      <label>
        Category:
        <select name="foodCategoryId" value={formData.foodCategoryId} onChange={handleCategoryChange}>
          <option value="">Select a category</option>
          {foodCategories.map((category) => (
            <option key={category._id} value={category._id}>
              {category.name}
            </option>
          ))}
        </select>
      </label>

      {/* Subcategory Dropdown */}
      <label>
        Subcategory:
        <select name="foodSubCategoryId" value={formData.foodSubCategoryId} onChange={handleChange}>
        <option value="">Select a subcategory</option>
        {foodSubcategories.map((subcategory) => (
        <option key={subcategory._id} value={subcategory._id}>
            {subcategory.name}
        </option>
        ))}
        </select>
      </label>

      {/* Food Type Dropdown */}
      <label>
        Food Type:
        <select name="foodTypeId" value={formData.foodTypeId} onChange={handleChange}>
          <option value="">Select a food type</option>
          {foodTypes.map((foodType) => (
            <option key={foodType._id} value={foodType._id}>
              {foodType.name}
            </option>
          ))}
        </select>
      </label>

      <button type="submit">Create Dish</button>
    </form>
  );
};

export default CreateDishForm;
