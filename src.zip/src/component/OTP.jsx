import React, { useState } from "react";

import { Link } from "react-router-dom";

import { Loader } from "semantic-ui-react";

const OTP = () => {
  return (
    <div>
      <section id="OTP">
        <div className="container-fluid">
          <div className="row full-height-vh">
            <div className="col-12 d-flex align-items-center justify-content-center gradient-aqua-marine">
              <div className="card px-4 py-2 box-shadow-2 width-400">
                <div className="card-header text-center">
                  <img
                    src="../app-assets/img/logos/logo.png"
                    alt="company-logo"
                    className="mb-3"
                    width="120"
                  />
                </div>
                <div className="card-body">
                  <div className="card-block">
                    <form>
                      <div className="form-group">
                        <div className="col-md-12">
                          <input
                            type="text"
                            className="form-control form-control-lg"
                            name="mobileNo"
                            // value={opt}
                            placeholder="Enter OTP"
                            // onChange={(e) => setmobileNo(e.target.value)}
                          />
                        </div>
                      </div>

                      <div className="form-group">
                        <div className="text-center col-md-12">
                          <button
                            type="submit"
                            // onClick={signIn}
                            className="btn btn-warning px-4 py-2 text-uppercase white font-small-4 box-shadow-2 border-0"
                          >
                            Submit
                          </button>
                        </div>
                      </div>
                    </form>
                  </div>
                </div>
                <div className="card-footer grey darken-1">
                  <div className="text-center mb-1">
                    Don't Have Account?
                    <Link to="/register">
                      <b>Register</b>
                    </Link>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default OTP;
