import React, { useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { Loader } from "semantic-ui-react";
import Navbarside from "./Navbarside";
import { Link } from "react-router-dom";
import Footer from "./footer";
import { FaVideo } from "react-icons/fa";
import { getplaylist } from "../store/slices/playlist";

function Playlist() {
  const [categoryPlaylist, setCategoryPlaylist] = useState([]);
  const dispatch = useDispatch();

  React.useEffect(() => {
    dispatch(getplaylist())
      .unwrap()
      .then((data) => {
        setCategoryPlaylist(data.user.data);
      })
      .catch(({ message }) => {
        // alert(message);
      });
  }, [dispatch]);

  return (
    <body data-col="2-columns" className=" 2-columns ">
      <Navbarside />

      <div className="container-fluid pb-5 response-cover">
        <div className="row">
          <div className="col-lg-2 col-md-4" />
          <div className="col-lg-10 col-md-8">
            <div className="container-fluid pt-5">
              <div className="row">
                <div className="col-12">
                  <div className="card">
                    <div className="card-header">
                      <div className="card-title-wrap bar-danger d-flex align-items-center">
                        <h4 className="card-title">
                          Playlist
                          {/* <Link
                            to="/UploadPackage"
                            className="btn btn-primary"
                          >
                            <i className="fa fa-plus"></i> Add
                          </Link> */}
                        </h4>
                        &nbsp; &nbsp;
                        <Link
                          to="/LiveWell/Playlist/AddPlaylist"
                          className="btn btn-primary"
                        >
                          <i className="fa fa-plus"></i> Add
                        </Link>
                      </div>
                    </div>
                    <div className="card-body collapse show">
                      <div className="card-block card-dashboard table-responsive">
                        <table className="table table-striped table-bordered zero-configuration">
                          <thead>
                            <tr>
                              <th>Content Name</th>
                              <th>Description</th>
                              <th>Thumbnail</th>
                              <th>Video</th>
                              <th>Playlist Content</th>
                              <th>Action</th>
                            </tr>
                          </thead>
                          <tbody>
                            {categoryPlaylist.map((PlaylistVal, index) => (
                              <tr key={index}>
                                <td>{PlaylistVal.name}</td>

                                <td>{PlaylistVal.description}</td>

                                <td className="d-flex justify-content-center">
                                  <img
                                    src={PlaylistVal.mediaLink}
                                    alt="content"
                                    style={{
                                      height: "60px",
                                      width: "60px",
                                      borderRadius: "10px",
                                    }}
                                  />
                                </td>

                                <td>
                                  <Link to="" className="btn btn-warning">
                                    View
                                  </Link>
                                </td>

                                <td>
                                  <Link
                                    to={`/PlaylistContent/${
                                      PlaylistVal._id ? PlaylistVal._id : null
                                    }`}
                                    className="btn btn-warning"
                                  >
                                    View
                                  </Link>
                                </td>

                                <td>
                                  <Link to="" className="btn btn-warning">
                                    Edit
                                  </Link>
                                </td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <Footer />
    </body>
  );
}

export default Playlist;
