import React, { useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import Navbarside from "./Navbarside";
import { getWmExperts } from "../store/slices/hcexpert";
import Footer from "./footer";
import { enableExpert } from "../store/slices/auth";
import { Link, useNavigate } from "react-router-dom";

import { ExportToExcel } from "./ExportToExcel";
import { API_PATHS } from "../utils/constants/api.constants";
import axios from "axios";

const WmExperts = () => {
  const dispatch = useDispatch();
  const [bodypart, setBodypart] = useState([]);
  const [data, setData] = useState([]);
  const fileName = "WMExpert";

  React.useEffect(() => {
    const fetchData = () => {
      axios.get(API_PATHS.getuser).then((postData) => {
        const customHeadings = postData.data.data.map((item) => ({
          "First Name": item.firstName,
          "Last Name": item.lastName,
          "Mobile No.": item.mobileNo,
          Email: item.email,
          Expertise: item.expertise,
        }));

        setData(customHeadings);
      });
    };
    fetchData();
  }, []);

  React.useEffect(() => {
    dispatch(getWmExperts())
      .unwrap()
      .then((data) => {
        setBodypart(data.user.data);
      })
      .catch(({ message }) => {
        // alert(message);
      });
  }, [dispatch]);
  async function disableApprove(ids) {
    let isAdminApproved = false;
    let id = ids;
    let item = { set: { isAdminApproved } };
    localStorage.setItem("item", JSON.stringify(item));
    localStorage.setItem("expertId", id);
    dispatch(enableExpert(item))
      .unwrap()
      .then(() => {
        alert("Expert disabled succesfully");
        window.location.reload(false);
      })
      .catch(({ message }) => {
        alert(message);
      });
    // console.log(item);
    // console.log(id);
  }

  async function enableApprove(ids) {
    let isAdminApproved = true;
    let id = ids;
    let item = { set: { isAdminApproved } };
    localStorage.setItem("item", JSON.stringify(item));
    localStorage.setItem("expertId", id);
    dispatch(enableExpert(item))
      .unwrap()
      .then(() => {
        alert("Expert approved succesfully");
        window.location.reload(false);
      })
      .catch(({ message }) => {
        alert(message);
      });
    // console.log(item);
    // console.log(id);
  }

  return (
    <div>
      <body data-col="2-columns" className=" 2-columns ">
        <Navbarside />

        <div className="container-fluid pb-5 response-cover">
          <div className="row">
            <div className="col-lg-2 col-md-4" />
            <div className="col-lg-10 col-md-8">
              <div className="container-fluid pt-5">
                <div className="row">
                  <div className="col-12">
                    <div className="card">
                      <div className="card-header">
                        <div className="card-title-wrap bar-success d-flex align-items-center">
                          <h4 className="card-title">
                            Weight Management Experts
                          </h4>{" "}
                          &nbsp; &nbsp; &nbsp;
                          <ExportToExcel apiData={data} fileName={fileName} />
                          &nbsp; &nbsp; &nbsp;
                          <Link
                            to="/AddExpert/6229a968eb71920e5c85b0af"
                            className="btn btn-success"
                          >
                            Add Expert
                          </Link>
                        </div>
                      </div>
                      <div className="card-body collapse show">
                        <div className="card-block card-dashboard table-responsive">
                          <table className="table table-striped table-bordered zero-configuration">
                            <thead>
                              <tr>
                                <th>Name</th>
                                <th>Email</th>
                                <th>Mobile Number</th>
                                <th>Is Verified</th>
                                <th>Action</th>
                              </tr>
                            </thead>

                            <tbody>
                              {bodypart.map((expertVal, index) => (
                                <tr>
                                  <td>
                                    <Link
                                      to={`/Expertdetails/${
                                        expertVal._id ? expertVal._id : null
                                      }`}
                                    >
                                      {expertVal.firstName} {expertVal.lastName}
                                    </Link>
                                  </td>
                                  <td>{expertVal.email}</td>
                                  <td>{expertVal.mobileNo}</td>
                                  <td>
                                    {expertVal.isAdminApproved === false && (
                                      <button
                                        onClick={() =>
                                          enableApprove(expertVal._id)
                                        }
                                        className="btn btn-warning"
                                        style={{
                                          height: "25px",
                                          padding: "0 10px",
                                        }}
                                      >
                                        Approve
                                      </button>
                                    )}
                                    {expertVal.isAdminApproved === true && (
                                      <button
                                        className="btn btn-success"
                                        style={{
                                          height: "25px",
                                          padding: "0 10px",
                                        }}
                                      >
                                        Verified
                                      </button>
                                    )}
                                  </td>
                                  <td>
                                    <Link
                                      to={`/EditExpert/${
                                        expertVal._id ? expertVal._id : null
                                      }`}
                                      className="btn btn-primary"
                                      style={{
                                        height: "25px",
                                        padding: "0 10px",
                                      }}
                                    >
                                      Edit Profile
                                    </Link>
                                    &nbsp;
                                    {expertVal.isAdminApproved === true && (
                                      <button
                                        onClick={() =>
                                          disableApprove(expertVal._id)
                                        }
                                        className="btn btn-warning"
                                        style={{
                                          height: "25px",
                                          padding: "0 10px",
                                        }}
                                      >
                                        Disable
                                      </button>
                                    )}
                                  </td>
                                </tr>
                              ))}
                            </tbody>
                          </table>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <Footer />
      </body>
    </div>
  );
};

export default WmExperts;
