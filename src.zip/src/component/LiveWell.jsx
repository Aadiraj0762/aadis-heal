import React, { useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import Navbarside from "./Navbarside";
import { Link } from "react-router-dom";
import Footer from "./footer";
import { getMasterCategory } from "../store/slices/livewell";
import { ExportToExcel } from "./ExportToExcel";
import { API_PATHS } from "../utils/constants/api.constants";
import axios from "axios";
function LiveWell() {
  const [categories, setCategories] = useState([]);
  const dispatch = useDispatch();

  const [data, setData] = useState([]);
  const fileName = "Live Well";

  React.useEffect(() => {
    const fetchData = () => {
      axios.get(API_PATHS.getMasterCategory).then((postData) => {
        const customHeadings = postData.data.data.map((item) => ({
          Name: item.name,
          Decription: item.description,
        }));

        setData(customHeadings);
      });
    };
    fetchData();
  }, []);

  React.useEffect(() => {
    dispatch(getMasterCategory())
      .unwrap()
      .then((data) => {
        setCategories(data.user.data);
      })
      .catch(({ message }) => {
        // alert(message);
      });
  }, [dispatch]);

  return (
    <body data-col="2-columns" className=" 2-columns ">
      <Navbarside />

      <div className="container-fluid pb-5 response-cover">
        <div className="row">
          <div className="col-lg-2 col-md-4" />
          <div className="col-lg-10 col-md-8">
            <div className="container-fluid pt-5">
              <div className="row">
                <div className="col-12">
                  <div className="card">
                    <div className="card-header">
                      <div className="card-title-wrap bar-success d-flex align-items-center">
                        <h4 className="card-title">Live Well</h4>
                        &nbsp; &nbsp;
                        <Link
                          to="/LiveWell/AddCategory"
                          className="btn btn-primary"
                          style={{ marginBottom: "0%" }}
                        >
                          <i className="fa fa-plus"></i> Add
                        </Link>{" "}
                        &nbsp; &nbsp;
                        <ExportToExcel
                          apiData={data}
                          fileName={fileName}
                          style={{
                            height: "25px",
                            padding: "0 10px",
                            marginBottom: "0%",
                          }}
                        />
                      </div>
                    </div>
                    <div className="card-body collapse show">
                      <div className="card-block card-dashboard table-responsive">
                        <table className="table table-striped table-bordered zero-configuration">
                          <thead>
                            <tr>
                              <th>Name</th>
                              <th>Description</th>
                              {/* <th>Content</th> */}
                              <th>Sub Categories</th>
                              {/* <th>Action</th> */}
                            </tr>
                          </thead>
                          <tbody>
                            {categories.map((LivewellVal, index) => (
                              <tr key={index}>
                                <td>{LivewellVal.name}</td>

                                <td>{LivewellVal.description}</td>

                                {/* <td>
                                  <Link
                                    to={`/LiveWell/Contents/${
                                      LivewellVal._id ? LivewellVal._id : null
                                    }`}
                                    className="btn btn-warning"
                                  >
                                    View
                                  </Link>
                                </td> */}

                                <td>
                                  <Link
                                    to={`/LiveWellSubCategory/${
                                      LivewellVal._id ? LivewellVal._id : null
                                    }`}
                                    className="btn btn-warning"
                                  >
                                    View
                                  </Link>
                                </td>

                                {/* <td>
                                  <Link to="" className="btn btn-warning">
                                    Edit
                                  </Link>
                                </td> */}
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <Footer />
    </body>
  );
}

export default LiveWell;
