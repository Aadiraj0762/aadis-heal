import React, { useState } from "react";

import Navbarside from "./Navbarside";
import Footer from "./footer";
import { getCommunitydetail, addlike } from "../store/slices/Community";
import { useDispatch, useSelector } from "react-redux";
import { useParams } from "react-router-dom";
import { SlLike } from "react-icons/sl";

const CommunityDetails = () => {
  const dispatch = useDispatch();

  const [commentsCount, setCommentsCount] = useState("");
  const [date, setDate] = useState("");
  const [likesCount, setLikesCount] = useState("");
  const [firstName, setFirstName] = useState("");
  const [imageUrl, setImageUrl] = useState("");
  const [lastName, setLastName] = useState("");

  const [mediaLink, setmediaLink] = useState("");
  const [description, setDescription] = useState("");
  const { id } = useParams();

  localStorage.setItem("postsId", id);

  React.useEffect(() => {
    dispatch(getCommunitydetail())
      .unwrap()
      .then((data) => {
        if (data.user.data[0]._id === id) {
          setmediaLink(data.user.data[0].mediaLink);
          setDescription(data.user.data[0].description);
          setCommentsCount(data.user.data[0].commentsCount);
          setDate(data.user.data[0].date);
          setLikesCount(data.user.data[0].likesCount);
          setFirstName(data.user.data[0].userId.firstName);
          setImageUrl(data.user.data[0].userId.imageUrl);
          setLastName(data.user.data[0].userId.lastName);
        }
      })
      .catch(({ message }) => {
        // alert(message);
      });
  }, [dispatch]);

  async function like(id) {
    let action = "like";
    let likedBy = "62b19dc0d18a138255d39bcd";
    let postId = "62fb4080c7917f0c6a391268";

    let item = { action, likedBy, postId };
    localStorage.setItem("item", JSON.stringify(item));
    localStorage.setItem("id", id);

    dispatch(addlike())
      .unwrap()
      .then(() => {
        // alert("Uploaded succesfully");
        window.location.reload(false);
      })
      .catch(({ message }) => {
        alert(message);
      });
    console.log(item);
    console.log(id);
  }

  return (
    <div>
      <body data-col="2-columns" className=" 2-columns ">
        <Navbarside />

        <div className="container-fluid pb-5 response-cover">
          <div className="row">
            <div className="col-lg-2 col-md-4" />
            <div className="col-lg-10 col-md-8">
              <div className="container-fluid pt-5">
                <div className="row pt-5 pb-5">
                  <div className="col-lg-2 col-md-1" />

                  <div className="col-lg-8 col-md-10 col-sm-12">
                    <div className="col-lg-12 col-sm-12 col-md-12">
                      <div className="post-card mt-2 mb-2">
                        <p className="post-name">
                          <img src={imageUrl} className="post-icon" alt="" />
                          {firstName} {lastName}
                        </p>
                        <p className="post-date-c">{date}</p>
                        <div className="description-res">
                          <p className="post-Description">
                            {description.substring(0, 50)}...
                          </p>
                        </div>
                        {mediaLink != null && (
                          <img
                            src={mediaLink}
                            className="post-image-media"
                            alt=""
                          />
                        )}

                        {/*
        <div className='d-flex justify-content-end pt-4'>
        // {action === "" && (
          <button
            className=""
            style={{
              height: "25px",
              padding: "0 10px",
            }}
            // onClick={() =>
            //   like(categoryVal._id)
            // }
          >
            <SlLike/>
          </button>
        )}
        {action === "like" && (
          <Link
            className=""
            style={{
              height: "25px",
              padding: "0 10px",
            }}
            onClick={() =>
              disablelike(categoryVal._id)
            }
          >
           <AiFillLike/>
          </Link>
        )}
          </div>*/}
                      </div>
                    </div>
                  </div>

                  <div className="col-lg-3 col-md-1" />
                </div>
              </div>
            </div>
          </div>
        </div>
        <Footer />
      </body>
    </div>
  );
};

export default CommunityDetails;
