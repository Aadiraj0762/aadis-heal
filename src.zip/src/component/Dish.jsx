import React from "react";
import Navbarside from "./Navbarside";
import { useDispatch } from "react-redux";
import { getdishfood } from "../store/slices/food";
import {postdishfood} from "../store/slices/food"
import { useState } from "react";
import Footer from "./footer";
import { useNavigate, useParams, Link } from "react-router-dom";


import { ExportToExcel } from "./ExportToExcel";
import { API_PATHS } from "../utils/constants/api.constants";
import axios from "axios";
const Dish = () => {
  const [dishfood, setDishfood] = useState([]);

  const dispatch = useDispatch();
  const [data, setData] = useState([]);
  const fileName = "WMDish";

  React.useEffect(() => {
    const fetchData = () => {
      axios.get(API_PATHS.getdish).then((postData) => {
        const customHeadings = postData.data.data.map((item) => ({
          "Name": item.name,
          "Unit": item.Unit,
          "Calories": item.perUnit.calories,
          "Quantity": item.perUnit.quantity,
          "Weight": item.perUnit.weight,
        }));

        setData(customHeadings);
      });
    };
    fetchData();
  }, []);

  React.useEffect(() => {
    dispatch(getdishfood())
      .unwrap()
      .then((data) => {
        setDishfood(data.user.data);
      })
      .catch(({ message }) => {
        alert(message);
      });
  }, [dispatch]);

  return (
    <div>
      <Navbarside />

      <div className="container-fluid response-cover pb-5">
        <div className="row">
          <div className="col-lg-2 col-md-4" />
          <div className="col-lg-10 col-md-8">
            <div className="container-fluid pt-5">
              <div className="row">
                <div className="col-12">
                  <div className="card">
                    <div className="card-header">
                      <div className="card-title-wrap bar-success d-flex align-items-center">
                        <h4 className="card-title">Dish</h4>
                        &nbsp; &nbsp; &nbsp;
                        <Link to="AddDish" className="btn btn-success col-white">
                          Add
                        </Link>
                        &nbsp; &nbsp; &nbsp;
                        <ExportToExcel apiData={data} fileName={fileName} />
                      </div>
                    </div>
                    <div className="card-body collapse show">
                      <div className="card-block card-dashboard table-responsive">
                        <table className="table table-striped table-bordered zero-configuration">
                          <thead>
                            <tr>
                              <th>Dish Name</th>
                              <th>Image</th>  
                              <th>Nutrition</th>
                              <th>Per Unit</th>

                              {/* <th>Action</th> */}
                            </tr>
                          </thead>

                          <tbody>
                            {dishfood.map((dishVal, index) => (
                              <tr key={index}>
                                <td>{dishVal.name}</td>
                                <td>
                                  <img
                                    src={dishVal.mediaLink}
                                    alt=""
                                    style={{
                                      borderRadius: "5px",
                                      height: "60px",
                                      width: "60px",
                                    }}
                                  />
                                </td>

                                <td>
                                  <div className="d-flex justify-content-between">
                                    <p> Carbs Quantity :</p>
                                    <span>
                                      {dishVal.nutrition[0].carbs.quantity}
                                    </span>
                                  </div>

                                  <div className="d-flex justify-content-between">
                                    <p> Fats Quantity :</p>
                                    <span>
                                      {dishVal.nutrition[0].fats.quantity}
                                    </span>
                                  </div>

                                  <div className="d-flex justify-content-between">
                                    <p>Fiber Quantity :</p>
                                    <span>
                                      {dishVal.nutrition[0].fiber.quantity}
                                    </span>
                                  </div>

                                  <div className="d-flex justify-content-between">
                                    <p>Proteins Quantity :</p>
                                    <span>
                                      {dishVal.nutrition[0].proteins.quantity}
                                    </span>
                                  </div>
                                </td>

                                <td>
                                  <div className="d-flex justify-content-between">
                                    <p>Calories :</p>
                                    <span>{dishVal.perUnit.calories}</span>
                                  </div>

                                  <div className="d-flex justify-content-between">
                                    <p>Quantity :</p>
                                    <span>{dishVal.perUnit.quantity}</span>
                                  </div>

                                  <div className="d-flex justify-content-between">
                                    <p>Weight :</p>
                                    <span>{dishVal.perUnit.weight}</span>
                                  </div>
                                </td>

                                {/* <td>
                                  <Link
                                    to=""
                                    className="btn btn-primary col-white"
                                  >
                                    Edit
                                  </Link>
                                </td> */}
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <Footer />
    </div>
  );
};

export default Dish;
