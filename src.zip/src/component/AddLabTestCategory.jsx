import React, { useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { Loader, MessageHeader } from "semantic-ui-react";
import Navbarside from "./Navbarside";
import { Link, useNavigate } from "react-router-dom";
import Footer from "./footer";
import { FaVideo } from "react-icons/fa";
import { postlab } from "../store/slices/Labcategory";
// import { API_PATHS } from "../utils/constants/api.constants";

const AddLabTestCategory = () => {
  const [name, setName] = useState("");
  const [price, setPrice] = useState("");

  const [alertname, setAlertName] = useState("");
  const [alertprice, setAlertPrice] = useState("");

  const navigate = useNavigate("");
  const dispatch = useDispatch();

  const save = (e) => {
    const regname = /^(([A-Za-z]+[,.]?[ ]?|[a-z]+['-]?|[0-9])+)$/;
    if (regname.test(name)) {
      setAlertName("");
    } else if (!regname.test(name) && name === "") {
      setAlertName("Please enter the category name");
      e.preventDefault();
    } else {
      setAlertName("Invalid input");
      e.preventDefault();
    }

    const regnumber = /^[0-9][0-9]?$|^100$/;
    if (regnumber.test(price)) {
      setAlertPrice("");
    } else if (!regnumber.test(price) && price === "") {
      setAlertPrice("Please enter the test price");
      e.preventDefault();
    } else {
      setAlertPrice("");
    }
  };

  const cancel = () => {
    setName("");
    setPrice("");
    setAlertName("");
    setAlertPrice("");
  };

  async function upload(e) {
    e.preventDefault();
    let isActive = "true";
    let item = { name, price, isActive };
    dispatch(postlab(item))
      .unwrap()
      .then(() => {
        alert("Uploaded succesfully");
        navigate(-1);
      })
      .catch(({ message }) => {
        alert(message);
      });
  }

  return (
    <body data-col="2-columns" className=" 2-columns ">
      <Navbarside />

      <div className="container-fluid pb-5 response-cover">
        <div className="row">
          <div className="col-lg-2 col-md-4" />
          <div className="col-lg-10 col-md-8">
            <div className="container-fluid pt-5">
              <div className="row">
                <div className="col-12">
                  <div className="card">
                    <div className="card-header">
                      <div className="card-title-wrap bar-danger d-flex align-items-center">
                        <h4 className="card-title">Add Lab Test</h4>
                      </div>
                    </div>

                    <section className="form-section">
                      <form onSubmit={upload}>
                        <div className="row">
                          <div className="col-md-6 col-sm-12 pt-2">
                            <p
                              className="col-black"
                              style={{ marginBottom: "2px" }}
                            >
                              Name
                            </p>
                            <input
                              type="text"
                              placeholder="Enter your name"
                              value={name}
                              onChange={(e) => setName(e.target.value)}
                              className="form-control"
                            />
                            <p className="alert-message">{alertname}</p>
                          </div>

                          <div className="col-md-6 col-sm-12 pt-2">
                            <p
                              className="col-black"
                              style={{ marginBottom: "2px" }}
                            >
                              Price
                            </p>
                            <input
                              type="number"
                              min="0"
                              placeholder="Enter the price"
                              value={price}
                              onChange={(e) => setPrice(e.target.value)}
                              className="form-control"
                            />
                            <p className="alert-message">{alertprice}</p>
                          </div>
                        </div>
                        <div className="d-flex justify-content-center pt-3">
                          <button
                            type="submit"
                            className="btn btn-primary"
                            onClick={save}
                          >
                            Submit
                          </button>
                          &nbsp; &nbsp; &nbsp;
                          <button
                            type="reset"
                            className="btn btn-warning"
                            onClick={cancel}
                          >
                            Cancel
                          </button>
                        </div>
                      </form>
                    </section>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <Footer />
    </body>
  );
};

export default AddLabTestCategory;
