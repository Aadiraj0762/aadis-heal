import React, { useState } from "react";
import { Link } from "react-router-dom";
import Navbarside from "./Navbarside";
import { useDispatch } from "react-redux";
import { getPhysioExperts } from "../store/slices/hcexpert";
import Footer from "./footer";
import { enableExpert } from "../store/slices/auth";
import { ExportToExcel } from "./ExportToExcel";
import { API_PATHS } from "../utils/constants/api.constants";
import axios from "axios";
import $ from "jquery";

const PhysioExpert = () => {
  const dispatch = useDispatch();

  const [data, setData] = useState([]);
  const fileName = "Physiotherapist Expert";

  React.useEffect(() => {
    const fetchData = () => {
      axios.get(API_PATHS.getuser).then((postData) => {
        const customHeadings = postData.data.data.map((item) => ({
          "First Name": item.firstName,
          "Last Name": item.lastName,
          "Mobile No.": item.mobileNo,
          Email: item.email,
          Expertise: item.expertise,
        }));

        setData(customHeadings);
      });
    };
    fetchData();
  }, []);

  React.useEffect(() => {
    dispatch(getPhysioExperts())
      .unwrap()
      .then((data) => {
        $("#example").DataTable({
          data: data.user.data.map((e, index) => {
            return { index, ...e };
          }),
          columns: [
            {
              title: "#",
              render: (data, type, row) => {
                return ++row.index;
              },
            },
            {
              title: "Name",
              render: (data, type, row) => {
                return `<a
                href="/Expertdetails/${row._id ? row._id : null}"
              >
                ${row.firstName} ${row.lastName}
              </a>`;
              },
            },
            {
              title: "Email",
              data: "email",
            },
            {
              title: "Mobile Number",
              data: "mobileNo",
            },
            {
              title: "Status",
              render: (data, type, row) => {
                if (row.isAdminApproved === false) {
                  return `<button
                  data-id="${row._id}"
                  class="btn btn-warning enableApprove"
                  style="height: 25px; padding: 0 10px"
                >
                  Approve
                </button>`;
                }

                if (row.isAdminApproved === true) {
                  return `<button
                  class="btn btn-success"
                  style="height: 25px; padding: 0 10px"
                >
                  Verified
                </button>`;
                }
              },
            },
            {
              title: "Action",
              render: (data, type, row) => {
                let html = `<a
                href="/EditExpert/${row._id ? row._id : null}"
                class="btn btn-primary"
                style="height: 25px; padding: 0 10px"
              >
                Edit Profile
              </a>`;

                if (row.isAdminApproved === true) {
                  html += `<button
                      data-id="${row._id}"
                      class="btn btn-warning disableApprove"
                      style="height: 25px; padding: 0 10px"
                    >
                      Disable
                    </button>`;
                }
                return html;
              },
            },
          ],
          destroy: true,
        });
      })
      .catch(({ message }) => {
        // alert(message);
      });

    $("#example").on("click", ".enableApprove", function (e) {
      e.stopPropagation();
      enableApprove($(this).data("id"));
    });
    $("#example").on("click", ".disableApprove", function (e) {
      e.stopPropagation();
      disableApprove($(this).data("id"));
    });
  }, [dispatch]);

  async function disableApprove(ids) {
    let isAdminApproved = false;
    let id = ids;
    let item = { set: { isAdminApproved } };
    localStorage.setItem("item", JSON.stringify(item));
    localStorage.setItem("expertId", id);
    dispatch(enableExpert(item))
      .unwrap()
      .then(() => {
        alert("Expert disabled succesfully");
        window.location.reload(false);
      })
      .catch(({ message }) => {
        alert(message);
      });
  }

  async function enableApprove(ids) {
    let isAdminApproved = true;
    let id = ids;
    let item = { set: { isAdminApproved } };
    localStorage.setItem("item", JSON.stringify(item));
    localStorage.setItem("expertId", id);
    dispatch(enableExpert(item))
      .unwrap()
      .then(() => {
        alert("Expert approved succesfully");
        window.location.reload(false);
      })
      .catch(({ message }) => {
        alert(message);
      });
  }

  return (
    <div>
      <Navbarside />

      <div className="container-fluid pb-5 response-cover">
        <div className="row">
          <div className="col-lg-2 col-md-4" />
          <div className="col-lg-10 col-md-8">
            <div className="container-fluid pt-5">
              <div className="row">
                <div className="col-12">
                  <div className="card">
                    <div className="card-header">
                      <div className="card-title-wrap bar-success d-flex align-items-center">
                        <h4 className="card-title">Expert Physiotherapists</h4>{" "}
                        &nbsp; &nbsp; &nbsp;
                        <ExportToExcel
                          apiData={data}
                          fileName={fileName}
                          style={{
                            height: "25px",
                            padding: "0 10px",
                            marginBottom: "0%",
                          }}
                        />
                        &nbsp; &nbsp; &nbsp;
                        <Link
                          to="/AddExpert/6229a980305897106867f787"
                          className="btn btn-success"
                        >
                          Add Expert
                        </Link>
                      </div>
                    </div>
                    <div className="card-body collapse show">
                      <div className="card-block card-dashboard table-responsive">
                        <table id="example" className="display"></table>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <Footer />
    </div>
  );
};

export default PhysioExpert;
