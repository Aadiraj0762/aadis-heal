import React, { useState } from "react";
import { Link } from "react-router-dom";
import Navbarside from "./Navbarside";
import { useDispatch, useSelector } from "react-redux";
import { getfamilylab } from "../store/slices/labdetails";
import Footer from "./footer";

const FamilyMemberLab = () => {
  const [fmLab, setFmLab] = useState([]);
  const dispatch = useDispatch();

  React.useEffect(() => {
    dispatch(getfamilylab())
      .unwrap()
      .then((data) => {
        setFmLab(data.user.data);
      })
      .catch(({ message }) => {
        // alert(message);
      });
  }, [dispatch]);

  return (
    <div>
      <Navbarside />

      <div className="container-fluid pb-5 response-cover">
        <div className="row">
          <div className="col-lg-2 col-md-4" />
          <div className="col-lg-10 col-md-8">
            <div className="container-fluid pt-5">
              <div className="row">
                <div className="col-12">
                  <div className="card">
                    <div className="card-header">
                      <div className="card-title-wrap bar-success d-flex align-items-center">
                        <h4 className="card-title">Family Member</h4>
                        &nbsp; &nbsp; &nbsp;
                        <Link
                          to="/AddFamilymember"
                          className="btn btn-warning col-white"
                        >
                          Add Family Members
                        </Link>
                      </div>
                    </div>
                    <div className="card-body collapse show">
                      <div className="card-block card-dashboard table-responsive">
                        <table className="table table-striped table-bordered zero-configuration">
                          <thead>
                            <tr>
                              <th>Image</th>
                              <th style={{ width: "150px" }}>Name</th>
                              <th>Age</th>
                              <th>Gender</th>
                              <th>Email</th>
                              <th>Mobile Number</th>
                            </tr>
                          </thead>
                          <tbody>
                            {fmLab.map((LabVal, index) => (
                              <tr key={index}>
                                <td>
                                  {" "}
                                  <img
                                    src={LabVal.imageUrl}
                                    style={{
                                      height: "75px",
                                      width: "75px",
                                      borderRadius: "10px",
                                    }}
                                    alt=""
                                  />
                                </td>
                                <td>
                                  {LabVal.firstName} {LabVal.lastName}
                                </td>
                                <td>{LabVal.age}</td>
                                <td>{LabVal.gender}</td>
                                <td>{LabVal.email}</td>
                                <td>{LabVal.mobileNo}</td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <Footer />
    </div>
  );
};

export default FamilyMemberLab;
