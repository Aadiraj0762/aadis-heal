import React, { useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { Loader } from "semantic-ui-react";
import Navbarside from "./Navbarside";
import { Link } from "react-router-dom";
import Footer from "./footer";
import { FaVideo } from "react-icons/fa";
import { getplaylistcontent } from "../store/slices/playlistcontent";

function PlaylistContent() {
  const [categoryPlaylistcontent, setCategoryPlaylistcontent] = useState([]);
  const dispatch = useDispatch();

  React.useEffect(() => {
    dispatch(getplaylistcontent())
      .unwrap()
      .then((data) => {
        setCategoryPlaylistcontent(data.user.data);
      })
      .catch(({ message }) => {
        // alert(message);
      });
  }, [dispatch]);

  return (
    <body data-col="2-columns" className=" 2-columns ">
      <Navbarside />

      <div className="container-fluid pb-5 response-cover">
        <div className="row">
          <div className="col-lg-2 col-md-4" />
          <div className="col-lg-10 col-md-8">
            <div className="container-fluid pt-5">
              <div className="row">
                <div className="col-12">
                  <div className="card">
                    <div className="card-header">
                      <h4 className="card-title">
                        Playlist
                        {/* <Link
                              to="/UploadPackage"
                              className="btn btn-primary"
                            >
                              <i className="fa fa-plus"></i> Add
                            </Link> */}
                      </h4>
                    </div>
                    <div className="card-body collapse show">
                      <div className="card-block card-dashboard table-responsive">
                        <table className="table table-striped table-bordered zero-configuration">
                          <thead>
                            <tr>
                              <th>Playlist Name</th>
                              <th>Description</th>
                              <th>Thumbnail</th>
                              <th>Action</th>
                            </tr>
                          </thead>
                          <tbody>
                            {categoryPlaylistcontent.map(
                              (PlaylistVal, index) => (
                                <tr key={index}>
                                  <td>{PlaylistVal.title}</td>

                                  <td>{PlaylistVal.description}</td>

                                  <td>
                                    <img
                                      src={PlaylistVal.thumbnail}
                                      alt="content"
                                      style={{
                                        height: "60px",
                                        width: "60px",
                                        borderRadius: "10px",
                                      }}
                                    />
                                  </td>

                                  <td>
                                    <Link to="" className="btn btn-danger">
                                      Edit
                                    </Link>
                                  </td>
                                </tr>
                              )
                            )}
                          </tbody>
                        </table>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <Footer />
    </body>
  );
}

export default PlaylistContent;
