import React, { useState } from "react";

import Navbarside from "./Navbarside";
import Footer from "./footer";
import { getExpertdiet, DeleteDietplan } from "../store/slices/diet";
import { useDispatch, useSelector } from "react-redux";
import { Link, useParams } from "react-router-dom";
import { confirmAlert } from "react-confirm-alert";
const ExpertDietPlans = () => {
  const dispatch = useDispatch();
  const [workout, setWorkout] = useState([]);

  React.useEffect(() => {
    dispatch(getExpertdiet())
      .unwrap()
      .then((data) => {
        setWorkout(data.user.data);
      })
      .catch(({ message }) => {
        // alert(message);
      });
  }, [dispatch]);

  const Delete = async function deletePlaylist(id) {
    localStorage.setItem("id", id);
    dispatch(DeleteDietplan())
      .unwrap()
      .then(() => {
        // alert("Uploaded succesfully");
        window.location.reload(false);
      })
      .catch(({ message }) => {
        alert(message);
      });

    console.log(id);
  };
  const deleteData = (id) => {
    confirmAlert({
      title: "Want to delete?",
      message: "Are you sure you want to delete this diet plan?",
      buttons: [
        {
          label: "Yes",
          onClick: () => Delete(id),
        },
        {
          label: "No",
          //onClick: () => alert('Click No')
        },
      ],
    });
  };

  return (
    <div>
      <body data-col="2-columns" className=" 2-columns ">
        <Navbarside />

        <div className="container-fluid pb-5 response-cover">
          <div className="row">
            <div className="col-lg-2 col-md-4" />
            <div className="col-lg-10 col-md-8">
              <div className="container-fluid pt-5">
                <div className="row">
                  <div className="col-12">
                    <div className="card">
                      <div className="card-header">
                        <div className="card-title-wrap bar-success">
                          <h4 className="card-title">
                            Diet Plans &nbsp; &nbsp;
                            <Link to="/AddDietPlan" className="btn btn-primary">
                              <i className="fa fa-plus"></i> Add
                            </Link>
                          </h4>
                        </div>
                      </div>
                      <div className="card-body collapse show">
                        <div className="card-block card-dashboard table-responsive">
                          <table className="table table-striped table-bordered zero-configuration">
                            <thead>
                              <tr>
                                <th>Dietplan Name</th>
                                <th>Level</th>
                                <th>Plan Type</th>
                                <th>Goal</th>
                                <th>Type</th>
                                <th>Validity</th>
                                <th>Action</th>
                              </tr>
                            </thead>

                            <tbody>
                              {workout.map((dietVal, index) => (
                                <tr>
                                  <td>
                                    <Link
                                      to={`/DietPlanDetails/${
                                        dietVal._id ? dietVal._id : null
                                      }`}
                                    >
                                      {dietVal.name}
                                    </Link>
                                  </td>
                                  <td>{dietVal.level}</td>
                                  <td>{dietVal.planType}</td>
                                  <td>{dietVal.goal}</td>
                                  <td>{dietVal.type}</td>
                                  <td>{dietVal.validity} Days</td>
                                  <td>
                                    <button
                                      onClick={() => deleteData(dietVal._id)}
                                      className="btn btn-warning"
                                      style={{
                                        height: "25px",
                                        padding: "0 10px",
                                      }}
                                    >
                                      Delete
                                    </button>
                                  </td>
                                </tr>
                              ))}
                            </tbody>
                          </table>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <Footer />
      </body>
    </div>
  );
};

export default ExpertDietPlans;
