import React, { useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { Link } from "react-router-dom";
import { Loader } from "semantic-ui-react";
import Navbarside from "../component/Navbarside";
import { ayurvedaEnquiry } from "../store/slices/enquiry";
import Moment from "moment";
import Footer from "./footer";

const GeneralAyurvedaEnquiry = () => {
  const [expertises, setexpertise] = useState([]);
  const { loading } = useSelector((state) => state.auth);
  const dispatch = useDispatch();

  React.useEffect(() => {
    dispatch(ayurvedaEnquiry())
      .unwrap()
      .then((data) => {
        setexpertise(data.user.data);
      })
      .catch(({ message }) => {
        alert(message);
      });
  }, [dispatch]);

  return (
    <div>
      <Navbarside />

      <div className="container-fluid pb-5 response-cover">
        <div className="row">
          <div className="col-lg-2 col-md-4" />
          <div className="col-lg-10 col-md-8">
            <div className="container-fluid pt-5">
              <div className="row">
                <div className="col-12">
                  <div className="card">
                    <div className="card-header">
                      <div className="card-title-wrap bar-success">
                        <h4 className="card-title">General Ayurveda Enquiry</h4>
                      </div>
                    </div>
                    <div className="card-body collapse show">
                      <div className="card-block card-dashboard table-responsive">
                        <table className="table table-striped table-bordered zero-configuration">
                          <thead>
                            <tr>
                              <th>User Details</th>
                              <th>Message</th>
                              <th>City</th>
                              <th>Booking Date</th>
                              <th>Status</th>
                              <th>Action</th>
                            </tr>
                          </thead>
                          {loading ? (
                            <Loader active inline />
                          ) : (
                            <>
                              <tbody>
                                {expertises.map((enqVal, index) => (
                                  <tr key={index}>
                                    <td>
                                      Name: {enqVal.name}
                                      <br />
                                      Email: {enqVal.email}
                                      <br />
                                      Mobile Number: {enqVal.contactNumber}
                                    </td>
                                    <td>{enqVal.message}</td>
                                    <td>{enqVal.city}</td>
                                    <td>
                                      {Moment(enqVal.date).format("DD-MM-YYYY")}
                                      /{" "}
                                      {Moment(enqVal.created_at).format(
                                        "hh:mm A"
                                      )}
                                    </td>
                                    <td>{enqVal.status}</td>
                                    <td>
                                      <Link
                                        to={`/UpdateEnquiry/${
                                          enqVal._id ? enqVal._id : null
                                        }`}
                                        className="btn btn-primary"
                                        style={{
                                          height: "25px",
                                          padding: "0 10px",
                                        }}
                                      >
                                        Update Status
                                      </Link>
                                    </td>
                                  </tr>
                                ))}
                              </tbody>
                            </>
                          )}
                        </table>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <Footer />
    </div>
  );
};

export default GeneralAyurvedaEnquiry;
