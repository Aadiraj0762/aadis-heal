import React, { useState } from "react";
import { useDispatch } from "react-redux";
import Navbarside from "./Navbarside";
import { useNavigate, useParams } from "react-router-dom";
import Footer from "./footer";
import { initiatefreeConsultation } from "../store/slices/Wmconsultation";
import { getWmExperts } from "../store/slices/hcexpert";

const WMFreeConsultation = () => {
  const [startTime, setstartTime] = useState("");
  const [startDates, setstartDates] = useState("");
  const [durationInMinutes, setdurationInMinutes] = useState("");
  const [Experts, setExperts] = useState([]);
  const [expertId, setexpertId] = useState("");
  const [expertfirstname, setExpertFirstname] = useState("");
  const [expertlastname, setExpertLastname] = useState("");
  // const [expert, setExpert] = useState("");
  const navigate = useNavigate("");
  const dispatch = useDispatch();
  const cancel = () => {
    navigate(-1);
  };

  let { expid } = "6229a968eb71920e5c85b0af";
  localStorage.setItem("id", expid);

  React.useEffect(() => {
    dispatch(getWmExperts())
      .unwrap()
      .then((data) => {
        setExperts(data.user.data);
        setexpertId(data.user.data[0]._id);
        setExpertFirstname(data.user.data[0].firstName);
        setExpertLastname(data.user.data[0].lastName);
      })
      .catch(({ message }) => {
        // alert(message);
      });
  }, [dispatch]);

  const { id } = useParams();
  let userId = id;

  async function upload(e) {
    e.preventDefault();
    let status = "initiated";
    let type = "free";

    const startDate = new Date(startDates).toLocaleDateString();
    let item = {
      userId,
      status,
      type,
      startTime,
      startDate,
      durationInMinutes,
      expertId,
    };

    dispatch(initiatefreeConsultation(item))
      .unwrap()
      .then(() => {
        alert("Consultation created succesfully");
        navigate(-1);
      })
      .catch(({ message }) => {
        alert(message);
      });
  }

  const handleExpertChange = (e) => {
    var value = Experts.filter(function (getWmExperts) {
      return getWmExperts.firstName == e.target.value;
    });
    setexpertId(value[0]._id);
    setExpertFirstname(value[0].firstName);
    // setExpertLastname(value[0].lastName);
  };

  return (
    <body data-col="2-columns" className=" 2-columns ">
      <Navbarside />

      <div className="container-fluid pb-5 response-cover">
        <div className="row">
          <div className="col-lg-2 col-md-4" />
          <div className="col-lg-10 col-md-8">
            <div className="container-fluid pt-5">
              <div className="row">
                <div className="col-12">
                  <div className="card">
                    <div className="card-header">
                      <div className="card-title-wrap bar-danger d-flex align-items-center">
                        <h4 className="card-title">Create Free Consultation</h4>
                      </div>
                    </div>

                    <section className="form-section">
                      <form onSubmit={upload}>
                        <div className="row">
                          <div className="col-md-6 col-sm-12 pt-2">
                            <label>Start Time</label>
                            <input
                              type="time"
                              step="1"
                              value={startTime}
                              onChange={(e) => setstartTime(e.target.value)}
                              className="form-control"
                            />
                          </div>

                          <div className="col-md-6 col-sm-12 pt-2">
                            <label>Start Date</label>
                            <input
                              type="date"
                              value={startDates}
                              onChange={(e) => setstartDates(e.target.value)}
                              className="form-control"
                            />
                          </div>

                          <div className="col-md-6 col-sm-12 pt-2">
                            <label>Duration In Minutes</label>
                            <input
                              type="number"
                              placeholder="Duration"
                              min="1"
                              value={durationInMinutes}
                              onChange={(e) =>
                                setdurationInMinutes(e.target.value)
                              }
                              className="form-control"
                            />
                          </div>
                          <div className="col-md-6 col-sm-12 pt-2">
                            <label>Expert</label>
                            <select
                              className="form-control"
                              onChange={handleExpertChange}
                            >
                              <option value="">Select Expert</option>
                              {Experts.map((option) => (
                                <option value={option.expertId}>
                                  {option.firstName}
                                </option>
                              ))}
                            </select>
                          </div>
                        </div>

                        <div className="d-flex justify-content-center pt-3">
                          <button type="submit" className="btn btn-primary">
                            Submit
                          </button>
                          &nbsp; &nbsp; &nbsp;
                          <button
                            type="reset"
                            className="btn btn-warning"
                            onClick={cancel}
                          >
                            Cancel
                          </button>
                        </div>
                      </form>
                    </section>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <Footer />
    </body>
  );
};

export default WMFreeConsultation;
