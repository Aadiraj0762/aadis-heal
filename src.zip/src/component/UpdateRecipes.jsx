import React, { useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { Loader } from "semantic-ui-react";
import Navbarside from "./Navbarside";
import { Link, useNavigate, useParams } from "react-router-dom";
import Footer from "./footer";
import { FaVideo } from "react-icons/fa";
import { editfoodrecipe, getfoodrecipe } from "../store/slices/recipes";
import { API_PATHS } from "../utils/constants/api.constants";


const  UpdateRecipes=()=> {


  const navigate = useNavigate("");

const [name, setName] =useState("");
const [mediaLink, setMediaLink] =useState([""]);
const [ingredients, setIngredients] =useState("");
const [method, setMethod] =useState("");
const [calories, setCalories] =useState("");
const [durationInMinutes, setDurationInMinutes] =useState("");
const [nutrition, setNutrition] =useState([
{
    proteins : {quantity : ""},
    carbs : {quantity : ""},
    fats : {quantity : ""},
    fiber : {quantity : ""}

}

]);


  const [message, setMessage] = useState("");
  const dispatch = useDispatch();

  async function addData(e) {
    e.preventDefault();

    let isActive=true;
    let description= {
        ingredients,
        method,

    }

    let item = { name, mediaLink, description, calories, durationInMinutes, isActive, nutrition};
    dispatch(editfoodrecipe(item))
      .unwrap()
      .then(() => {
        alert("Uploaded succesfully");
        // navigate(-1);
      })
      .catch(({ message }) => {
        alert(message);
      });
  }

  const { id } = useParams();
  localStorage.setItem("id", id);
  React.useEffect(() => {
    dispatch(getfoodrecipe())
      .unwrap()
      .then((data) => {
        if (data.user.data[0]._id == id) {
        //   setName(data.user.data[0].weightUnit);
        //   setMediaLink(data.user.data[0].weightUnit);
        //   setIngredients(data.user.data[0].weightUnit);
        //   setMethod(data.user.data[0].weightUnit);
        //   setCalories(data.user.data[0].weightUnit);
        //   setDurationInMinutes(data.user.data[0].weightUnit);
         
          
        }
      })
      .catch(({ message }) => {
        alert(message);
      });
  }, [dispatch]);

  const handleAddForms = () => {
    let quantitys = [...nutrition];
    quantitys.push({
        proteins : {quantity : ""},
        carbs : {quantity : ""},
        fats : {quantity : ""},
        fiber : {quantity : ""}
    
    });
    setNutrition(quantitys);
  };

  const handleDeleteForms = (e) => {
    if (nutrition.length > 1) {
      let quantitys = [...nutrition];
      quantitys.pop();
      setNutrition(quantitys);
    }
  };
  const handleRowChange = (e, index) => {
    const quantitys = [...nutrition];
    quantitys[index][e.currentTarget.name] = e.currentTarget.value;
    setNutrition(quantitys);
    // console.log(tourIternary);
  };


  async function imageLink(e) {
    e.preventDefault();
    var formdata = new FormData();
    formdata.append("file", e.target.files[0]);

    var requestOptions = {
      method: "POST",
      body: formdata,
      redirect: "follow",
    };
    let response = await fetch(API_PATHS.uploadImage, requestOptions);
    let data = await response.json();
    setMediaLink(data.data.location);
    setMessage(data.message);
  }


  return (
    <body data-col="2-columns" className=" 2-columns ">
     
        <Navbarside />

        <div className="container-fluid pb-5 response-cover">
        <div className="row">
          <div className="col-lg-2 col-md-4" />
          <div className="col-lg-10 col-md-8">
            <div className="container-fluid pt-5">
              <div className="row">
                    <div className="col-12">
                      <div className="card">
                        <div className="card-header">
                        <div className="card-title-wrap bar-danger d-flex align-items-center">
                          <h4 className="card-title">
                            Add Recipes
                            {/* <Link
                              to="/UploadPackage"
                              className="btn btn-primary"
                            >
                              <i className="fa fa-plus"></i> Add
                            </Link> */}
                          </h4>
                       
                        </div>
                        </div>
                      
                        <section className="form-section">
                        <form onSubmit={addData}>

                        <div className="row">

                        <div className="col-md-6 col-sm-12 pt-2">
                        <p className="col-black" style={{marginBottom:"2px"}}>Recipe Name</p>
                        <input type="text" placeholder="Enter the recipe name"  value={name}
                        onChange={(e) => setName(e.target.value)} className="form-control"/>
                        <p className="alert-message"></p>
                        </div>

                        <div className="col-md-6 col-sm-12 pt-2">
                        <p className="col-black" style={{marginBottom:"2px"}}>Calories</p>
                        <input type="text" placeholder="Enter the no of calories"  value={calories}
                        onChange={(e) => setCalories(e.target.value)} className="form-control"/>
                        <p className="alert-message"></p>
                        </div>

                        <div className="col-md-6 col-sm-12 pt-2">
                        <p className="col-black" style={{marginBottom:"2px"}}>Duration In Minutes</p>
                        <input type="text" placeholder="Enter the duration in minutes"  value={durationInMinutes}
                        onChange={(e) => setDurationInMinutes(e.target.value)} className="form-control"/>
                        <p className="alert-message"></p>
                        </div>

                        <div className="col-12 pt-5">
                           <h5>Description</h5>
                         
                          </div>

                        <div className="col-md-6 col-sm-12 pt-2">
                        <p className="col-black" style={{marginBottom:"2px"}}>Recipe Ingredients</p>
                        <input type="text" placeholder="Enter the recipe ingredients"  value={ingredients}
                        onChange={(e) => setIngredients(e.target.value)} className="form-control"/>
                        <p className="alert-message"></p>
                        </div>

                        <div className="col-md-6 col-sm-12 pt-2">
                        <p className="col-black" style={{marginBottom:"2px"}}>Recipe Method</p>
                        <input type="text" placeholder="Enter the recipe method"  value={method}
                        onChange={(e) => setMethod(e.target.value)} className="form-control"/>
                        <p className="alert-message"></p>
                        </div>

   <div className="col-md-6 col-sm-12 pt-2">
                      <p className="col-black" style={{marginBottom:"2px"}}>Uploade the recipe picture</p>
                      <input
                      type="file"
                      className="form-control-file"
                      Placeholder="Price Tagline"
                      required
                      onChange={(e) => imageLink(e)}
                    />
                    <p className="alert-message">{}</p>
                    <p style={{color:"green", fontWeight:"500"}}>{message}</p>
                    </div>


                    <div className="col-12 d-flex justify-content-center">
                    <button
                    type="button"
                    className="btn btn-success"
                    onClick={(e) => handleAddForms(e)}
                    
                  >
                    <i className="fa fa-plus-circle" />
                  </button>
                  &nbsp; &nbsp;
                  <button
                    type="button"
                    className="btn btn-danger"
                    onClick={(e) => handleDeleteForms(e)}
                  >
                    <i className="fa fa-minus-circle" />
                  </button>
                    </div>
                   

                    {nutrition.map((quantitys, index) => (
                        <div className="col-12">
                        
                                                    <div key={index} className="row">
                        
                                                     <div className="col-md-3 col-sm-12 pt-2 pb-1">
                                                  <input type="number" className="form-control" placeholder="Enter your protein quantity"
                                                          onChange={(e) => handleRowChange(e, index)}
                                                          value={quantitys.proteins.quantity}
                                                          name="proteins"
                                                          required
                                                  
                                                  />
                                                  </div>
                        
                                                  <div className="col-md-3 col-sm-12 pt-2 pb-1">
                                                  <input type="number" className="form-control" placeholder="Enter your carbs quantity"
                                                          onChange={(e) => handleRowChange(e, index)}
                                                          value={quantitys.carbs.quantity}
                                                          name="carbs"
                                                          required
                                                  
                                                  />
                                                  </div>
                          
                                                  <div className="col-md-3 col-sm-12 pt-2 pb-1">
                                                  <input type="number" className="form-control" placeholder="Enter your fat quantity"
                                                          onChange={(e) => handleRowChange(e, index)}
                                                          value={quantitys.fats.quantity}
                                                          name="fats"
                                                          required
                                                  
                                                  />
                        
                                                  </div>

                                                  <div className="col-md-3 col-sm-12 pt-2 pb-1">
                                                  <input type="number" className="form-control" placeholder="Enter your fiber quantity"
                                                          onChange={(e) => handleRowChange(e, index)}
                                                          value={quantitys.fiber.quantity}
                                                          name="fiber"
                                                          required
                                                  
                                                  />
                        
                                                  </div>

                                                  </div>
                                                  </div>
                                                ))}

                        </div> 
<div className="d-flex justify-content-center pt-3">
<button type="submit" className="btn btn-success">Submit</button>
&nbsp;
&nbsp;
&nbsp;
<button type="reset" className="btn btn-warning">Reset</button>

</div>
                          </form>
                        </section>

                      </div>
                    </div>
                  </div>
            </div>
            </div>
            </div>
            </div>

       

          <Footer />
    

    </body>
  );
}

export default UpdateRecipes;
