import React, { useState } from "react";

import Navbarside from "./Navbarside";
import Footer from "./footer";
import { dietPlan } from "../store/slices/forms";
import { useDispatch, useSelector } from "react-redux";
import { Link, useParams } from "react-router-dom";
const UserDietPlans = () => {
  const dispatch = useDispatch();
  const { id } = useParams();
  localStorage.setItem("clientId", id);
  const [workout, setWorkout] = useState([]);

  React.useEffect(() => {
    dispatch(dietPlan())
      .unwrap()
      .then((data) => {
        setWorkout(data.user.data);
      })
      .catch(({ message }) => {
        // alert(message);
      });
  }, [dispatch]);

  return (
    <div>
      <body data-col="2-columns" className=" 2-columns ">
        <Navbarside />

        <div className="container-fluid pb-5 response-cover">
          <div className="row">
            <div className="col-lg-2 col-md-4" />
            <div className="col-lg-10 col-md-8">
              <div className="container-fluid pt-5">
                <div className="row">
                  <div className="col-12">
                    <div className="card">
                      <div className="card-header">
                        <div className="card-title-wrap bar-success">
                          <h4 className="card-title">
                            Diet Plans &nbsp; &nbsp;
                            {/* <Link to="/AddDietPlan" className="btn btn-primary">
                              <i className="fa fa-plus"></i> Add
                            </Link> */}
                          </h4>
                        </div>
                      </div>
                      <div className="card-body collapse show">
                        <div className="card-block card-dashboard table-responsive">
                          <table className="table table-striped table-bordered zero-configuration">
                            <thead>
                              <tr>
                                <th>Dietplan Name</th>
                                <th>Level</th>
                                <th>Plan Type</th>
                                <th>Goal</th>
                                <th>Type</th>
                                <th>Validity</th>
                              </tr>
                            </thead>

                            <tbody>
                              {workout.map((dietVal, index) => (
                                <tr>
                                  <td>
                                    <Link
                                      to={`/DietPlanDetails/${
                                        dietVal.dietPlanId._id
                                          ? dietVal.dietPlanId._id
                                          : null
                                      }`}
                                    >
                                      {dietVal.dietPlanId.name}
                                    </Link>
                                  </td>
                                  <td>{dietVal.dietPlanId.level}</td>
                                  <td>{dietVal.dietPlanId.planType}</td>
                                  <td>{dietVal.dietPlanId.goal}</td>
                                  <td>{dietVal.dietPlanId.type}</td>
                                  <td>{dietVal.dietPlanId.validity} Days</td>
                                </tr>
                              ))}
                            </tbody>
                          </table>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <Footer />
      </body>
    </div>
  );
};

export default UserDietPlans;
