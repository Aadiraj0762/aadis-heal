import React, { useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { Loader, MessageHeader } from "semantic-ui-react";
import Navbarside from "./Navbarside";
import { Link, useNavigate } from "react-router-dom";
import Footer from "./footer";
import { FaVideo } from "react-icons/fa";
import { addplaylists } from "../store/slices/playlist";
import { API_PATHS } from "../utils/constants/api.constants";

const AddPlaylist = () => {
  const [name, setName] = useState("");
  const [description, setDescription] = useState("");
  const [mediaLink, setmediaLink] = useState("");
  const [details, setDetails] = useState("");

  const [alertname, setAlertName] = useState("");
  const [alertdescription, setAlertDescription] = useState("");
  const [alertmediaLink, setAlertmediaLink] = useState("");
  const [alertdetails, setAlertDetails] = useState("");

  const navigate = useNavigate("");
  const [message, setMessage] = useState("");
  const dispatch = useDispatch();

  const save = (e) => {
    const regname = /^(([A-Za-z]+[,.]?[ ]?|[a-z]+['-]?|[0-9])+)$/;
    if (regname.test(name)) {
      setAlertName("");
    } else if (!regname.test(name) && name === "") {
      setAlertName("Please enter the category name");
      e.preventDefault();
    } else {
      setAlertName("Single and double quotes are not-valid");
      e.preventDefault();
    }

    const regdescription = /^(.|\s)*[a-zA-Z]+(.|\s)*$/;
    if (regdescription.test(description)) {
      setAlertDescription("");
    } else if (!regdescription.test(description) && description === "") {
      setAlertDescription("Please enter the Description");
      e.preventDefault();
    } else {
      setAlertDescription("");
    }

    const regdetailstext = /^(.|\s)*[a-zA-Z]+(.|\s)*$/;
    if (regdetailstext.test(details)) {
      setAlertDetails("");
    } else if (!regdetailstext.test(details) && details === "") {
      setAlertDetails("Please enter the details");
      e.preventDefault();
    } else {
      setAlertDetails("");
    }

    const regimage = /(gif|jpe?g|tiff?|png|webp|bmp)$/i;
    if (regimage.test(mediaLink)) {
      setAlertmediaLink("");
    } else if (!regimage.test(mediaLink) && mediaLink === "") {
      setAlertmediaLink("Please enter image link");
      e.preventDefault();
    } else {
      setAlertmediaLink("Invalid file");
      e.preventDefault();
    }
  };

  const cancel = () => {
    setName("");
    setDescription("");
    setmediaLink("");
    setDetails("");
    setAlertName("");
    setAlertDescription("");
    setAlertmediaLink("");
    setAlertDetails("");
    setMessage("");
  };

  async function addData(e) {
    e.preventDefault();
    let item = { name, description, mediaLink, details };
    dispatch(addplaylists(item))
      .unwrap()
      .then(() => {
        alert("Uploaded succesfully");
        navigate(-1);
      })
      .catch(({ message }) => {
        alert(message);
      });
  }

  async function imageUpload(e) {
    e.preventDefault();
    var formdata = new FormData();
    formdata.append("file", e.target.files[0]);

    var requestOptions = {
      method: "POST",
      body: formdata,
      redirect: "follow",
    };
    let response = await fetch(API_PATHS.uploadImage, requestOptions);
    let data = await response.json();
    setmediaLink(data.data.location);
    setMessage(data.message);
  }

  return (
    <body data-col="2-columns" className=" 2-columns ">
      <Navbarside />

      <div className="container-fluid pb-5 response-cover">
        <div className="row">
          <div className="col-lg-2 col-md-4" />
          <div className="col-lg-10 col-md-8">
            <div className="container-fluid pt-5">
              <div className="row">
                <div className="col-12">
                  <div className="card">
                    <div className="card-header">
                      <div className="card-title-wrap bar-danger d-flex align-items-center">
                        <h4 className="card-title">
                          Add Playlist
                          {/* <Link
                              to="/UploadPackage"
                              className="btn btn-primary"
                            >
                              <i className="fa fa-plus"></i> Add
                            </Link> */}
                        </h4>
                      </div>
                    </div>

                    <section className="form-section">
                      <form onSubmit={addData}>
                        <div className="row">
                          <div className="col-md-6 col-sm-12 pt-2">
                            <p
                              className="col-black"
                              style={{ marginBottom: "2px" }}
                            >
                              Playlist title
                            </p>
                            <input
                              type="text"
                              placeholder="Enter the content title"
                              value={name}
                              onChange={(e) => setName(e.target.value)}
                              className="form-control"
                            />
                            <p className="alert-message">{alertname}</p>
                          </div>

                          <div className="col-md-6 col-sm-12 pt-2">
                            <p
                              className="col-black"
                              style={{ marginBottom: "2px" }}
                            >
                              Description
                            </p>
                            <input
                              type="text"
                              placeholder="Enter the Description"
                              value={description}
                              onChange={(e) => setDescription(e.target.value)}
                              className="form-control"
                            />
                            <p className="alert-message">{alertdescription}</p>
                          </div>

                          <div className="col-md-6 col-sm-12 pt-2">
                            <p
                              className="col-black"
                              style={{ marginBottom: "2px" }}
                            >
                              Details
                            </p>
                            <input
                              type="text"
                              placeholder="Enter the details"
                              value={details}
                              onChange={(e) => setDetails(e.target.value)}
                              className="form-control"
                            />
                            <p className="alert-message">{alertdetails}</p>
                          </div>

                          <div className="col-md-6 col-sm-12 pt-2">
                            <p
                              className="col-black"
                              style={{ marginBottom: "2px" }}
                            >
                              Uploade the image
                            </p>
                            <input
                              type="file"
                              className="form-control-file"
                              Placeholder="Price Tagline"
                              required
                              onChange={(e) => imageUpload(e)}
                            />
                            <p className="alert-message">{alertmediaLink}</p>
                            <p style={{ color: "green", fontWeight: "500" }}>
                              {message}
                            </p>
                          </div>
                        </div>
                        <div className="d-flex justify-content-center pt-3">
                          <button
                            type="submit"
                            className="btn btn-success"
                            onClick={save}
                            disabled={!message}
                          >
                            Submit
                          </button>
                          &nbsp; &nbsp; &nbsp;
                          <button
                            type="reset"
                            className="btn btn-warning"
                            onClick={cancel}
                          >
                            Reset
                          </button>
                        </div>
                      </form>
                    </section>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <Footer />
    </body>
  );
};

export default AddPlaylist;
