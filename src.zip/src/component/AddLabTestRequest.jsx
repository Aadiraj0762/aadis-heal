import React, { useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { useNavigate } from "react-router-dom";

import { API_PATHS } from "../utils/constants/api.constants";
import { postlabrateings } from "../store/slices/labdetails";
// import { Loader } from "semantic-ui-react";
import Footer from "./footer";
import Navbarside from "../component/Navbarside";

function AddLabTestRequest(e) {
  const navigate = useNavigate("");
  const dispatch = useDispatch();

  const [location, setLocation] = useState({
    type: "Point",
    coordinates: [13.00345, 77.662795],
  });

  const [gender, setGender] = useState("");
  const [age, setAge] = useState("");
  const [date, setDate] = useState("");
  const [time, setTime] = useState("");
  const [testType, setTestType] = useState("");
  const [testFor, setTestFor] = useState("");

  const [address, setAddress] = useState({
    doorNoAndStreetName: "",
    city: "",
    state: "",
    pincode: "",
  });
  const [mobileNo, setMobileNo] = useState("");
  const [labTestCategoryId, setLabTestCategoryId] = useState([
    "63578020e5a8e19d1cf98f4a",
    "63577f1fe5a8e19d1cf98f38",
  ]);

  //   Alert-message

  async function upload(e) {
    e.preventDefault();
    let userId = "628e07c3295cbb2a64996d2d";
    let labId = "6357be467efd830dee9769a6";
    let patientId = "635a24fdffb8ec7ebc168153";
    let item = {
      location,
      gender,
      age,
      date,
      time,
      testType,
      testFor,
      address,
      mobileNo,
      userId,
      labId,
      patientId,
      labTestCategoryId,
    };

    dispatch(postlabrateings(item))
      .unwrap()
      .then(() => {
        alert("Uploaded successfully");
        // navigate("/-1");
      })
      .catch(({ message }) => {
        alert(message);
      });
  }

  //   const save = (e) => {
  //     const regtext = /^(([A-Za-z]+[,.]?[ ]?|[a-z]+['-]?)+)$/;
  //     if (regtext.test(blogTitle)) {
  //       setAlertblogTitle("");
  //     } else if (!regtext.test(blogTitle) && blogTitle === "") {
  //       setAlertblogTitle("Please enter Blog Title");
  //       e.preventDefault();
  //     } else {
  //       setAlertblogTitle("");
  //     }

  //     const regimage = /(gif|jpe?g|tiff?|png|webp|bmp)$/i;
  //     if (regimage.test(mediaLink)) {
  //       setAlertmediaLink("");
  //     } else if (!regimage.test(mediaLink) && mediaLink === "") {
  //       setAlertmediaLink("Please enter image link");
  //       e.preventDefault();
  //     } else {
  //       setAlertmediaLink("Invalid file");
  //       e.preventDefault();
  //     }

  //     const regtext2 = /^(([A-Za-z]+[,.]?[ ]?|[a-z]+['-]?)+)$/;
  //     if (regtext2.test(description)) {
  //       setAlertdescription("");
  //     } else if (!regtext2.test(description) && description === "") {
  //       setAlertdescription("Please enter your description");
  //       e.preventDefault();
  //     } else {
  //       setAlertdescription("");
  //     }

  //     const regdate =
  //       /^([0]?[1-9]|[1|2][0-9]|[3][0|1])[-]([0]?[1-9]|[1][0-2])[-]([0-9]{4}|[0-9]{2})$/;
  //     if (regdate.test(date)) {
  //       setAlertdate("");
  //     } else if (!regdate.test(date) && date === "") {
  //       setAlertdate("Please enter your blog date");
  //       e.preventDefault();
  //     } else {
  //       setAlertdate("");
  //     }
  //   };

  const cancel = () => {};
  return (
    <div>
      <Navbarside />

      <div className="container-fluid pb-5 response-cover">
        <div className="row">
          <div className="col-lg-2 col-md-4" />
          <div className="col-lg-10 col-md-8">
            <div className="container-fluid pt-5">
              <div className="row match-height">
                <div className="col-md-12">
                  <div className="card">
                    <div className="card-header">
                      <div className="card-title-wrap bar-warning">
                        <h4
                          className="card-title"
                          id="basic-layout-form-center"
                        >
                          Upload Blog
                        </h4>
                      </div>
                    </div>
                    <div className="card-body">
                      <div className="px-3">
                        <form className="form" onSubmit={upload}>
                          <div className="row justify-content-md-center">
                            <div className="col-md-6">
                              <div className="form-body">
                                <div className="form-group">
                                  <label for="placeTextarea">Rate</label>
                                  <input
                                    type="text"
                                    className="form-control"
                                    Placeholder="Enter your ratings"
                                    value={gender}
                                    onChange={(e) => setGender(e.target.value)}
                                  />
                                  <p className="alert-message"></p>
                                </div>
                              </div>
                            </div>

                            <div className="col-md-6">
                              <div className="form-body">
                                <div className="form-group">
                                  <label for="placeTextarea">Review</label>
                                  <input
                                    type="text"
                                    className="form-control"
                                    Placeholder="Enter the review"
                                    value={age}
                                    onChange={(e) => setAge(e.target.value)}
                                  />
                                  <p className="alert-message"></p>
                                </div>
                              </div>
                            </div>

                            <div className="col-md-6">
                              <div className="form-body">
                                <div className="form-group">
                                  <label for="placeTextarea">Rate</label>
                                  <input
                                    type="text"
                                    className="form-control"
                                    Placeholder="Enter your ratings"
                                    value={date}
                                    onChange={(e) => setDate(e.target.value)}
                                  />
                                  <p className="alert-message"></p>
                                </div>
                              </div>
                            </div>

                            <div className="col-md-6">
                              <div className="form-body">
                                <div className="form-group">
                                  <label for="placeTextarea">Review</label>
                                  <input
                                    type="text"
                                    className="form-control"
                                    Placeholder="Enter the review"
                                    value={time}
                                    onChange={(e) => setTime(e.target.value)}
                                  />
                                  <p className="alert-message"></p>
                                </div>
                              </div>
                            </div>

                            <div className="col-md-6">
                              <div className="form-body">
                                <div className="form-group">
                                  <label for="placeTextarea">Rate</label>
                                  <input
                                    type="text"
                                    className="form-control"
                                    Placeholder="Enter your ratings"
                                    value={testType}
                                    onChange={(e) =>
                                      setTestType(e.target.value)
                                    }
                                  />
                                  <p className="alert-message"></p>
                                </div>
                              </div>
                            </div>

                            <div className="col-md-6">
                              <div className="form-body">
                                <div className="form-group">
                                  <label for="placeTextarea">Review</label>
                                  <input
                                    type="text"
                                    className="form-control"
                                    Placeholder="Enter the review"
                                    value={testFor}
                                    onChange={(e) => setTestFor(e.target.value)}
                                  />
                                  <p className="alert-message"></p>
                                </div>
                              </div>
                            </div>

                            <div className="col-md-6">
                              <div className="form-body">
                                <div className="form-group">
                                  <label for="placeTextarea">Rate</label>
                                  <input
                                    type="text"
                                    className="form-control"
                                    Placeholder="Enter your ratings"
                                    value={mobileNo}
                                    onChange={(e) =>
                                      setMobileNo(e.target.value)
                                    }
                                  />
                                  <p className="alert-message"></p>
                                </div>
                              </div>
                            </div>

                            {/*  {address.map((lab, index) => (
                                <div className="col-md-6">
                                <div className="form-body">
                                  <div className="form-group">
                                    <label for="placeTextarea">Rate</label>
                                    <input
                                      type="text"
                                      className="form-control"
                                      Placeholder="Enter your ratings"
                                      value={lab.doorNoAndStreetName}
                                      
                                      
                                    />
                                    <p className="alert-message">
                                      
                                    </p>
                                  </div>
                                </div>
                              </div>

                              <div className="col-md-6">
                              <div className="form-body">
                                <div className="form-group">
                                  <label for="placeTextarea">Rate</label>
                                  <input
                                    type="text"
                                    className="form-control"
                                    Placeholder="Enter your ratings"
                                    value={lab.city}
                                   
                                  />
                                  <p className="alert-message">
                                    
                                  </p>
                                </div>
                              </div>
                            </div>

                            <div className="col-md-6">
                              <div className="form-body">
                                <div className="form-group">
                                  <label for="placeTextarea">Rate</label>
                                  <input
                                    type="text"
                                    className="form-control"
                                    Placeholder="Enter your ratings"
                                    value={lab.state}
                                    onChange={(e) =>
                                      setMobileNo(e.target.value)
                                    }
                                  />
                                  <p className="alert-message">
                                    
                                  </p>
                                </div>
                              </div>
                            </div>

                            <div className="col-md-6">
                              <div className="form-body">
                                <div className="form-group">
                                  <label for="placeTextarea">Rate</label>
                                  <input
                                    type="text"
                                    className="form-control"
                                    Placeholder="Enter your ratings"
                                    value={lab.pincode}
                                    onChange={(e) =>
                                      setMobileNo(e.target.value)
                                    }
                                  />
                                  <p className="alert-message">
                                    
                                  </p>
                                </div>
                              </div>
                            </div>
                                ))}*/}
                          </div>

                          <div className="form-actions center">
                            <button
                              type="submit"
                              className="btn btn-success"
                              //   onClick={save}
                              //   disabled={!message}
                            >
                              <i className="icon-note"></i> Save
                            </button>{" "}
                            &nbsp;
                            <button
                              type="reset"
                              className="btn btn-warning mr-1"
                              onClick={cancel}
                            >
                              <i className="icon-trash"></i> Cancel
                            </button>
                          </div>
                        </form>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <Footer />
    </div>
  );
}
export default AddLabTestRequest;
