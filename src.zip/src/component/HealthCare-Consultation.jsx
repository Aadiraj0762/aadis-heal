import React, { useState } from "react";
import { Link } from "react-router-dom";
import Navbarside from "./Navbarside";
import { useDispatch, useSelector } from "react-redux";
import { getHcConsultation } from "../store/slices/HcConsultation";
import { useNavigate, useParams } from "react-router-dom";
import Footer from "./footer";

const HealthCareConsultation = () => {
  const [hconsultation, setHconsultation] = useState([]);
  const dispatch = useDispatch();

  React.useEffect(() => {
    dispatch(getHcConsultation())
      .unwrap()
      .then((data) => {
        setHconsultation(data.user.data);
      })
      .catch(({ message }) => {
        // alert(message);
      });
  }, [dispatch]);

  return (
    <div>
      <Navbarside />

      <div className="container-fluid pb-5 response-cover">
        <div className="row">
          <div className="col-lg-2 col-md-4" />
          <div className="col-lg-10 col-md-8">
            <div className="container-fluid pt-5">
              <div className="row">
                <div className="col-12">
                  <div className="card">
                    <div className="card-header">
                      <div className="card-title-wrap bar-success d-flex align-items-center">
                        <h4 className="card-title">Health Care Consultation</h4>
                        {/* &nbsp; &nbsp; &nbsp;
                        <Link
                          to="/AddLabdetails"
                          className="btn btn-danger col-white"
                        >
                          Add
                        </Link> */}
                      </div>
                    </div>
                    <div className="card-body collapse show">
                      <div className="card-block card-dashboard table-responsive">
                        <table className="table table-striped table-bordered zero-configuration">
                          <thead>
                            <tr>
                              <th>User</th>
                              <th>Expert</th>
                              <th>Expertise</th>
                              <th>Description</th>
                              <th>Date</th>
                              <th>Time</th>
                              <th>Action</th>
                            </tr>
                          </thead>

                          <tbody>
                            {hconsultation.map((hcConsultationVal, index) => (
                              <tr key={index}>
                                <td>
                                  {hcConsultationVal.userId[0]?.firstName}{" "}
                                  {hcConsultationVal.userId[0]?.lastName}
                                </td>

                                <td>
                                  {Array.isArray(hcConsultationVal.expertId)
                                    ? hcConsultationVal.expertId[0]?.firstName
                                    : ""}{" "}
                                  {Array.isArray(hcConsultationVal.expertId)
                                    ? hcConsultationVal.expertId[0]?.lastName
                                    : ""}
                                </td>

                                <td>
                                  {hcConsultationVal.expertiseId[0]?.name}
                                </td>

                                <td>{hcConsultationVal.description}</td>

                                <td>{hcConsultationVal.startDate}</td>

                                <td>{hcConsultationVal.startTime}</td>
                                <td>
                                  {hcConsultationVal.status === "initiated" && (
                                    <Link
                                      to={`/HealthCare/AssignHealthCareExpert/${
                                        hcConsultationVal._id
                                          ? hcConsultationVal._id
                                          : null
                                      }`}
                                      className="btn btn-warning"
                                      style={{
                                        height: "25px",
                                        padding: "0 10px",
                                      }}
                                    >
                                      Assign Expert
                                    </Link>
                                  )}
                                  {hcConsultationVal.status === "scheduled" && (
                                    <button
                                      className="btn btn-success"
                                      style={{
                                        height: "25px",
                                        padding: "0 10px",
                                      }}
                                    >
                                      Appointment Scheduled
                                    </button>
                                  )}
                                  {hcConsultationVal.status ===
                                    "paymentRequested" && (
                                    <button
                                      className="btn btn-danger"
                                      style={{
                                        height: "25px",
                                        padding: "0 10px",
                                      }}
                                    >
                                      Payment Pending
                                    </button>
                                  )}
                                </td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <Footer />
    </div>
  );
};

export default HealthCareConsultation;
