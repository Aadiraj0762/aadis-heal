import React from "react";
import Navbarside from "./Navbarside";
import { useDispatch } from "react-redux";
import { getfitcenter } from "../store/slices/fitness";
import { useState } from "react";
import Footer from "./footer";
import { Link } from "react-router-dom";
import { ExportToExcel } from "./ExportToExcel";
import { API_PATHS } from "../utils/constants/api.constants";
import axios from "axios";
import { ApproveRequestFitnesss } from "./../store/slices/fitness";
import $ from "jquery";

const FitnessCenter = () => {
  const dispatch = useDispatch();

  const [data, setData] = useState([]);
  const fileName = "Fitness Center";

  React.useEffect(() => {
    const fetchData = () => {
      axios.get(API_PATHS.getfitnesscenter).then((postData) => {
        const customHeadings = postData.data.data.map((item) => ({
          "Fitness Name": item.fcName,
          "Mobile No.": item.fcMobileNo,
          Email: item.fcEmail,
          City: item.fcAddress.city,
          State: item.fcAddress.state,
        }));

        setData(customHeadings);
      });
    };
    fetchData();
  }, []);

  React.useEffect(() => {
    dispatch(getfitcenter())
      .unwrap()
      .then((data) => {
        $("#example").DataTable({
          data: data.user.data.map((e, index) => {
            return { index, ...e };
          }),
          columns: [
            {
              title: "#",
              render: (data, type, row) => {
                return ++row.index;
              },
            },
            {
              title: "Name",
              render: (data, type, row) => {
                return `<a href="/FitnessCenterDetails/${row._id}">${row.fcName}</a>`;
              },
            },
            {
              data: "fcEmail",
              title: "Email",
            },
            {
              data: "fcMobileNo",
              title: "Mobile No.",
            },
            {
              title: "Agreement",
              render: (data, type, row) => {
                return `<a
                    href="${row.agreement}"
                    download
                    style="height: 25px; padding: 0 10px"
                    class="btn btn-danger col-white"
                  >
                    View
                  </a>`;
              },
            },
            {
              title: "Address",
              render: (data, type, row) => {
                return `${row.fcAddress.doorNoAndStreetName} ${row.fcAddress.city}, ${row.fcAddress.state}`;
              },
            },
            {
              title: "Status",
              render: (data, type, row) => {
                if (row.status === "approvalPending") {
                  return `<a
                        class="btn btn-primary"
                        style="height: 25px; padding: 0 10px"
                        href="/FitnessrequestApprove/${
                          row._id ? row._id : null
                        }"
                      >
                        Approve
                      </a>
                      <button
                        class="btn btn-danger"
                        style="height: 25px; padding: 0 10px"
                        onclick="disableApprove('${row._id}')"
                      >
                        Reject
                      </button>`;
                }
                if (row.status === "rejected") {
                  return `<button
                    class="btn btn-danger"
                    style="height: 25px; padding: 0 10px"
                  >
                    Rejected
                  </button>`;
                }
                if (row.status === "approved") {
                  return `<button
                    class="btn btn-success"
                    style="height: 25px; padding: 0 10px"
                  >
                    Approved
                  </button>`;
                }
              },
            },
            {
              title: "Plans",
              render: (data, type, row) => {
                return `<a
                    class="btn btn-primary"
                    style="height: 25px; padding: 0 10px"
                    href="/FitnessCenterPlan/${
                      row.fcAdminId ? row.fcAdminId : null
                    }"
                  >
                    View
                  </a>`;
              },
            },
            {
              title: "Revenue",
              render: (data, type, row) => {
                return `<a
                    class="btn btn-primary"
                    style="height: 25px; padding: 0 10px"
                    href="/FitnessCenterRevenue/${
                      row.fcAdminId ? row.fcAdminId : null
                    }"
                  >
                    View
                  </a>`;
              },
            },
          ],
          destroy: true,
        });
      })
      .catch(({ message }) => {
        alert(message);
      });
  }, [dispatch]);

  async function disableApprove(ids) {
    let status = "rejected";
    let id = ids;
    let isApproved = false;
    let item = { id, status, isApproved };
    localStorage.setItem("item", JSON.stringify(item));
    dispatch(ApproveRequestFitnesss(item))
      .unwrap()
      .then(() => {
        alert("Request rejected succesfully");
        // window.location.reload(false);
      })
      .catch(({ message }) => {
        alert(message);
      });
    console.log(item);
    console.log(id);
  }

  return (
    <div>
      <Navbarside />

      <div className="container-fluid response-cover pb-5">
        <div className="row">
          <div className="col-lg-2 col-md-4" />
          <div className="col-lg-10 col-md-8">
            <div className="container-fluid pt-5">
              <div className="row">
                <div className="col-12">
                  <div className="card">
                    <div className="card-header">
                      <div className="card-title-wrap bar-success d-flex align-items-center">
                        <h4 className="card-title">Fitness Center </h4>
                        &nbsp; &nbsp; &nbsp;
                        <ExportToExcel
                          apiData={data}
                          fileName={fileName}
                          style={{
                            height: "25px",
                            padding: "0 10px",
                            marginBottom: "0%",
                          }}
                        />
                      </div>
                    </div>
                    <div className="card-body collapse show">
                      <div className="card-block card-dashboard table-responsive">
                        <table id="example" className="display"></table>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <Footer />
    </div>
  );
};

export default FitnessCenter;
