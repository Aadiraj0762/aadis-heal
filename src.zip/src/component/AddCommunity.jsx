import React, { useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { Loader } from "semantic-ui-react";
import Navbarside from "./Navbarside";
import { Link, useNavigate } from "react-router-dom";
import Footer from "./footer";
import { FaVideo } from "react-icons/fa";
// import { postcontent } from "../store/slices/content";
import { API_PATHS } from "../utils/constants/api.constants";

const AddCategory = () => {
  const [date, setDate] = useState("");
  const [description, setDescription] = useState("");
  const [mediaLink, setmediaLink] = useState("");

  const [alertdate, setAlertdate] = useState("");
  const [alertdescription, setAlertDescription] = useState("");
  const [alertmediaLink, setAlertmediaLink] = useState("");

  const navigate = useNavigate("");
  const [message, setMessage] = useState("");
  const dispatch = useDispatch();

  const save = (e) => {
    const regdescription = /^(.|\s)*[a-zA-Z]+(.|\s)*$/;
    if (regdescription.test(description)) {
      setAlertDescription("");
    } else if (!regdescription.test(description) && description === "") {
      setAlertDescription("Please enter the description");
      e.preventDefault();
    } else {
      setAlertDescription("");
    }

    const regdate =
      /^([0]?[1-9]|[1|2][0-9]|[3][0|1])[-]([0]?[1-9]|[1][0-2])[-]([0-9]{4}|[0-9]{2})$/;
    if (regdate.test(date)) {
      setAlertdate("");
    } else if (!regdate.test(date) && date === "") {
      setAlertdate("Please enter the date");
      e.preventDefault();
    } else {
      setAlertdate("");
    }
  };

  const cancel = () => {
    setDescription("");
    setmediaLink("");
    setAlertDescription("");
    setAlertmediaLink("");
    setMessage("");
    setAlertdate("");
    setDate("");
  };

  // async function addData(e) {
  //   e.preventDefault();
  //   let data = JSON.parse(localStorage.getItem("user"));
  //   let userId = data.data.id;
  //   let userType = "user";
  //   let isActive = false;
  //   let item = { date, description, mediaLink, userId, userType, isActive };
  //   dispatch(postcontent(item))
  //     .unwrap()
  //     .then(() => {
  //       alert("Posted succesfully");
  //       navigate(-1);
  //     })
  //     .catch(({ message }) => {
  //       alert(message);
  //     });
  // }

  async function imageUpload(e) {
    e.preventDefault();
    var formdata = new FormData();
    formdata.append("file", e.target.files[0]);

    var requestOptions = {
      method: "POST",
      body: formdata,
      redirect: "follow",
    };
    let response = await fetch(API_PATHS.uploadImage, requestOptions);
    let data = await response.json();
    setmediaLink(data.data.location);
    setMessage(data.message);
  }

  return (
    <body data-col="2-columns" className=" 2-columns ">
      <Navbarside />

      <div className="container-fluid pb-5 response-cover">
        <div className="row">
          <div className="col-lg-2 col-md-4" />
          <div className="col-lg-10 col-md-8">
            <div className="container-fluid pt-5">
              <div className="row">
                <div className="col-12">
                  <div className="card">
                    <div className="card-header">
                      <div className="card-title-wrap bar-danger d-flex align-items-center">
                        <h4 className="card-title">
                          Add Community post
                          {/* <Link
                              to="/UploadPackage"
                              className="btn btn-primary"
                            >
                              <i className="fa fa-plus"></i> Add
                            </Link> */}
                        </h4>
                      </div>
                    </div>

                    <section className="form-section">
                      <form>
                        <div className="row">
                          <div className="col-md-12 col-lg-12 col-sm-12 pt-2">
                            <p
                              className="col-black"
                              style={{ marginBottom: "2px" }}
                            >
                              Description
                            </p>
                            <textarea
                              placeholder="Enter the Description"
                              value={description}
                              onChange={(e) => setDescription(e.target.value)}
                              className="form-control"
                            />
                            <p className="alert-message">{alertdescription}</p>
                          </div>

                          <div className="col-md-6 col-lg-4 col-sm-12 pt-2">
                            <p
                              className="col-black"
                              style={{ marginBottom: "2px" }}
                            >
                              Date
                            </p>
                            <input
                              type="date"
                              placeholder="Enter the date"
                              value={date}
                              onChange={(e) => setDate(e.target.value)}
                              className="form-control"
                            />
                            <p className="alert-message">{alertdate}</p>
                          </div>

                          <div className="col-md-6 col-lg-4 col-sm-12 pt-2">
                            <p
                              className="col-black"
                              style={{ marginBottom: "2px" }}
                            >
                              Uploade the image
                            </p>
                            <input
                              type="file"
                              className="form-control-file"
                              Placeholder="Price Tagline"
                              required
                              onChange={(e) => imageUpload(e)}
                            />
                            <p className="alert-message">{alertmediaLink}</p>
                            <p style={{ color: "green", fontWeight: "500" }}>
                              {message}
                            </p>
                          </div>
                        </div>
                        <div className="d-flex justify-content-center pt-3">
                          <button
                            type="submit"
                            className="btn btn-primary wd-100"
                            onClick={save}
                            // disabled={!message}
                          >
                            Submit
                          </button>
                          &nbsp; &nbsp; &nbsp;
                          <button
                            type="reset"
                            className="btn btn-warning wd-100"
                            onClick={cancel}
                          >
                            Cancel
                          </button>
                        </div>
                      </form>
                    </section>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <Footer />
    </body>
  );
};

export default AddCategory;
