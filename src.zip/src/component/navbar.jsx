import React, { useState } from "react";
import Background from "./../img/sidebar-bg/01.jpg";
import { useDispatch } from "react-redux";
import logo from "./../img/logo.png";
import { Link, useNavigate } from "react-router-dom";
// import {Dropdown, Button, ButtonGroup}from 'react-bootstrap';

// let data;

function Navbar() {
  const dispatch = useDispatch();

  let data = JSON.parse(localStorage.getItem("user"));
  let role = data.data.roles[0];

  const navigate = useNavigate();

  function signOut(e) {
    localStorage.clear();
    navigate("/login");
  }

  return (
    <div>
      <div
        data-active-color="white"
        data-background-color="black"
        className="app-sidebar"
        style={{ backgroundImage: `url(${Background})` }}
      >
        <div className="sidebar-header">
          <div className="logo clearfix">
            <Link to="/Home" className="logo-text float-left">
              {/* <div className="logo-img">
                <img src={logo} />
              </div> */}
              <span className="text align-middle" style={{ fontSize: "25px" }}>
                Healthonify
              </span>
            </Link>
            <a
              id="sidebarToggle"
              href="javascript:"
              className="nav-toggle d-none d-sm-none d-md-none d-lg-block"
            >
              <i data-toggle="expanded" className="ft-disc toggle-icon"></i>
            </a>
            <a
              id="sidebarClose"
              href="javascript:;"
              className="nav-close d-block d-md-block d-lg-none d-xl-none"
            >
              <i className="ft-circle"></i>
            </a>
          </div>
        </div>

        <div className="sidebar-content">
          <div className="nav-container">
            <ul
              id="main-menu-navigation"
              data-menu="menu-navigation"
              className="navigation navigation-main"
            >
              <li className="nav-item">
                <Link to="/Home">
                  <i className="icon-home"></i>
                  <span data-i18n="" className="menu-title">
                    Dashboard
                  </span>
                </Link>
              </li>
              {role === "ROLE_TRAVEL_ADMIN" && (
                <li className="nav-item">
                  <Link to="/TravelPackage">
                    <i className="icon-magnet"></i>
                    <span data-i18n="" className="menu-title">
                      Travel Packages
                    </span>
                  </Link>
                </li>
              )}
              {role === "ROLE_EXPERT" && (
                <li className="nav-item">
                  <Link to="/MyClients">
                    <i className="icon-magnet"></i>
                    <span data-i18n="" className="menu-title">
                      My Clients
                    </span>
                  </Link>
                </li>
              )}

              {role === "ROLE_SUPERADMIN" && (
                <li className="nav-item">
                  <Link to="/MyConsultations">
                    <i className="icon-magnet"></i>
                    <span data-i18n="" className="menu-title">
                      Consultations
                    </span>
                  </Link>
                </li>
              )}

              {role === "ROLE_EXPERT" && (
                <li className="nav-item">
                  <Link to="/MyConsultations">
                    <i className="icon-magnet"></i>
                    <span data-i18n="" className="menu-title">
                      My Consultations
                    </span>
                  </Link>
                </li>
              )}

              {role === "ROLE_TRAVELAGENT" && (
                <li className="nav-item">
                  <Link to="/MyTravelPackage">
                    <i className="icon-magnet"></i>
                    <span data-i18n="" className="menu-title">
                      Travel Packages
                    </span>
                  </Link>
                </li>
              )}

              {role === "ROLE_TRAVEL_ADMIN" && (
                <li className="nav-item">
                  <Link to="/TravelCategory">
                    <i className="icon-magnet"></i>
                    <span data-i18n="" className="menu-title">
                      Category
                    </span>
                  </Link>
                </li>
              )}

              {role === "ROLE_TRAVEL_ADMIN" && (
                <li className="nav-item">
                  <Link to="/CityList">
                    <i className="icon-magnet"></i>
                    <span data-i18n="" className="menu-title">
                      City
                    </span>
                  </Link>
                </li>
              )}
              {role === "ROLE_TRAVEL_ADMIN" && (
                <li className="nav-item">
                  <Link to="/ThemeList">
                    <i className="icon-magnet"></i>
                    <span data-i18n="" className="menu-title">
                      Theme
                    </span>
                  </Link>
                </li>
              )}
              {role === "ROLE_HOTELADMIN" && (
                <li className="nav-item">
                  <Link to="/RoomCategory">
                    <i className="icon-home"></i>
                    <span data-i18n="" className="menu-title">
                      Room Category
                    </span>
                  </Link>
                </li>
              )}
              {role === "ROLE_HOTELADMIN" && (
                <li className="nav-item">
                  <Link to="/RoomType">
                    <i className="icon-home"></i>
                    <span data-i18n="" className="menu-title">
                      Room Type
                    </span>
                  </Link>
                </li>
              )}
              {role === "ROLE_TRAVELAGENT" && (
                <li className="nav-item">
                  <a href="/TravelBooking">
                    <i className="icon-magnet"></i>
                    <span data-i18n="" className="menu-title">
                      Booking
                    </span>
                  </a>
                </li>
              )}
              {role === "ROLE_TRAVEL_ADMIN" && (
                <li className="nav-item">
                  <a href="/TravelBooking">
                    <i className="icon-magnet"></i>
                    <span data-i18n="" className="menu-title">
                      Booking
                    </span>
                  </a>
                </li>
              )}
              {role === "ROLE_TRAVELAGENT" && (
                <li className="nav-item">
                  <Link to="/Revenue">
                    <i className="icon-magnet"></i>
                    <span data-i18n="" className="menu-title">
                      Revenue
                    </span>
                  </Link>
                </li>
              )}
              {role === "ROLE_TRAVEL_ADMIN" && (
                <li className="nav-item">
                  <Link to="/TravelAgency">
                    <i className="icon-magnet"></i>
                    <span data-i18n="" className="menu-title">
                      Travel Agency
                    </span>
                  </Link>
                </li>
              )}
              {role === "ROLE_TRAVEL_ADMIN" && (
                <li className="nav-item">
                  <Link to="/TravelAgents">
                    <i className="icon-user"></i>
                    <span data-i18n="" className="menu-title">
                      Travel Agents
                    </span>
                  </Link>
                </li>
              )}
              {role === "ROLE_HOTEL_ADMIN" && (
                <li className="nav-item">
                  <Link to="/RoomCategory">
                    <i className="icon-user"></i>
                    <span data-i18n="" className="menu-title">
                      Room Category
                    </span>
                  </Link>
                </li>
              )}
              {role === "ROLE_TRAVEL_ADMIN" && (
                <li className="nav-item">
                  <Link to="/TravelAgentEnquiry">
                    <i className="icon-user"></i>
                    <span data-i18n="" className="menu-title">
                      Agency Enquiry
                    </span>
                  </Link>
                </li>
              )}
              {role === "ROLE_TRAVEL_ADMIN" && (
                <li className="nav-item">
                  <Link to="/TravelPackageEnquiry">
                    <i className="icon-user"></i>
                    <span data-i18n="" className="menu-title">
                      Travel Packge Enquiry
                    </span>
                  </Link>
                </li>
              )}
              {role === "ROLE_HOTEL_ADMIN" && (
                <li className="nav-item">
                  <Link to="/BedType">
                    <i className="icon-user"></i>
                    <span data-i18n="" className="menu-title">
                      Bed Type
                    </span>
                  </Link>
                </li>
              )}
              {role === "ROLE_HOTEL_ADMIN" && (
                <li className="nav-item">
                  <Link to="/RoomType">
                    <i className="icon-user"></i>
                    <span data-i18n="" className="menu-title">
                      Room Type
                    </span>
                  </Link>
                </li>
              )}
              {/* {role === "ROLE_TRAVEL_ADMIN" && (
                <li className="nav-item">
                  <Link to="/Hoteladmin">
                    <i className="icon-user"></i>
                    <span data-i18n="" className="menu-title">
                      Hotels Admin
                    </span>
                  </Link>
                </li>
              )} */}
              <li className="nav-item">
                <a onClick={signOut}>
                  <i className="icon-user"></i>
                  <span data-i18n="" className="menu-title">
                    Logout
                  </span>
                </a>
              </li>
            </ul>
          </div>
        </div>
        <div className="sidebar-background"></div>
      </div>

      <nav className="navbar navbar-expand-lg navbar-light bg-faded">
        <div className="container-fluid">
          <div className="navbar-header">
            <button
              type="button"
              data-toggle="collapse"
              className="navbar-toggle d-lg-none float-left"
            >
              <span className="sr-only">Toggle navigation</span>
              <span className="icon-bar"></span>
              <span className="icon-bar"></span>
              <span className="icon-bar"></span>
            </button>
            <span className="d-lg-none navbar-right navbar-collapse-toggle">
              <a className="open-navbar-container">
                <i className="ft-more-vertical"></i>
              </a>
            </span>
          </div>
          <div className="navbar-container">
            <div
              id="navbarSupportedContent"
              className="collapse navbar-collapse"
            >
              {/* <ul className="navbar-nav">
                <Dropdown as={ButtonGroup}>
                  <li className="dropdown  mr-0">
                    <a
                      id="dropdownBasic3"
                      href="#"
                      data-toggle="dropdown"
                      className="nav-link position-relative dropdown-user-link dropdown-toggle"
                    >
                      <span className="avatar avatar-online">
                        <img
                          id="navbar-avatar"
                          src="app-assets/img/portrait/small/avatar-s-3.jpg"
                          alt="avatar"
                        />
                      </span>
                    </a>
                  </li>

                  <Dropdown.Toggle
                    split
                    variant="success"
                    id="dropdown-split-basic"
                  />

                  <Dropdown.Menu>
                    <Dropdown.Item href="#/action-1">Action</Dropdown.Item>
                    <Dropdown.Item href="#/action-2">
                      Another action
                    </Dropdown.Item>
                    <Dropdown.Item href="#/action-3">
                      Something else
                    </Dropdown.Item>
                  </Dropdown.Menu>
                </Dropdown>
              </ul> */}
            </div>
          </div>
        </div>
      </nav>
    </div>
  );
}

export default Navbar;
