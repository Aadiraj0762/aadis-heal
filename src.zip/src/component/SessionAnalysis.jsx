import React, { useState, useRef } from "react";
import { useDispatch, useSelector } from "react-redux";
import Navbarside from "../component/Navbarside";
import Footer from "./footer";
import Moment from "moment";
import { SessionnalysisDetails } from "../store/slices/analysis";
import { useDownloadExcel } from "react-export-table-to-excel";

const SessionAnalysis = () => {
  const [startDate, setstartDate] = useState("");
  const [endDate, setendDate] = useState("");
  const tableRef = useRef(null);
  const dispatch = useDispatch();
  const fileName = "Appointment Analysis Report";
  const [data, setData] = useState([]);
  async function analysisData(e) {
    e.preventDefault();
    let item = { startDate, endDate };
    localStorage.setItem("item", JSON.stringify(item));
    dispatch(SessionnalysisDetails())
      .unwrap()
      .then((data) => {
        setData(data.user.data);
      })
      .catch(({ message }) => {
        // alert(message);
      });
  }

  const { onDownload } = useDownloadExcel({
    currentTableRef: tableRef.current,
    filename: "Appointment Analysis Report",
    sheet: "Sheet1",
  });

  return (
    <div>
      <Navbarside />

      <div className="container-fluid pb-5 response-cover">
        <div className="row">
          <div className="col-lg-2 col-md-4" />
          <div className="col-lg-10 col-md-8">
            <div className="container-fluid pt-5">
              <div className="row">
                <div className="col-12">
                  <div className="card">
                    <div className="card-header">
                      <div className="card-title-wrap bar-success d-flex align-items-center">
                        <h4 className="card-title">Session Analysis Report</h4>
                      </div>
                    </div>
                    <section className="form-section">
                      <form onSubmit={analysisData}>
                        <div className="row">
                          <div className="col-md-4 col-sm-12 pt-2">
                            <p
                              className="col-black"
                              style={{ marginBottom: "2px" }}
                            >
                              From Date
                            </p>
                            <input
                              type="date"
                              placeholder="Enter the recipe name"
                              value={startDate}
                              onChange={(e) => setstartDate(e.target.value)}
                              className="form-control"
                            />
                            <p className="alert-message"></p>
                          </div>
                          <div className="col-md-4 col-sm-12 pt-2">
                            <p
                              className="col-black"
                              style={{ marginBottom: "2px" }}
                            >
                              To Date
                            </p>
                            <input
                              type="date"
                              placeholder="Enter the recipe name"
                              value={endDate}
                              onChange={(e) => setendDate(e.target.value)}
                              className="form-control"
                            />
                            <p className="alert-message"></p>
                          </div>
                          <div className="col-md-4 col-sm-12 pt-2 mt-3">
                            <button type="submit" className="btn btn-primary">
                              Submit
                            </button>
                          </div>
                        </div>
                      </form>
                    </section>
                    <div className="card-body collapse show">
                      <div className="card-block card-dashboard table-responsive">
                        {data !== "" && (
                          <div>
                            <button
                              onClick={onDownload}
                              className="btn btn-primary"
                            >
                              Export to Excel
                            </button>
                            <table
                              className="table table-striped table-bordered zero-configuration"
                              ref={tableRef}
                            >
                              <thead>
                                <tr>
                                  <th>Session Date</th>
                                  <th>Session Time</th>
                                  <th>Category</th>
                                  {/* <th>Created By</th> */}

                                  <th>Session Expert</th>
                                  <th>User Name</th>
                                  <th>Plan Name</th>
                                  <th>Session Status</th>
                                </tr>
                              </thead>

                              <tbody>
                                {data.map((dataVal, index) => (
                                  <tr>
                                    <td>
                                      {" "}
                                      {Moment(dataVal.created_at).format(
                                        "DD-MM-YYYY"
                                      )}
                                    </td>
                                    <td>
                                      {Moment(dataVal.created_at).format(
                                        "hh:mm A"
                                      )}
                                    </td>

                                    <td>{dataVal.category}</td>

                                    <td>
                                      <p>
                                        {dataVal.specialExpertId.firstName
                                          ? dataVal.specialExpertId.firstName
                                          : null}
                                        &nbsp;
                                        {dataVal.specialExpertId.lastName
                                          ? dataVal.specialExpertId.lastName
                                          : null}
                                      </p>
                                    </td>
                                    <td>
                                      {dataVal.userId.firstName
                                        ? dataVal.userId.firstName
                                        : null}
                                      &nbsp;
                                      {dataVal.userId.lastName
                                        ? dataVal.userId.lastName
                                        : null}
                                    </td>
                                    <td>
                                      {dataVal.subscriptionId.packageId
                                        ? dataVal.subscriptionId.packageId.name
                                        : null}
                                    </td>
                                    <td>{dataVal.status}</td>
                                  </tr>
                                ))}
                              </tbody>
                            </table>
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <Footer />
    </div>
  );
};

export default SessionAnalysis;
