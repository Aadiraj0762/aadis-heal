import React from "react";
import Navbarside from "./Navbarside";
import { useDispatch } from "react-redux";
import { fitnessCenterPlans } from "../store/slices/fitnessplans";
import { useState } from "react";
import Footer from "./footer";
import { useNavigate, useParams, Link } from "react-router-dom";

const FitnessCenterPlan = () => {
  const { id } = useParams();
  localStorage.setItem("fitnesscenterId", id);
  const [fitnessenquire, setFitnessenquire] = useState([]);
  const dispatch = useDispatch();
  const [data, setData] = useState([]);
  React.useEffect(() => {
    const fetchData = () => {};
    fetchData();
  }, []);

  React.useEffect(() => {
    dispatch(fitnessCenterPlans())
      .unwrap()
      .then((data) => {
        setFitnessenquire(data.user.data);
      })
      .catch(({ message }) => {
        alert(message);
      });
  }, [dispatch]);

  return (
    <div>
      <Navbarside />

      <div className="container-fluid response-cover pb-5">
        <div className="row">
          <div className="col-lg-2 col-md-4" />
          <div className="col-lg-10 col-md-8">
            <div className="container-fluid pt-5">
              <div className="row">
                <div className="col-12">
                  <div className="card">
                    <div className="card-header">
                      <div className="card-title-wrap bar-success d-flex align-items-center">
                        <h4 className="card-title">Fitness Center Plans</h4>
                      </div>
                    </div>
                    <div className="card-body collapse show">
                      <div className="card-block card-dashboard table-responsive">
                        <table className="table table-striped table-bordered zero-configuration">
                          <thead>
                            <tr>
                              <th>Plan Name</th>
                              <th>Plan Validity</th>
                              <th>Price</th>
                              <th>Action</th>
                            </tr>
                          </thead>

                          <tbody>
                            {fitnessenquire.map((fitnessVal, index) => (
                              <tr key={index}>
                                <td>{fitnessVal.name}</td>
                                <td>{fitnessVal.memberShipDurationInDays}</td>
                                <td>{fitnessVal.price}</td>
                                <td>
                                  {" "}
                                  {fitnessVal.isActive === true && (
                                    <button
                                      className="btn btn-warning"
                                      style={{
                                        height: "25px",
                                        padding: "0 10px",
                                      }}
                                    >
                                      Active
                                    </button>
                                  )}
                                  &nbsp;
                                  {fitnessVal.isActive === false && (
                                    <button
                                      className="btn btn-success"
                                      style={{
                                        height: "25px",
                                        padding: "0 10px",
                                      }}
                                    >
                                      Inactive
                                    </button>
                                  )}{" "}
                                </td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <Footer />
    </div>
  );
};

export default FitnessCenterPlan;
