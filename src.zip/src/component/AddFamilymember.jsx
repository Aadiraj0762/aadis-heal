import React, { useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { Loader } from "semantic-ui-react";
import Navbarside from "./Navbarside";
import { Link, useNavigate } from "react-router-dom";
import Footer from "./footer";
import { postmembersLab } from "../store/slices/labdetails";
import { API_PATHS } from "../utils/constants/api.constants";


const AddFamilymember = () => {
    const navigate = useNavigate("");
    const dispatch = useDispatch();

  const [firstName, setFirstName] = useState("");
  const [lastName, setLastName] = useState("");
  const [relation, setRelation] = useState("");
  const [dob, setDob] = useState("");
  const [age, setAge] = useState("");
  const [email, setEmail] = useState("");
  const [mobileNo, setMobileNo] = useState("");
  const [imageUrl, setImageUrl] = useState("");
  const [gender, setGender] = useState("");

  async function imageUpload(e) {
    e.preventDefault();
    var formdata = new FormData();
    formdata.append("file", e.target.files[0]);

    var requestOptions = {
      method: "POST",
      body: formdata,
      redirect: "follow",
    };
    let response = await fetch(API_PATHS.uploadImage, requestOptions);
    let data = await response.json();
    setImageUrl(data.data.location);
    // setMessage(data.message);
  }



  async function addData(e) {
    e.preventDefault();
    let relatesTo = "628e07c3295cbb2a64996d2d";
    let isFamilyMember = true;
    let item = { firstName, lastName, relation, relatesTo, dob, age, isFamilyMember, email, mobileNo, imageUrl, gender};
    dispatch(postmembersLab(item))
      .unwrap()
      .then(() => {
        alert("Uploaded succesfully");
        navigate(-1);
      })
      .catch(({ message }) => {
        alert(message);
      });
  }

//   const save = (e) => {
//     const regname = /^(([A-Za-z]+[,.]?[ ]?|[a-z]+['-]?|[0-9])+)$/;
//     if (regname.test(firstName)) {
//       setAlertName("");
//     } else if (!regname.test(firstName) && firstName === "") {
//       setAlertName("Please enter the body part name");
//       e.preventDefault();
//     } else {
//       setAlertName("Single and double quotes are not-valid");
//       e.preventDefault();
//     }
//   };

//   const cancel = () => {
//     setName("");
//     setAlertName("");
//   };
  return (
    <body data-col="2-columns" className=" 2-columns ">
      <Navbarside />

      <div className="container-fluid pb-5 response-cover">
        <div className="row">
          <div className="col-lg-2 col-md-4" />
          <div className="col-lg-10 col-md-8">
            <div className="container-fluid pt-5">
              <div className="row">
                <div className="col-12">
                  <div className="card">
                    <div className="card-header">
                      <div className="card-title-wrap bar-danger d-flex align-items-center">
                        <h4 className="card-title">Add Family Members</h4>
                      </div>
                    </div>

                    <section className="form-section">
                      <form
                       onSubmit={addData}
                       >
                        <div className="row">
                          <div className="col-md-6 col-sm-12 pt-2">
                            <p
                              className="col-black"
                              style={{ marginBottom: "2px" }}
                            >
First Name
                            </p>
                            <input
                              type="text"
                              placeholder="Enter your first name"
                              value={firstName}
                              onChange={(e) => setFirstName(e.target.value)}
                              className="form-control"
                            />
                            <p className="alert-message"></p>
                          </div>

                          <div className="col-md-6 col-sm-12 pt-2">
                            <p
                              className="col-black"
                              style={{ marginBottom: "2px" }}
                            >
                              Last Name
                            </p>
                            <input
                              type="text"
                              placeholder="Enter your last name"
                              value={lastName}
                              onChange={(e) => setLastName(e.target.value)}
                              className="form-control"
                            />
                            <p className="alert-message"></p>
                          </div>

                          <div className="col-md-6 col-sm-12 pt-2">
                            <p
                              className="col-black"
                              style={{ marginBottom: "2px" }}
                            >
                              Relation
                            </p>
                            <input
                              type="text"
                              placeholder="Enter the relation"
                              value={relation}
                              onChange={(e) => setRelation(e.target.value)}
                              className="form-control"
                            />
                            <p className="alert-message"></p>
                          </div>

                          <div className="col-md-6 col-sm-12 pt-2">
                          <p
                            className="col-black"
                            style={{ marginBottom: "2px" }}
                          >
                            Date Of Birth
                          </p>
                          <input
                            type="text"
                            placeholder="Enter the D O B"
                            value={dob}
                            onChange={(e) => setDob(e.target.value)}
                            className="form-control"
                          />
                          <p className="alert-message"></p>
                        </div>

                        <div className="col-md-6 col-sm-12 pt-2">
                        <p
                          className="col-black"
                          style={{ marginBottom: "2px" }}
                        >
Age
                        </p>
                        <input
                          type="text"
                          placeholder="Enter the age"
                          value={age}
                          onChange={(e) => setAge(e.target.value)}
                          className="form-control"
                        />
                        <p className="alert-message"></p>
                      </div>

                      <div className="col-md-6 col-sm-12 pt-2">
                      <p
                        className="col-black"
                        style={{ marginBottom: "2px" }}
                      >
Email
                      </p>
                      <input
                        type="text"
                        placeholder="Enter the email"
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        className="form-control"
                      />
                      <p className="alert-message"></p>
                    </div>

                    <div className="col-md-6 col-sm-12 pt-2">
                    <p
                      className="col-black"
                      style={{ marginBottom: "2px" }}
                    >
Mobile No
                    </p>
                    <input
                      type="text"
                      placeholder="Enter the mobile number"
                      value={mobileNo}
                      onChange={(e) => setMobileNo(e.target.value)}
                      className="form-control"
                    />
                    <p className="alert-message"></p>
                  </div>

                  <div className="col-md-6 col-sm-12 pt-2">
                  <p
                    className="col-black"
                    style={{ marginBottom: "2px" }}
                  >
Gender
                  </p>
                  <input
                    type="text"
                    placeholder="Enter the gender"
                    value={gender}
                    onChange={(e) => setGender(e.target.value)}
                    className="form-control"
                  />
                  <p className="alert-message"></p>
                </div>

                
                <div className="col-md-6 col-sm-12 pt-2">
                <p
                  className="col-black"
                  style={{ marginBottom: "2px" }}
                >
Image
                </p>
                <input
                                    type="file"
                                    className="form-control-file"
                                    Placeholder=""
                                    name="imageUrl"
                                    onChange={(e) => imageUpload(e)}
                                  />
                <p className="alert-message"></p>
              </div>

                        </div>
                        <div className="d-flex justify-content-center pt-3">
                          <button
                            type="submit"
                            className="btn btn-success"
                            // onClick={save}
                          >
                            Submit
                          </button>
                          &nbsp; &nbsp; &nbsp;
                          <button
                            type="reset"
                            className="btn btn-warning"
                            // onClick={cancel}
                          >
                            Reset
                          </button>
                        </div>
                      </form>
                    </section>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <Footer />
    </body>
  );
};

export default AddFamilymember;
