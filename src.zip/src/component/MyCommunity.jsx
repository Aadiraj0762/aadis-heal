import React, { useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import Navbarside from "../component/Navbarside";
import { getAllcommunity } from "../store/slices/Community";
import Footer from "./footer";
import { FaUserCircle } from "react-icons/fa";
import Skeleton from "@mui/material/Skeleton";

import { Link, useNavigate } from "react-router-dom";

const Community = () => {
  const dispatch = useDispatch();
  const [communitys, setCommunitys] = useState([]);

  React.useEffect(() => {
    dispatch(getAllcommunity())
      .unwrap()
      .then((data) => {
        setCommunitys(data.user.data);
      })
      .catch(({ message }) => {
        // alert(message);
      });
  }, [dispatch]);
  return (
    <div>
      <body data-col="2-columns" className=" 2-columns ">
        <Navbarside />

        <div className="container-fluid pb-5 response-cover">
          <div className="row">
            <div className="col-lg-2 col-md-4" />
            <div className="col-lg-10 col-md-8">
              <div className="container-fluid pt-5">
                <div className="row">
                  <div className="col-12">
                    <div className="card">
                      <div className="card-header">
                        <div className="card-title-wrap bar-success">
                          <h4 className="card-title">
                            Community &nbsp; &nbsp;
                            <Link
                              to="/Community/AddCommunity"
                              className="btn btn-primary"
                            >
                              <i className="fa fa-plus"></i> Add
                            </Link>
                          </h4>
                        </div>
                      </div>

                      <div className="row">
                        {communitys.map((CommunityVal) => (
                          <div
                            className="col-lg-4 col-md-12 col-sm-12 position-relative"
                            style={{ zIndex: "1" }}
                          >
                            <div className="card-bg-gray">
                              <div className="d-flex justify-content-start">
                                <div>
                                  <FaUserCircle className="post-icon" />
                                </div>{" "}
                                &nbsp;
                                <div className="name-t">
                                  {/* <p>
                                    {CommunityVal.userId.firstName}{" "}
                                    {CommunityVal.userId.lastName}
                                  </p> */}
                                  <span> {CommunityVal.date}</span>
                                </div>
                              </div>

                              <div className="dec-t pt-2">
                                <p>{CommunityVal.description}</p>
                              </div>

                              <img
                                src={CommunityVal.mediaLink}
                                alt=""
                                className="post-img"
                              />
                            </div>
                          </div>
                        ))}
                      </div>

                      <div className="position-absolute position-set">
                        <div className="row">
                          <div className="col-lg-4 col-md-12 col-sm-12">
                            <div className="card-bg-gray-skeleton">
                              <Skeleton
                                variant="circular"
                                width={50}
                                height={50}
                              />
                              <br />
                              <Skeleton
                                variant="rectangle"
                                width="100%"
                                height={10}
                                className="pt-1"
                              />
                              <br />

                              <Skeleton
                                variant="rectangle"
                                width="100%"
                                height={270}
                                className="pt-1"
                              />
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <Footer />
      </body>
    </div>
  );
};

export default Community;
