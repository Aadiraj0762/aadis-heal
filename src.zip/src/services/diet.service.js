import axios from "axios";
import { API_PATHS } from "../utils/constants/api.constants";

class dietService {

    static postdietplan(item) {
        return axios
            .post(API_PATHS.postdiet,
                item
            )
            .then((response) => {
                if (response.data) {
                    //  localStorage.setItem("user", JSON.stringify(response.data));
                }
                return response.data;
            });
    }

    static getdietplan() {
        let api='';
         let id = localStorage.getItem("id"); 
         api = id ? API_PATHS.getdietplan + '?_id=' + id : API_PATHS.getdietplan;
         localStorage.removeItem("id");
         return axios
         .get( api)
             .then((response) => {
                 if (response.data) {
                     // localStorage.setItem("user", JSON.stringify(response.data));
                 }
                 return response.data;
             });
     }

     static getExpertdietplan() {
        let api='';
        let user = JSON.parse(localStorage.getItem("user"));
        let id = user.data.id;
         api = API_PATHS.getdietplan + '?expertId=' + id ;
         localStorage.removeItem("id");
         return axios
         .get( api)
             .then((response) => {
                 if (response.data) {
                     // localStorage.setItem("user", JSON.stringify(response.data));
                 }
                 return response.data;
             });
     }

     static getdietplanDetails() {
        let api='';
         let id = localStorage.getItem("dietPlanId"); 
         api =  API_PATHS.getdietplan + '?_id=' + id ;
         localStorage.removeItem("id");
         return axios
         .get( api)
             .then((response) => {
                 if (response.data) {
                     // localStorage.setItem("user", JSON.stringify(response.data));
                 }
                 return response.data;
             });
     }

     
     static deleteDietplan() {
        let api = '';
        let id = localStorage.getItem("id");
          api = API_PATHS.deleteDietPlan + '?id=' + id ;
        localStorage.removeItem("id");
        return axios
            .delete(api)
            .then((response) => {
                if (response.data) {
                    // localStorage.setItem("user", JSON.stringify(response.data));
                }
                return response.data;
            });
    }
  
    static removeUserDetails() {
        localStorage.removeItem("user");
    }

    static getUserDetails() {
        return JSON.parse(localStorage.getItem("user"));
    }
}

export default dietService;