import axios from "axios";
import { API_PATHS } from "../utils/constants/api.constants";

class ExpertService {


 
    static editexpertprofile(item) {
        let api = '';
        let id = localStorage.getItem("expertId");
          api =API_PATHS.putuser + '?id=' + id;
        localStorage.removeItem("id");
        return axios
            .put(api,
                item
            )
            .then((response) => {
                if (response.data) {
                   // localStorage.setItem("user", JSON.stringify(response.data));
                }
                return response.data;
            });
    }



    static getuserDetails() {
        let api = '';
        let user = JSON.parse(localStorage.getItem("user"));
        let id = user.data.id;
    api =API_PATHS.getuser + '?id=' + id ;
    localStorage.removeItem("id");
        return axios
            .get(api)
            .then((response) => {
                if (response.data) {
                    // localStorage.setItem("user", JSON.stringify(response.data));
                }
                return response.data;
            });
    }

    static clientDetails() {
        let api = '';
        let id = localStorage.getItem("id");
    api =API_PATHS.getuser + '?id=' + id ;
    // localStorage.removeItem("id");
        return axios
            .get(api)
            .then((response) => {
                if (response.data) {
                    // localStorage.setItem("user", JSON.stringify(response.data));
                }
                return response.data;
            });
    }


    static expertDetails() {
        let api = '';
        let id = localStorage.getItem("expertId");
    api =API_PATHS.getuser + '?id=' + id ;
    // localStorage.removeItem("id");
        return axios
            .get(api)
            .then((response) => {
                if (response.data) {
                    // localStorage.setItem("user", JSON.stringify(response.data));
                }
                return response.data;
            });
    }



    static expertprofile(item) {
        return axios
            .post(API_PATHS.addExpert,
                item
            )
            .then((response) => {
                if (response.data) {
             
                }
                return response.data;
            });
    }




    static removeUserDetails() {
        localStorage.removeItem("user");
    }

    static getUserDetails() {
        return JSON.parse(localStorage.getItem("user"));
    }
}

export default ExpertService;