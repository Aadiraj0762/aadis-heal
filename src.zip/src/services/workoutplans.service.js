import axios from "axios";
import { API_PATHS } from "../utils/constants/api.constants";

class workoutService {

    static getworkplan() {
        let api='';
         let id = localStorage.getItem("id"); 
         api = id ? API_PATHS.getworkoutplan + '?_id=' + id : API_PATHS.getworkoutplan;
         localStorage.removeItem("id");
         return axios
         .get( api)
             .then((response) => {
                 if (response.data) {
                     // localStorage.setItem("user", JSON.stringify(response.data));
                 }
                 return response.data;
             });
     }
     static getExpertworkplan() {
        let api='';
        let user = JSON.parse(localStorage.getItem("user"));
        let id = user.data.id;
         api =  API_PATHS.getworkoutplan + '?expertId=' + id;
         localStorage.removeItem("id");
         return axios
         .get( api)
             .then((response) => {
                 if (response.data) {
                     // localStorage.setItem("user", JSON.stringify(response.data));
                 }
                 return response.data;
             });
     }
     static getworkplanDetails() {
        let api='';
         let id = localStorage.getItem("workoutId"); 
         api = API_PATHS.getworkoutplan + '?_id=' + id ;
         localStorage.removeItem("id");
         return axios
         .get( api)
             .then((response) => {
                 if (response.data) {
                     // localStorage.setItem("user", JSON.stringify(response.data));
                 }
                 return response.data;
             });
     }

     static deleteWorkoutplan() {
        let api = '';
        let id = localStorage.getItem("id");
          api = API_PATHS.deleteworkoutplan + '?id=' + id ;
        localStorage.removeItem("id");
        return axios
            .delete(api)
            .then((response) => {
                if (response.data) {
                    // localStorage.setItem("user", JSON.stringify(response.data));
                }
                return response.data;
            });
    }

     
    static removeUserDetails() {
        localStorage.removeItem("user");
    }

    static getUserDetails() {
        return JSON.parse(localStorage.getItem("user"));
    }
}

export default workoutService;