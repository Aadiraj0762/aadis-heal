import axios from "axios";
import { API_PATHS } from "../utils/constants/api.constants";

class AnalysisService {

    static salesAnalysis() {
        let api = '';
        let item = JSON.parse(localStorage.getItem("item"));
        api = API_PATHS.salesAnalysisDetail + '?startDate=' + item.startDate + '&endDate=' + item.endDate;
        return axios
            .get(api)
            .then((response) => {
                if (response.data) {
                    
                }
                return response.data;
            });
    }

    static appointmentAnalysis() {
        let api = '';
        let item = JSON.parse(localStorage.getItem("item"));
        api = API_PATHS.appointmentAnalysisDetail + '?startDate=' + item.startDate + '&endDate=' + item.endDate;
        return axios
            .get(api)
            .then((response) => {
                if (response.data) {
                    // localStorage.setItem("user", JSON.stringify(response.data));
                }
                return response.data;
            });
    }

    static sessionAnalysis() {
        let api = '';
        let item = JSON.parse(localStorage.getItem("item"));
        api = API_PATHS.sessionAnalysisDetail + '?startDate=' + item.startDate + '&endDate=' + item.endDate;
        return axios
            .get(api)
            .then((response) => {
                if (response.data) {
                    // localStorage.setItem("user", JSON.stringify(response.data));
                }
                return response.data;
            });
    }

    static gstAnalysis() {
        let api = '';
        let item = JSON.parse(localStorage.getItem("item"));
        api = API_PATHS.accountReport + '?startDate=' + item.startDate + '&endDate=' + item.endDate;
        return axios
            .get(api)
            .then((response) => {
                if (response.data) {
                    // localStorage.setItem("user", JSON.stringify(response.data));
                }
                return response.data;
            });
    }





    static removeUserDetails() {
        localStorage.removeItem("user");
    }

    static getUserDetails() {
        return JSON.parse(localStorage.getItem("user"));
    }
}

export default AnalysisService;
