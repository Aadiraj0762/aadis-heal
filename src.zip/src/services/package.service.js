import axios from "axios";
import { API_PATHS } from "../utils/constants/api.constants";

class PackageService {
    static getPackages() {
       let api='';
      //  let id = localStorage.getItem("id"); 
        api = API_PATHS.getPackage;
        localStorage.removeItem("id");
        return axios
        .get( api)
            .then((response) => {
                if (response.data) {
                    // localStorage.setItem("user", JSON.stringify(response.data));
                }
                return response.data;
            });
    }

 
     static postPackages(item) {
        return axios
            .post(API_PATHS.addPackage,
                item
            )
            .then((response) => {
                if (response.data) {
                    // localStorage.setItem("user", JSON.stringify(response.data));
                }
                return response.data;
            });
    }
    static deletePackage() {
        let api = '';
        let id = localStorage.getItem("id");
          api = API_PATHS.deletePackage + '?id=' + id ;
        localStorage.removeItem("id");
        return axios
            .delete(api)
            .then((response) => {
                if (response.data) {
                    // localStorage.setItem("user", JSON.stringify(response.data));
                }
                return response.data;
            });
    }

    static removeUserDetails() {
        localStorage.removeItem("user");
    }

    static getUserDetails() {
        return JSON.parse(localStorage.getItem("user"));
    }
}

export default PackageService; 