import axios from "axios";
import { API_PATHS } from "../utils/constants/api.constants";

class ExpertiseService {
    static getExpertise() {
        let api = '';
        let id = localStorage.getItem("id");
          api = id ? API_PATHS.getExpertise + '?_id=' + id : API_PATHS.getExpertise;
        
        localStorage.removeItem("id");
        return axios
            .get(api)
            .then((response) => {
                if (response.data) {
                    // localStorage.setItem("user", JSON.stringify(response.data));
                }
                return response.data;
            });
    }

   


    static removeUserDetails() {
        localStorage.removeItem("user");
    }

    static getUserDetails() {
        return JSON.parse(localStorage.getItem("user"));
    }
}

export default ExpertiseService;