import axios from "axios";
import { API_PATHS } from "../utils/constants/api.constants";

class hcexpertService {

  static posthcexpert(item) {
    return axios
        .post(API_PATHS.posthcexpert,
            item
        )
        .then((response) => {
            if (response.data) {
                // localStorage.setItem("user", JSON.stringify(response.data));
            }
            return response.data;
        });
}

static getWmExperts() {
    let api = '';
    let id = '6229a968eb71920e5c85b0af';
      api =API_PATHS.getuser + '?topExpertise=' + id;

    localStorage.removeItem("id");
    return axios
        .get(api)
        .then((response) => {
            if (response.data) {
                // localStorage.setItem("user", JSON.stringify(response.data));
            }
            return response.data;
        });
}

static getHcExperts() {
    let api = '';
    let id = '6343acb2f427d20b635ec853';
      api =API_PATHS.getuser + '?topExpertise=' + id;

    localStorage.removeItem("id");
    return axios
        .get(api)
        .then((response) => {
            if (response.data) {
                // localStorage.setItem("user", JSON.stringify(response.data));
            }
            return response.data;
        });
}
static getFitnessExperts() {
    let api = '';
    let id = '63ef2333eef2ad2bdf410333';
      api =API_PATHS.getuser + '?topExpertise=' + id;

    localStorage.removeItem("id");
    return axios
        .get(api)
        .then((response) => {
            if (response.data) {
                // localStorage.setItem("user", JSON.stringify(response.data));
            }
            return response.data;
        });
}
static getPhysioExperts() {
    let api = '';
    let id = '6229a980305897106867f787';
      api =API_PATHS.getuser + '?topExpertise=' + id;

    localStorage.removeItem("id");
    return axios
        .get(api)
        .then((response) => {
            if (response.data) {
                // localStorage.setItem("user", JSON.stringify(response.data));
            }
            return response.data;
        });
}

static getHcexpertdetail() {

    let api = '';
    let id = localStorage.getItem("id");
    api = API_PATHS.getuser + '?_id=' + id ;
    return axios
        .get(api)
        .then((response) => {
            if (response.data) {
                // localStorage.setItem("user", JSON.stringify(response.data));
            }
            return response.data;
        });
}


    static removeUserDetails() {
        localStorage.removeItem("user");
    }

    static getUserDetails() {
        return JSON.parse(localStorage.getItem("user"));
    }
}

export default hcexpertService