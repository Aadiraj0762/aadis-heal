import axios from "axios";
import { API_PATHS } from "../utils/constants/api.constants";

class healthConditions {
  static getHealthConditions() {
    return axios.get(API_PATHS.getHealthConditions).then((response) => {
      if (response.data) {
        // localStorage.setItem("user", JSON.stringify(response.data));
      }
      return response.data;
    });
  }

  static postHealthConditions(item) {
    return axios
      .post(API_PATHS.postHealthConditions, item)
      .then((response) => {
        if (response.data) {
          // localStorage.setItem("user", JSON.stringify(response.data));
        }
        return response.data;
      });
  }

  static editHealthConditions(item) {
    let api = "";
    let id = localStorage.getItem("id");
    api = API_PATHS.putHealthConditions + "?id=" + id;
    localStorage.removeItem("id");
    return axios.put(api, item).then((response) => {
      if (response.data) {
        // localStorage.setItem("user", JSON.stringify(response.data));
      }
      return response.data;
    });
  }

  static deleteHealthConditions() {
    let api = "";
    let id = localStorage.getItem("id");
    api = API_PATHS.deleteHealthConditions + "?id=" + id;
    localStorage.removeItem("id");
    return axios.delete(api).then((response) => {
      if (response.data) {
        // localStorage.setItem("user", JSON.stringify(response.data));
      }
      return response.data;
    });
  }

  static removeUserDetails() {
    localStorage.removeItem("user");
  }

  static getUserDetails() {
    return JSON.parse(localStorage.getItem("user"));
  }
}

export default healthConditions;
